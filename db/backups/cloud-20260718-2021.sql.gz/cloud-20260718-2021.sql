--
-- PostgreSQL database dump
--

\restrict fp6FoTXCcWuPx5foQVpVeeOAXlLjNWso26JGe1iD7UYCkeC8D6ttd318dXmjm5X

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.4 (Debian 18.4-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY climbing.topo DROP CONSTRAINT IF EXISTS topo_media_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.topo_line DROP CONSTRAINT IF EXISTS topo_line_topo_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.topo_line DROP CONSTRAINT IF EXISTS topo_line_source_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.topo_line DROP CONSTRAINT IF EXISTS topo_line_route_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.topo DROP CONSTRAINT IF EXISTS topo_area_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route DROP CONSTRAINT IF EXISTS route_sun_window_code_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route DROP CONSTRAINT IF EXISTS route_rock_code_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route_reference DROP CONSTRAINT IF EXISTS route_reference_route_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route DROP CONSTRAINT IF EXISTS route_protection_code_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route_parking DROP CONSTRAINT IF EXISTS route_parking_route_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route DROP CONSTRAINT IF EXISTS route_incline_code_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route_hazard DROP CONSTRAINT IF EXISTS route_hazard_route_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route_hazard DROP CONSTRAINT IF EXISTS route_hazard_hazard_code_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route_guidebook DROP CONSTRAINT IF EXISTS route_guidebook_route_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route_guidebook DROP CONSTRAINT IF EXISTS route_guidebook_guidebook_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route DROP CONSTRAINT IF EXISTS route_grade_system_code_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route_grade DROP CONSTRAINT IF EXISTS route_grade_route_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route_grade DROP CONSTRAINT IF EXISTS route_grade_grade_system_code_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route_feature DROP CONSTRAINT IF EXISTS route_feature_route_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route_feature DROP CONSTRAINT IF EXISTS route_feature_feature_code_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route_discipline DROP CONSTRAINT IF EXISTS route_discipline_route_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route_discipline DROP CONSTRAINT IF EXISTS route_discipline_discipline_code_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route DROP CONSTRAINT IF EXISTS route_commitment_code_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route_climatology DROP CONSTRAINT IF EXISTS route_climatology_route_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route_character DROP CONSTRAINT IF EXISTS route_character_route_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route_character DROP CONSTRAINT IF EXISTS route_character_character_code_fkey;
ALTER TABLE IF EXISTS ONLY climbing.route DROP CONSTRAINT IF EXISTS route_area_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.provenance DROP CONSTRAINT IF EXISTS provenance_source_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.provenance DROP CONSTRAINT IF EXISTS provenance_route_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.pitch DROP CONSTRAINT IF EXISTS pitch_route_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.pitch DROP CONSTRAINT IF EXISTS pitch_grade_system_code_fkey;
ALTER TABLE IF EXISTS ONLY climbing.media DROP CONSTRAINT IF EXISTS media_area_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.guide_section DROP CONSTRAINT IF EXISTS guide_section_guide_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.guide_section DROP CONSTRAINT IF EXISTS guide_section_area_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.guide_route DROP CONSTRAINT IF EXISTS guide_route_section_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.guide_route DROP CONSTRAINT IF EXISTS guide_route_route_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.guide_route DROP CONSTRAINT IF EXISTS guide_route_guide_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.guide_edition DROP CONSTRAINT IF EXISTS guide_edition_guide_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.guide DROP CONSTRAINT IF EXISTS guide_area_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.grade_conversion DROP CONSTRAINT IF EXISTS grade_conversion_grade_system_code_fkey;
ALTER TABLE IF EXISTS ONLY climbing.first_ascent DROP CONSTRAINT IF EXISTS first_ascent_style_code_fkey;
ALTER TABLE IF EXISTS ONLY climbing.first_ascent DROP CONSTRAINT IF EXISTS first_ascent_route_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.external_ref DROP CONSTRAINT IF EXISTS external_ref_source_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.crawl_frontier DROP CONSTRAINT IF EXISTS crawl_frontier_source_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.crawl_frontier DROP CONSTRAINT IF EXISTS crawl_frontier_route_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.crawl_frontier DROP CONSTRAINT IF EXISTS crawl_frontier_parent_frontier_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.crawl_frontier DROP CONSTRAINT IF EXISTS crawl_frontier_area_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.area DROP CONSTRAINT IF EXISTS area_rock_code_fkey;
ALTER TABLE IF EXISTS ONLY climbing.area_reference DROP CONSTRAINT IF EXISTS area_reference_area_id_fkey;
ALTER TABLE IF EXISTS ONLY climbing.area DROP CONSTRAINT IF EXISTS area_parent_id_fkey;
DROP TRIGGER IF EXISTS route_hazard_evidence ON climbing.route_hazard;
DROP INDEX IF EXISTS climbing.topo_line_route_idx;
DROP INDEX IF EXISTS climbing.topo_area_idx;
DROP INDEX IF EXISTS climbing.route_status_ix;
DROP INDEX IF EXISTS climbing.route_parking_route_ix;
DROP INDEX IF EXISTS climbing.route_needs_field_check_ix;
DROP INDEX IF EXISTS climbing.route_name_trgm;
DROP INDEX IF EXISTS climbing.route_geom_gix;
DROP INDEX IF EXISTS climbing.route_data_grade_ix;
DROP INDEX IF EXISTS climbing.provenance_route_field_ix;
DROP INDEX IF EXISTS climbing.media_area_idx;
DROP INDEX IF EXISTS climbing.crawl_frontier_tag_pending_ix;
DROP INDEX IF EXISTS climbing.crawl_frontier_parent_ix;
DROP INDEX IF EXISTS climbing.crawl_frontier_needs_review_ix;
DROP INDEX IF EXISTS climbing.crawl_frontier_fetch_pending_ix;
DROP INDEX IF EXISTS climbing.area_name_trgm;
DROP INDEX IF EXISTS climbing.area_geom_gix;
ALTER TABLE IF EXISTS ONLY climbing.topo DROP CONSTRAINT IF EXISTS topo_pkey;
ALTER TABLE IF EXISTS ONLY climbing.topo_line DROP CONSTRAINT IF EXISTS topo_line_pkey;
ALTER TABLE IF EXISTS ONLY climbing.sun_window DROP CONSTRAINT IF EXISTS sun_window_pkey;
ALTER TABLE IF EXISTS ONLY climbing.source DROP CONSTRAINT IF EXISTS source_pkey;
ALTER TABLE IF EXISTS ONLY climbing.route_reference DROP CONSTRAINT IF EXISTS route_reference_pkey;
ALTER TABLE IF EXISTS ONLY climbing.route DROP CONSTRAINT IF EXISTS route_pkey;
ALTER TABLE IF EXISTS ONLY climbing.route_parking DROP CONSTRAINT IF EXISTS route_parking_pkey;
ALTER TABLE IF EXISTS ONLY climbing.route_hazard DROP CONSTRAINT IF EXISTS route_hazard_pkey;
ALTER TABLE IF EXISTS ONLY climbing.route_guidebook DROP CONSTRAINT IF EXISTS route_guidebook_pkey;
ALTER TABLE IF EXISTS ONLY climbing.route_grade DROP CONSTRAINT IF EXISTS route_grade_pkey;
ALTER TABLE IF EXISTS ONLY climbing.route_feature DROP CONSTRAINT IF EXISTS route_feature_pkey;
ALTER TABLE IF EXISTS ONLY climbing.route_discipline DROP CONSTRAINT IF EXISTS route_discipline_pkey;
ALTER TABLE IF EXISTS ONLY climbing.route_climatology DROP CONSTRAINT IF EXISTS route_climatology_pkey;
ALTER TABLE IF EXISTS ONLY climbing.route_character DROP CONSTRAINT IF EXISTS route_character_pkey;
ALTER TABLE IF EXISTS ONLY climbing.route DROP CONSTRAINT IF EXISTS route_area_id_name_key;
ALTER TABLE IF EXISTS ONLY climbing.rock_type DROP CONSTRAINT IF EXISTS rock_type_pkey;
ALTER TABLE IF EXISTS ONLY climbing.provenance DROP CONSTRAINT IF EXISTS provenance_pkey;
ALTER TABLE IF EXISTS ONLY climbing.protection_grade DROP CONSTRAINT IF EXISTS protection_grade_pkey;
ALTER TABLE IF EXISTS ONLY climbing.pitch DROP CONSTRAINT IF EXISTS pitch_pkey;
ALTER TABLE IF EXISTS ONLY climbing.media DROP CONSTRAINT IF EXISTS media_pkey;
ALTER TABLE IF EXISTS ONLY climbing.incline DROP CONSTRAINT IF EXISTS incline_pkey;
ALTER TABLE IF EXISTS ONLY climbing.hazard DROP CONSTRAINT IF EXISTS hazard_pkey;
ALTER TABLE IF EXISTS ONLY climbing.guidebook DROP CONSTRAINT IF EXISTS guidebook_pkey;
ALTER TABLE IF EXISTS ONLY climbing.guidebook DROP CONSTRAINT IF EXISTS guidebook_isbn_key;
ALTER TABLE IF EXISTS ONLY climbing.guide DROP CONSTRAINT IF EXISTS guide_slug_key;
ALTER TABLE IF EXISTS ONLY climbing.guide_section DROP CONSTRAINT IF EXISTS guide_section_pkey;
ALTER TABLE IF EXISTS ONLY climbing.guide_section DROP CONSTRAINT IF EXISTS guide_section_guide_id_position_key;
ALTER TABLE IF EXISTS ONLY climbing.guide_route DROP CONSTRAINT IF EXISTS guide_route_pkey;
ALTER TABLE IF EXISTS ONLY climbing.guide DROP CONSTRAINT IF EXISTS guide_pkey;
ALTER TABLE IF EXISTS ONLY climbing.guide_edition DROP CONSTRAINT IF EXISTS guide_edition_pkey;
ALTER TABLE IF EXISTS ONLY climbing.grade_system DROP CONSTRAINT IF EXISTS grade_system_pkey;
ALTER TABLE IF EXISTS ONLY climbing.grade_conversion DROP CONSTRAINT IF EXISTS grade_conversion_pkey;
ALTER TABLE IF EXISTS ONLY climbing.first_ascent DROP CONSTRAINT IF EXISTS first_ascent_pkey;
ALTER TABLE IF EXISTS ONLY climbing.feature DROP CONSTRAINT IF EXISTS feature_pkey;
ALTER TABLE IF EXISTS ONLY climbing.external_ref DROP CONSTRAINT IF EXISTS external_ref_source_id_external_id_key;
ALTER TABLE IF EXISTS ONLY climbing.external_ref DROP CONSTRAINT IF EXISTS external_ref_pkey;
ALTER TABLE IF EXISTS ONLY climbing.discipline DROP CONSTRAINT IF EXISTS discipline_pkey;
ALTER TABLE IF EXISTS ONLY climbing.crawl_frontier DROP CONSTRAINT IF EXISTS crawl_frontier_source_id_external_id_key;
ALTER TABLE IF EXISTS ONLY climbing.crawl_frontier DROP CONSTRAINT IF EXISTS crawl_frontier_pkey;
ALTER TABLE IF EXISTS ONLY climbing.commitment_grade DROP CONSTRAINT IF EXISTS commitment_grade_pkey;
ALTER TABLE IF EXISTS ONLY climbing."character" DROP CONSTRAINT IF EXISTS character_pkey;
ALTER TABLE IF EXISTS ONLY climbing.ascent_style DROP CONSTRAINT IF EXISTS ascent_style_pkey;
ALTER TABLE IF EXISTS ONLY climbing.area_reference DROP CONSTRAINT IF EXISTS area_reference_pkey;
ALTER TABLE IF EXISTS ONLY climbing.area DROP CONSTRAINT IF EXISTS area_pkey;
ALTER TABLE IF EXISTS ONLY climbing.area DROP CONSTRAINT IF EXISTS area_parent_id_name_key;
DROP TABLE IF EXISTS climbing.topo_line;
DROP TABLE IF EXISTS climbing.topo;
DROP TABLE IF EXISTS climbing.sun_window;
DROP TABLE IF EXISTS climbing.source;
DROP VIEW IF EXISTS climbing.route_resolved;
DROP TABLE IF EXISTS climbing.route_reference;
DROP TABLE IF EXISTS climbing.route_parking;
DROP TABLE IF EXISTS climbing.route_hazard;
DROP TABLE IF EXISTS climbing.route_guidebook;
DROP TABLE IF EXISTS climbing.route_grade;
DROP TABLE IF EXISTS climbing.route_feature;
DROP TABLE IF EXISTS climbing.route_discipline;
DROP TABLE IF EXISTS climbing.route_climatology;
DROP TABLE IF EXISTS climbing.route_character;
DROP TABLE IF EXISTS climbing.route;
DROP TABLE IF EXISTS climbing.rock_type;
DROP TABLE IF EXISTS climbing.provenance;
DROP TABLE IF EXISTS climbing.protection_grade;
DROP TABLE IF EXISTS climbing.pitch;
DROP TABLE IF EXISTS climbing.media;
DROP TABLE IF EXISTS climbing.incline;
DROP TABLE IF EXISTS climbing.hazard;
DROP TABLE IF EXISTS climbing.guidebook;
DROP TABLE IF EXISTS climbing.guide_section;
DROP TABLE IF EXISTS climbing.guide_route;
DROP TABLE IF EXISTS climbing.guide_edition;
DROP TABLE IF EXISTS climbing.guide;
DROP TABLE IF EXISTS climbing.grade_system;
DROP TABLE IF EXISTS climbing.grade_conversion;
DROP TABLE IF EXISTS climbing.first_ascent;
DROP TABLE IF EXISTS climbing.feature;
DROP TABLE IF EXISTS climbing.external_ref;
DROP TABLE IF EXISTS climbing.discipline;
DROP TABLE IF EXISTS climbing.crawl_frontier;
DROP TABLE IF EXISTS climbing.commitment_grade;
DROP TABLE IF EXISTS climbing."character";
DROP TABLE IF EXISTS climbing.ascent_style;
DROP VIEW IF EXISTS climbing.area_resolved;
DROP TABLE IF EXISTS climbing.area_reference;
DROP TABLE IF EXISTS climbing.area;
DROP FUNCTION IF EXISTS climbing.enforce_hazard_evidence();
DROP DOMAIN IF EXISTS climbing.aspect_dir;
DROP EXTENSION IF EXISTS postgis;
DROP EXTENSION IF EXISTS pg_trgm;
DROP SCHEMA IF EXISTS climbing;
--
-- Name: climbing; Type: SCHEMA; Schema: -; Owner: climbing
--

CREATE SCHEMA climbing;


ALTER SCHEMA climbing OWNER TO climbing;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: aspect_dir; Type: DOMAIN; Schema: climbing; Owner: climbing
--

CREATE DOMAIN climbing.aspect_dir AS text
	CONSTRAINT aspect_dir_check CHECK ((VALUE = ANY (ARRAY['N'::text, 'NE'::text, 'E'::text, 'SE'::text, 'S'::text, 'SW'::text, 'W'::text, 'NW'::text])));


ALTER DOMAIN climbing.aspect_dir OWNER TO climbing;

--
-- Name: enforce_hazard_evidence(); Type: FUNCTION; Schema: climbing; Owner: climbing
--

CREATE FUNCTION climbing.enforce_hazard_evidence() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF (SELECT h.safety_critical FROM hazard h WHERE h.code = NEW.hazard_code)
       AND (NEW.evidence_span IS NULL OR NEW.evidence_span = '') THEN
        RAISE EXCEPTION 'hazard % is safety-critical: evidence_span required', NEW.hazard_code
            USING ERRCODE = 'check_violation';
    END IF;
    RETURN NEW;
END $$;


ALTER FUNCTION climbing.enforce_hazard_evidence() OWNER TO climbing;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: area; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.area (
    id bigint NOT NULL,
    parent_id bigint,
    name text NOT NULL,
    kind text NOT NULL,
    grade_context text,
    rock_code text,
    aspect climbing.aspect_dir,
    timezone text,
    geom public.geography(Point,4326),
    access_notes text,
    CONSTRAINT area_kind_check CHECK ((kind = ANY (ARRAY['country'::text, 'region'::text, 'crag'::text, 'sector'::text])))
);


ALTER TABLE climbing.area OWNER TO climbing;

--
-- Name: area_id_seq; Type: SEQUENCE; Schema: climbing; Owner: climbing
--

ALTER TABLE climbing.area ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME climbing.area_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: area_reference; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.area_reference (
    id bigint NOT NULL,
    area_id bigint NOT NULL,
    title text NOT NULL,
    source_name text,
    url text NOT NULL,
    note text,
    verified_at date
);


ALTER TABLE climbing.area_reference OWNER TO climbing;

--
-- Name: area_reference_id_seq; Type: SEQUENCE; Schema: climbing; Owner: climbing
--

ALTER TABLE climbing.area_reference ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME climbing.area_reference_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: area_resolved; Type: VIEW; Schema: climbing; Owner: climbing
--

CREATE VIEW climbing.area_resolved AS
 WITH RECURSIVE anc AS (
         SELECT a.id,
            a.parent_id,
            a.name,
            a.kind,
            ARRAY[a.name] AS path_tokens,
            a.grade_context AS eff_grade_context,
            a.rock_code AS eff_rock_code,
            a.aspect AS eff_aspect,
            a.timezone AS eff_timezone
           FROM climbing.area a
          WHERE (a.parent_id IS NULL)
        UNION ALL
         SELECT c.id,
            c.parent_id,
            c.name,
            c.kind,
            (anc_1.path_tokens || c.name),
            COALESCE(c.grade_context, anc_1.eff_grade_context) AS "coalesce",
            COALESCE(c.rock_code, anc_1.eff_rock_code) AS "coalesce",
            COALESCE(c.aspect, anc_1.eff_aspect) AS "coalesce",
            COALESCE(c.timezone, anc_1.eff_timezone) AS "coalesce"
           FROM (climbing.area c
             JOIN anc anc_1 ON ((c.parent_id = anc_1.id)))
        )
 SELECT id,
    parent_id,
    name,
    kind,
    path_tokens,
    eff_grade_context,
    eff_rock_code,
    eff_aspect,
    eff_timezone
   FROM anc;


ALTER VIEW climbing.area_resolved OWNER TO climbing;

--
-- Name: ascent_style; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.ascent_style (
    code text NOT NULL,
    meaning text NOT NULL,
    is_modifier boolean DEFAULT false NOT NULL
);


ALTER TABLE climbing.ascent_style OWNER TO climbing;

--
-- Name: character; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing."character" (
    code text NOT NULL,
    meaning text NOT NULL
);


ALTER TABLE climbing."character" OWNER TO climbing;

--
-- Name: commitment_grade; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.commitment_grade (
    code text NOT NULL,
    system text NOT NULL,
    meaning text NOT NULL,
    CONSTRAINT commitment_grade_system_check CHECK ((system = ANY (ARRAY['NCCS'::text, 'IFAS'::text])))
);


ALTER TABLE climbing.commitment_grade OWNER TO climbing;

--
-- Name: crawl_frontier; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.crawl_frontier (
    id bigint NOT NULL,
    source_id text NOT NULL,
    external_id text NOT NULL,
    kind text NOT NULL,
    parent_frontier_id bigint,
    path text,
    corpus_area_id text,
    area_id bigint,
    route_id bigint,
    fetch_status text DEFAULT 'pending'::text NOT NULL,
    passes_filter boolean,
    tag_status text DEFAULT 'not_applicable'::text NOT NULL,
    flagged_fields text[],
    attempts smallint DEFAULT 0 NOT NULL,
    last_error text,
    claimed_at timestamp with time zone,
    last_attempted_at timestamp with time zone,
    fetched_at timestamp with time zone,
    tagged_at timestamp with time zone,
    raw_capture_path text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT crawl_frontier_fetch_status_check CHECK ((fetch_status = ANY (ARRAY['pending'::text, 'in_progress'::text, 'done'::text, 'failed'::text, 'skipped'::text]))),
    CONSTRAINT crawl_frontier_kind_check CHECK ((kind = ANY (ARRAY['area'::text, 'route'::text]))),
    CONSTRAINT crawl_frontier_tag_status_check CHECK ((tag_status = ANY (ARRAY['not_applicable'::text, 'pending'::text, 'in_progress'::text, 'done'::text, 'needs_review'::text, 'failed'::text])))
);


ALTER TABLE climbing.crawl_frontier OWNER TO climbing;

--
-- Name: crawl_frontier_id_seq; Type: SEQUENCE; Schema: climbing; Owner: climbing
--

ALTER TABLE climbing.crawl_frontier ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME climbing.crawl_frontier_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: discipline; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.discipline (
    code text NOT NULL,
    meaning text NOT NULL
);


ALTER TABLE climbing.discipline OWNER TO climbing;

--
-- Name: external_ref; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.external_ref (
    entity_type text NOT NULL,
    entity_id bigint NOT NULL,
    source_id text NOT NULL,
    external_id text NOT NULL,
    url text,
    CONSTRAINT external_ref_entity_type_check CHECK ((entity_type = ANY (ARRAY['route'::text, 'area'::text])))
);


ALTER TABLE climbing.external_ref OWNER TO climbing;

--
-- Name: feature; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.feature (
    code text NOT NULL,
    meaning text
);


ALTER TABLE climbing.feature OWNER TO climbing;

--
-- Name: first_ascent; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.first_ascent (
    route_id bigint NOT NULL,
    kind text NOT NULL,
    climber text,
    year smallint,
    style_code text,
    CONSTRAINT first_ascent_kind_check CHECK ((kind = ANY (ARRAY['fa'::text, 'ffa'::text])))
);


ALTER TABLE climbing.first_ascent OWNER TO climbing;

--
-- Name: grade_conversion; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.grade_conversion (
    grade_system_code text NOT NULL,
    original_grade text NOT NULL,
    data_grade smallint NOT NULL,
    CONSTRAINT grade_conversion_data_grade_check CHECK (((data_grade >= 1) AND (data_grade <= 7)))
);


ALTER TABLE climbing.grade_conversion OWNER TO climbing;

--
-- Name: grade_system; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.grade_system (
    code text NOT NULL,
    name text NOT NULL,
    region text,
    discipline text,
    example text
);


ALTER TABLE climbing.grade_system OWNER TO climbing;

--
-- Name: guide; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.guide (
    id bigint NOT NULL,
    slug text NOT NULL,
    title text NOT NULL,
    subtitle text,
    area_id bigint NOT NULL,
    series text,
    edition smallint DEFAULT 1 NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    intro_md text,
    access_md text,
    logistics_md text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT guide_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'review'::text, 'publish'::text])))
);


ALTER TABLE climbing.guide OWNER TO climbing;

--
-- Name: guide_edition; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.guide_edition (
    guide_id bigint NOT NULL,
    edition smallint NOT NULL,
    frozen jsonb NOT NULL,
    frozen_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE climbing.guide_edition OWNER TO climbing;

--
-- Name: guide_id_seq; Type: SEQUENCE; Schema: climbing; Owner: climbing
--

ALTER TABLE climbing.guide ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME climbing.guide_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: guide_route; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.guide_route (
    guide_id bigint NOT NULL,
    section_id bigint,
    route_id bigint NOT NULL,
    "position" integer NOT NULL,
    note_md text
);


ALTER TABLE climbing.guide_route OWNER TO climbing;

--
-- Name: guide_section; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.guide_section (
    id bigint NOT NULL,
    guide_id bigint NOT NULL,
    "position" integer NOT NULL,
    kind text NOT NULL,
    title text NOT NULL,
    body_md text,
    area_id bigint,
    CONSTRAINT guide_section_kind_check CHECK ((kind = ANY (ARRAY['essay'::text, 'sector'::text, 'logistics'::text])))
);


ALTER TABLE climbing.guide_section OWNER TO climbing;

--
-- Name: guide_section_id_seq; Type: SEQUENCE; Schema: climbing; Owner: climbing
--

ALTER TABLE climbing.guide_section ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME climbing.guide_section_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: guidebook; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.guidebook (
    id bigint NOT NULL,
    isbn text,
    title text NOT NULL,
    rrp text,
    img_url text,
    link text,
    kind text DEFAULT 'guidebook'::text NOT NULL,
    CONSTRAINT guidebook_kind_check CHECK ((kind = ANY (ARRAY['guidebook'::text, 'pdf'::text])))
);


ALTER TABLE climbing.guidebook OWNER TO climbing;

--
-- Name: guidebook_id_seq; Type: SEQUENCE; Schema: climbing; Owner: climbing
--

ALTER TABLE climbing.guidebook ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME climbing.guidebook_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: hazard; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.hazard (
    code text NOT NULL,
    kind text NOT NULL,
    meaning text NOT NULL,
    safety_critical boolean DEFAULT false NOT NULL,
    feeds text,
    CONSTRAINT hazard_kind_check CHECK ((kind = ANY (ARRAY['route'::text, 'objective'::text])))
);


ALTER TABLE climbing.hazard OWNER TO climbing;

--
-- Name: incline; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.incline (
    code text NOT NULL,
    sort_order smallint NOT NULL
);


ALTER TABLE climbing.incline OWNER TO climbing;

--
-- Name: media; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.media (
    id bigint NOT NULL,
    area_id bigint,
    kind text NOT NULL,
    uri text NOT NULL,
    width_px integer NOT NULL,
    height_px integer NOT NULL,
    credit text NOT NULL,
    license text DEFAULT 'owned'::text NOT NULL,
    permission_note text,
    taken_at date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT media_height_px_check CHECK ((height_px > 0)),
    CONSTRAINT media_kind_check CHECK ((kind = ANY (ARRAY['crag_photo'::text, 'approach'::text, 'map'::text, 'other'::text]))),
    CONSTRAINT media_license_check CHECK ((license = ANY (ARRAY['owned'::text, 'permission'::text, 'cc'::text]))),
    CONSTRAINT media_width_px_check CHECK ((width_px > 0))
);


ALTER TABLE climbing.media OWNER TO climbing;

--
-- Name: media_id_seq; Type: SEQUENCE; Schema: climbing; Owner: climbing
--

ALTER TABLE climbing.media ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME climbing.media_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: pitch; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.pitch (
    route_id bigint NOT NULL,
    number smallint NOT NULL,
    length_m integer,
    original_grade text,
    grade_system_code text,
    bolts_count integer,
    description text,
    CONSTRAINT pitch_number_check CHECK ((number >= 1))
);


ALTER TABLE climbing.pitch OWNER TO climbing;

--
-- Name: protection_grade; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.protection_grade (
    code text NOT NULL,
    meaning text NOT NULL,
    sort_order smallint
);


ALTER TABLE climbing.protection_grade OWNER TO climbing;

--
-- Name: provenance; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.provenance (
    id bigint NOT NULL,
    route_id bigint NOT NULL,
    field text NOT NULL,
    source_id text,
    source_url text,
    span text,
    confidence real,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT provenance_confidence_check CHECK (((confidence >= (0)::double precision) AND (confidence <= (1)::double precision)))
);


ALTER TABLE climbing.provenance OWNER TO climbing;

--
-- Name: provenance_id_seq; Type: SEQUENCE; Schema: climbing; Owner: climbing
--

ALTER TABLE climbing.provenance ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME climbing.provenance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rock_type; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.rock_type (
    code text NOT NULL,
    friction_dry real,
    seeps boolean DEFAULT false NOT NULL,
    fragile_when_wet boolean DEFAULT false NOT NULL,
    notes text
);


ALTER TABLE climbing.rock_type OWNER TO climbing;

--
-- Name: route; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.route (
    id bigint NOT NULL,
    area_id bigint NOT NULL,
    name text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    geom public.geography(Point,4326),
    timezone text,
    left_right_index integer,
    length_m integer,
    pitches_count smallint,
    rock_code text,
    incline_code text,
    aspect climbing.aspect_dir,
    grade_system_code text,
    original_grade text,
    trad_grade text,
    tech_grade text,
    data_grade smallint,
    protection_code text DEFAULT 'UNSPECIFIED'::text NOT NULL,
    protection_style text,
    belays text,
    commitment_code text,
    escapable boolean,
    approach_time_min smallint,
    approach_difficulty smallint,
    rack text,
    rope text,
    bolts_count integer,
    descent_method text,
    descent_abseils smallint,
    descent_notes text,
    elevation_m integer,
    sun_window_code text,
    wind_exposed boolean,
    best_season smallint[],
    stars smallint,
    intro_html text,
    approach_html text,
    pitch_info_html text,
    tile_image jsonb,
    topo jsonb,
    map_img jsonb,
    last_update timestamp with time zone DEFAULT now() NOT NULL,
    tagged_by text DEFAULT 'source'::text NOT NULL,
    tag_prov jsonb,
    curation_notes text,
    needs_field_check boolean DEFAULT false NOT NULL,
    curated_at timestamp with time zone,
    CONSTRAINT route_approach_difficulty_check CHECK (((approach_difficulty >= 1) AND (approach_difficulty <= 3))),
    CONSTRAINT route_belays_check CHECK ((belays = ANY (ARRAY['gear'::text, 'bolted'::text, 'mixed'::text]))),
    CONSTRAINT route_best_season_check CHECK ((best_season <@ ARRAY[(1)::smallint, (2)::smallint, (3)::smallint, (4)::smallint, (5)::smallint, (6)::smallint, (7)::smallint, (8)::smallint, (9)::smallint, (10)::smallint, (11)::smallint, (12)::smallint])),
    CONSTRAINT route_data_grade_check CHECK (((data_grade >= 1) AND (data_grade <= 7))),
    CONSTRAINT route_descent_method_check CHECK ((descent_method = ANY (ARRAY['walk-off'::text, 'abseil'::text, 'lower-off'::text]))),
    CONSTRAINT route_protection_style_check CHECK ((protection_style = ANY (ARRAY['gear'::text, 'bolted'::text, 'mixed'::text, 'none'::text]))),
    CONSTRAINT route_publish_needs_human_tags CHECK (((status <> 'publish'::text) OR (tagged_by = 'human'::text))),
    CONSTRAINT route_stars_check CHECK (((stars >= 0) AND (stars <= 3))),
    CONSTRAINT route_status_check CHECK ((status = ANY (ARRAY['publish'::text, 'draft'::text, 'quarantined'::text]))),
    CONSTRAINT route_tagged_by_check CHECK ((tagged_by = ANY (ARRAY['human'::text, 'llm'::text, 'source'::text])))
);


ALTER TABLE climbing.route OWNER TO climbing;

--
-- Name: route_character; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.route_character (
    route_id bigint NOT NULL,
    character_code text NOT NULL
);


ALTER TABLE climbing.route_character OWNER TO climbing;

--
-- Name: route_climatology; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.route_climatology (
    route_id bigint NOT NULL,
    month smallint NOT NULL,
    rainy_days real,
    temp_high real,
    temp_low real,
    CONSTRAINT route_climatology_month_check CHECK (((month >= 1) AND (month <= 12)))
);


ALTER TABLE climbing.route_climatology OWNER TO climbing;

--
-- Name: route_discipline; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.route_discipline (
    route_id bigint NOT NULL,
    discipline_code text NOT NULL
);


ALTER TABLE climbing.route_discipline OWNER TO climbing;

--
-- Name: route_feature; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.route_feature (
    route_id bigint NOT NULL,
    feature_code text NOT NULL
);


ALTER TABLE climbing.route_feature OWNER TO climbing;

--
-- Name: route_grade; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.route_grade (
    route_id bigint NOT NULL,
    grade_system_code text NOT NULL,
    value text NOT NULL
);


ALTER TABLE climbing.route_grade OWNER TO climbing;

--
-- Name: route_guidebook; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.route_guidebook (
    route_id bigint NOT NULL,
    guidebook_id bigint NOT NULL,
    page text,
    description text
);


ALTER TABLE climbing.route_guidebook OWNER TO climbing;

--
-- Name: route_hazard; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.route_hazard (
    route_id bigint NOT NULL,
    hazard_code text NOT NULL,
    evidence_span text,
    source_url text
);


ALTER TABLE climbing.route_hazard OWNER TO climbing;

--
-- Name: route_id_seq; Type: SEQUENCE; Schema: climbing; Owner: climbing
--

ALTER TABLE climbing.route ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME climbing.route_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: route_parking; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.route_parking (
    id bigint NOT NULL,
    route_id bigint NOT NULL,
    label text DEFAULT 'parking'::text NOT NULL,
    geom public.geography(Point,4326) NOT NULL,
    ord smallint DEFAULT 1 NOT NULL
);


ALTER TABLE climbing.route_parking OWNER TO climbing;

--
-- Name: route_parking_id_seq; Type: SEQUENCE; Schema: climbing; Owner: climbing
--

ALTER TABLE climbing.route_parking ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME climbing.route_parking_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: route_reference; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.route_reference (
    id bigint NOT NULL,
    route_id bigint NOT NULL,
    prefix text,
    text text NOT NULL,
    url text NOT NULL,
    CONSTRAINT route_reference_prefix_check CHECK ((prefix = ANY (ARRAY['Video'::text, 'Travel'::text, 'Article'::text, 'Info'::text, 'Tides'::text, 'Access'::text, 'Accommodation'::text])))
);


ALTER TABLE climbing.route_reference OWNER TO climbing;

--
-- Name: route_reference_id_seq; Type: SEQUENCE; Schema: climbing; Owner: climbing
--

ALTER TABLE climbing.route_reference ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME climbing.route_reference_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: route_resolved; Type: VIEW; Schema: climbing; Owner: climbing
--

CREATE VIEW climbing.route_resolved AS
 SELECT r.id,
    r.area_id,
    r.name,
    r.status,
    r.geom,
    r.timezone,
    r.left_right_index,
    r.length_m,
    r.pitches_count,
    r.rock_code,
    r.incline_code,
    r.aspect,
    r.grade_system_code,
    r.original_grade,
    r.trad_grade,
    r.tech_grade,
    r.data_grade,
    r.protection_code,
    r.protection_style,
    r.belays,
    r.commitment_code,
    r.escapable,
    r.approach_time_min,
    r.approach_difficulty,
    r.rack,
    r.rope,
    r.bolts_count,
    r.descent_method,
    r.descent_abseils,
    r.descent_notes,
    r.elevation_m,
    r.sun_window_code,
    r.wind_exposed,
    r.best_season,
    r.stars,
    r.intro_html,
    r.approach_html,
    r.pitch_info_html,
    r.tile_image,
    r.topo,
    r.map_img,
    r.last_update,
    r.tagged_by,
    r.tag_prov,
    r.curation_notes,
    r.needs_field_check,
    r.curated_at,
    ar.path_tokens,
    ar.eff_grade_context,
    COALESCE(r.rock_code, ar.eff_rock_code) AS eff_rock_code,
    COALESCE(r.aspect, ar.eff_aspect) AS eff_aspect,
    COALESCE(r.timezone, ar.eff_timezone) AS eff_timezone
   FROM (climbing.route r
     JOIN climbing.area_resolved ar ON ((ar.id = r.area_id)));


ALTER VIEW climbing.route_resolved OWNER TO climbing;

--
-- Name: source; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.source (
    id text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    method text,
    license text,
    tos text,
    regions text[],
    cadence text,
    teaches text
);


ALTER TABLE climbing.source OWNER TO climbing;

--
-- Name: sun_window; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.sun_window (
    code text NOT NULL,
    meaning text
);


ALTER TABLE climbing.sun_window OWNER TO climbing;

--
-- Name: topo; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.topo (
    id bigint NOT NULL,
    media_id bigint NOT NULL,
    area_id bigint,
    title text,
    belay_size integer DEFAULT 24 NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT topo_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'publish'::text])))
);


ALTER TABLE climbing.topo OWNER TO climbing;

--
-- Name: topo_id_seq; Type: SEQUENCE; Schema: climbing; Owner: climbing
--

ALTER TABLE climbing.topo ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME climbing.topo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: topo_line; Type: TABLE; Schema: climbing; Owner: climbing
--

CREATE TABLE climbing.topo_line (
    topo_id bigint NOT NULL,
    route_id bigint NOT NULL,
    line jsonb NOT NULL,
    pitches jsonb,
    descent jsonb,
    source_id text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE climbing.topo_line OWNER TO climbing;

--
-- Data for Name: area; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.area (id, parent_id, name, kind, grade_context, rock_code, aspect, timezone, geom, access_notes) FROM stdin;
1	\N	Scotland	country	GB	\N	\N	Europe/London	\N	\N
2	\N	Wales	country	GB	\N	\N	Europe/London	\N	\N
3	\N	England	country	GB	\N	\N	Europe/London	\N	\N
4	\N	Northern Ireland	country	GB	\N	\N	Europe/London	\N	\N
5	\N	Spain	country	ES	\N	\N	Europe/Madrid	\N	\N
6	\N	France	country	FR	\N	\N	Europe/Paris	\N	\N
7	\N	Croatia	country	HR	\N	\N	Europe/Zagreb	\N	\N
8	1	Assynt	region	\N	\N	\N	\N	\N	\N
9	2	Snowdonia	region	\N	\N	\N	\N	\N	\N
10	2	Gower	region	\N	\N	\N	\N	\N	\N
11	3	Lake District	region	\N	\N	\N	\N	\N	\N
12	4	Antrim	region	\N	\N	\N	\N	\N	\N
13	5	Sierra de Gredos	region	\N	\N	\N	\N	\N	\N
14	6	Écrins	region	\N	\N	\N	\N	\N	\N
15	7	Paklenica	region	\N	\N	\N	\N	\N	\N
16	8	Old Man of Stoer	sector	\N	sandstone	SE	\N	0101000020E61000008B6CE7FBA97115C01B2FDD2406214D40	\N
17	9	Idwal Slabs	sector	\N	rhyolite	NE	\N	0101000020E610000004560E2DB21D10C03BDF4F8D978E4A40	\N
18	10	Three Cliffs Bay	sector	\N	limestone	S	\N	0101000020E61000008B6CE7FBA97110C0295C8FC2F5C84940	\N
19	11	Gimmer Crag	sector	\N	volcanic	SW	\N	0101000020E61000004C37894160E508C0F0A7C64B37394B40	\N
20	12	Fair Head	sector	\N	dolerite	N	\N	0101000020E610000039B4C876BE9F18C023DBF97E6A9C4B40	\N
21	13	Los Galayos	sector	\N	granite	W	\N	0101000020E61000001904560E2DB214C0E17A14AE47214440	\N
22	14	Aiguille Dibona	sector	\N	granite	S	\N	0101000020E61000007F6ABC7493181940BA490C022B774640	\N
23	15	Anica Kuk	sector	\N	limestone	N	\N	0101000020E6100000AE47E17A14EE2E404A0C022B87264640	\N
24	20	The Small Crag	sector	\N	\N	\N	\N	\N	\N
26	20	Binnagapple Area	sector	\N	\N	\N	\N	\N	\N
34	20	Grey Man's Path East	sector	\N	\N	\N	\N	\N	\N
40	20	Grey Man's Path West	sector	\N	\N	\N	\N	\N	\N
49	20	The White Lightning Amphitheatre	sector	\N	\N	\N	\N	\N	\N
55	20	Bird Hide Block Area	sector	\N	\N	\N	\N	\N	\N
62	20	An Bealach Rúnda Area	sector	\N	\N	\N	\N	\N	\N
72	20	The Fang Area	sector	\N	\N	\N	\N	\N	\N
77	20	The Terraces	sector	\N	\N	\N	\N	\N	\N
91	20	Rathlin Wall Area	sector	\N	\N	\N	\N	\N	\N
111	20	The Wall of Prey	sector	\N	\N	\N	\N	\N	\N
117	20	Ballycastle Descent Gully East	sector	\N	\N	\N	\N	\N	\N
122	20	Ballycastle Descent Gully West	sector	\N	\N	\N	\N	\N	\N
124	20	The Prow	sector	\N	\N	\N	\N	\N	\N
125	20	Farrangandoo	sector	\N	\N	\N	\N	\N	\N
127	20	The Middle Crag	sector	\N	\N	\N	\N	\N	\N
128	20	Below the Main Crag	sector	\N	\N	\N	\N	\N	\N
129	20	Binnagapple	sector	\N	\N	\N	\N	\N	\N
130	20	Grey Man's Path	sector	\N	\N	\N	\N	\N	\N
131	20	Login to join in | theCrag	sector	\N	\N	\N	\N	\N	\N
135	20	Rathlin Wall	sector	\N	\N	\N	\N	\N	\N
141	20	Na Bolláin Rúnda	sector	\N	\N	\N	\N	\N	\N
142	20	Agent Orange Area	sector	\N	\N	\N	\N	\N	\N
145	20	Cockus Maximus and Beyond 1	sector	\N	\N	\N	\N	\N	\N
146	20	Cockus Maximus Area	sector	\N	\N	\N	\N	\N	\N
147	20	Eat It Area	sector	\N	\N	\N	\N	\N	\N
151	20	Murlough Bay Area	sector	\N	\N	\N	\N	\N	\N
152	20	Outlying Areas	sector	\N	\N	\N	\N	\N	\N
153	20	Shoreline Area	sector	\N	\N	\N	\N	\N	\N
154	20	Under Your Nose Area	sector	\N	\N	\N	\N	\N	\N
184	\N	Austria	country	\N	\N	\N	\N	\N	\N
185	\N	Belgium	country	\N	\N	\N	\N	\N	\N
186	\N	Bulgaria	country	\N	\N	\N	\N	\N	\N
187	\N	Canada	country	\N	\N	\N	\N	\N	\N
188	\N	Greece	country	\N	\N	\N	\N	\N	\N
189	\N	Hong Kong	country	\N	\N	\N	\N	\N	\N
190	\N	Ireland	country	\N	\N	\N	\N	\N	\N
191	\N	Italy	country	\N	\N	\N	\N	\N	\N
192	\N	Morocco	country	\N	\N	\N	\N	\N	\N
193	\N	Norway	country	\N	\N	\N	\N	\N	\N
194	\N	Portugal	country	\N	\N	\N	\N	\N	\N
195	\N	Switzerland	country	\N	\N	\N	\N	\N	\N
196	\N	USA	country	\N	\N	\N	\N	\N	\N
198	187	Alberta	region	\N	\N	\N	\N	\N	\N
199	1	Arran	region	\N	\N	\N	\N	\N	\N
200	191	Bolzano	region	\N	\N	\N	\N	\N	\N
201	3	Bristol	region	\N	\N	\N	\N	\N	\N
202	195	Canton of Glarus	region	\N	\N	\N	\N	\N	\N
203	5	Catalan	region	\N	\N	\N	\N	\N	\N
204	190	Co. Donegal	region	\N	\N	\N	\N	\N	\N
205	2	Conwy	region	\N	\N	\N	\N	\N	\N
206	3	Cornwall	region	\N	\N	\N	\N	\N	\N
207	5	Costa Blanca	region	\N	limestone	S	\N	0101000020E6100000EC51B81E85EBB13F713D0AD7A3504340	\N
208	4	County Down	region	\N	\N	\N	\N	\N	\N
209	3	Cumbria	region	\N	\N	\N	\N	\N	\N
210	191	Dolomites	region	\N	\N	\N	\N	\N	\N
211	190	Donegal	region	\N	\N	\N	\N	\N	\N
212	3	Gloucestershire	region	\N	\N	\N	\N	\N	\N
213	2	Gwynedd	region	\N	\N	\N	\N	\N	\N
214	6	Hautes-Alpes	region	\N	\N	\N	\N	\N	\N
215	192	Jebel el Kest	region	\N	\N	\N	\N	\N	\N
216	189	Kowloon	region	\N	\N	\N	\N	\N	\N
217	3	Lundy	region	\N	granite	W	\N	0101000020E61000008638D6C56DB412C04703780B24984940	\N
218	188	Meteora	region	\N	conglomerate	\N	\N	0101000020E6100000E17A14AE47A135405C8FC2F528DC4340	\N
219	4	Mourne and Down	region	\N	\N	\N	\N	\N	\N
220	193	Nordland	region	\N	\N	\N	\N	\N	\N
221	1	Orkney	region	\N	\N	\N	\N	\N	\N
222	194	Região do Norte	region	\N	\N	\N	\N	\N	\N
223	192	Souss-Massa	region	\N	\N	\N	\N	\N	\N
224	191	South Tyrol	region	\N	\N	\N	\N	\N	\N
225	192	Tafraout	region	\N	\N	\N	\N	\N	\N
226	5	Teneriffe	region	\N	\N	\N	\N	\N	\N
227	5	Valencia	region	\N	\N	\N	\N	\N	\N
228	186	Vratsa	region	\N	limestone	S	\N	0101000020E61000000F9C33A2B487374062A1D634EF984540	\N
229	185	Wallonia	region	\N	\N	\N	\N	\N	\N
230	196	Wyoming	region	\N	\N	\N	\N	\N	\N
231	\N	Aladaglar	crag	\N	limestone	\N	\N	0101000020E610000033333333339341406666666666E64240	\N
197	5	Alicante	region	\N	\N	\N	\N	\N	\N
232	215	Amzkhssan Wall	crag	\N	quartzite	S	\N	0101000020E610000079E92631080C22C00F9C33A2B4D73D40	\N
233	\N	Anti Atlas	crag	\N	quartzite	\N	\N	0101000020E6100000F6285C8FC2F521C0B81E85EB51B83D40	\N
234	201	Avon Gorge	crag	\N	limestone	\N	\N	0101000020E61000001B9E5E29CB1005C08716D9CEF7BB4940	\N
235	206	Bosigran	crag	\N	granite	W	\N	0101000020E6100000ECC039234A7B16C08351499D80164940	\N
236	202	Brüggler	crag	\N	limestone	S	\N	0101000020E61000004694F6065FF82140E5D022DBF98E4740	\N
237	219	Buzzards Roost	crag	\N	granite	SE	\N	0101000020E610000042CF66D5E7EA17C0A301BC0512144B40	\N
238	\N	Calanques	crag	\N	limestone	S	\N	0101000020E6100000CDCCCCCCCCCC15407B14AE47E19A4540	\N
239	\N	Campanile Basso	crag	\N	dolomite	\N	\N	0101000020E61000003D0AD7A370BD254014AE47E17A144740	\N
240	\N	Carcassonne	crag	\N	limestone	\N	\N	0101000020E6100000CDCCCCCCCCCC02407B14AE47E19A4540	\N
241	226	Cathedral Rock	crag	\N	basalt	E	\N	0101000020E6100000DF4F8D976EA230C0F0A7C64B37393C40	\N
242	206	Chair Ladder	crag	\N	granite	SW	\N	0101000020E6100000D1915CFE43BA16C0789CA223B9044940	\N
243	199	Cir Mhor	crag	\N	granite	S	\N	0101000020E61000006ADE718A8EE414C07DAEB6627FD14B40	\N
244	213	Clogwyn Dur Arddu	crag	\N	rhyolite	N	\N	0101000020E6100000AC1C5A643B5F10C052499D80268A4A40	\N
245	206	Cornakey Cliff	crag	\N	sandstone	S	\N	0101000020E610000099BB96900F3A12C0A1F831E6AE754940	\N
246	205	Cwm Cneifion	crag	\N	rhyolite	SW	\N	0101000020E610000031992A18951410C0A089B0E1E98D4A40	\N
247	213	Cwm Idwal	crag	\N	rhyolite	NW	\N	0101000020E6100000B4C876BE9F1A10C0A01A2FDD248E4A40	\N
249	\N	Devon	crag	\N	sandstone	\N	\N	0101000020E61000003D0AD7A3703D12C0F6285C8FC2754940	\N
250	213	Dinorwic Quarry	crag	\N	slate	SE	\N	0101000020E61000002E90A0F8316610C09CA223B9FC8F4A40	\N
251	191	Dolomites (Cortina)	crag	\N	limestone	\N	\N	0101000020E6100000A01A2FDD2446284085EB51B81E454740	\N
252	190	Donegal (Sail Rock)	crag	\N	quartzite	W	\N	0101000020E61000001F85EB51B85E21C0E3A59BC420504B40	\N
253	219	Eagle Mountain	crag	\N	granite	NE	\N	0101000020E6100000B30C71AC8B5B18C01AC05B2041114B40	\N
254	184	East Tyrol (Lienz)	crag	\N	limestone	\N	\N	0101000020E61000007D3F355EBA892940273108AC1C6A4740	\N
255	197	El Castellet	crag	\N	limestone	S	\N	0101000020E6100000C4B12E6EA301C4BFB81E85EB51504340	\N
256	\N	Elbsandstein	crag	\N	sandstone	\N	\N	0101000020E61000001F85EB51B81E2C4014AE47E17A744940	\N
257	4	Fair Head, NI	crag	\N	dolerite	N	\N	0101000020E610000039B4C876BE9F18C023DBF97E6A9C4B40	\N
258	229	Freÿr	crag	\N	limestone	W	\N	0101000020E6100000FFB27BF2B0901340772D211FF41C4940	\N
259	224	Grande Fermeda	crag	\N	dolomite	S	\N	0101000020E61000001895D409688227404D158C4AEA4C4740	\N
260	10	Great Tor	crag	\N	limestone	SE	\N	0101000020E61000005AF5B9DA8A7D10C0F085C954C1C84940	\N
261	\N	Gredos	crag	\N	granite	W	\N	0101000020E6100000AE47E17A14AE14C0C3F5285C8F224440	\N
262	218	Heiliger Geist	crag	\N	conglomerate	E	\N	0101000020E6100000C66D3480B7A03540C0EC9E3C2CDC4340	\N
263	225	High Sierra Dome	crag	\N	granite	S	\N	0101000020E61000003255302AA9F321C051DA1B7C61B23D40	\N
264	\N	Hoy	crag	\N	sandstone	W	\N	0101000020E6100000713D0AD7A3700BC0713D0AD7A3704D40	\N
265	\N	Isle Of White	crag	\N	chalk	\N	\N	0101000020E6100000CDCCCCCCCCCCF4BF14AE47E17A544940	\N
266	1	Isle of Arran	crag	\N	granite	\N	\N	0101000020E6100000CDCCCCCCCCCC14C0FED478E926D14B40	\N
267	223	Ksar Rock	crag	\N	quartzite	SE	\N	0101000020E6100000E0BE0E9C332222C08E75711B0DD03D40	\N
268	3	Lake District (Borrowdale)	crag	\N	volcanic	\N	\N	0101000020E6100000A01A2FDD240609C0D9CEF753E3454B40	\N
269	216	Lion Rock	crag	\N	granite	W	\N	0101000020E610000007CE1951DA8B5C4060764F1E165A3640	\N
270	213	Lliwedd	crag	\N	rhyolite	N	\N	0101000020E61000008104C58F313710C00F9C33A2B4874A40	\N
271	\N	Loften	crag	\N	granite	\N	\N	0101000020E61000003333333333332B4048E17A14AE075140	\N
272	215	Lower Eagle Crag	crag	\N	quartzite	NE	\N	0101000020E6100000FE43FAEDEB2022C0744694F606CF3D40	\N
273	\N	Mallorca	crag	\N	limestone	\N	\N	0101000020E6100000295C8FC2F52806405C8FC2F528DC4340	\N
274	222	Meadinha	crag	\N	granite	SE	\N	0101000020E6100000DE718A8EE47220C0A245B6F3FDFC4440	\N
275	\N	Medina	crag	\N	granite	\N	\N	0101000020E6100000AE47E17A14CE4340B81E85EB51783840	\N
276	\N	Mont Blonc	crag	\N	granite	\N	\N	0101000020E61000008FC2F5285C8F1B40713D0AD7A3F04640	\N
277	\N	Montserrat	crag	\N	conglomerate	\N	\N	0101000020E6100000F6285C8FC2F5FC3FCDCCCCCCCCCC4440	\N
278	198	Mount Indefatigable	crag	\N	limestone	\N	\N	0101000020E61000006D567DAEB6CA5CC09A99999999514940	\N
279	4	Mournes, NI	crag	\N	granite	\N	\N	0101000020E610000000000000000018C03333333333134B40	\N
280	221	Old Man of Hoy	crag	\N	sandstone	E	\N	0101000020E61000008B6CE7FBA9710BC0D3BCE3141D714D40	\N
281	7	Paklenica (Anica Kuk)	crag	\N	limestone	N	\N	0101000020E6100000EC51B81E85EB2E4048E17A14AE274640	\N
282	207	Penya Roc	crag	\N	limestone	NE	\N	0101000020E6100000C364AA605452C7BFE17A14AE47514340	\N
283	207	Peñón de Ifach	crag	\N	limestone	S	\N	0101000020E6100000BEC117265305B33F9A779CA223514340	\N
284	5	Picos de Europa	crag	\N	limestone	\N	\N	0101000020E610000062105839B44813C07D3F355EBA994540	\N
285	219	Pigeon Rock	crag	\N	granite	E	\N	0101000020E610000055C1A8A44E4018C098DD938785124B40	\N
286	227	Puig Campana	crag	\N	limestone	S	\N	0101000020E61000003BDF4F8D976ECABF6C09F9A0674B4340	\N
287	\N	Riglos	crag	\N	conglomerate	S	\N	0101000020E61000005C8FC2F5285CE7BFCDCCCCCCCC2C4540	\N
288	203	Roca Gris	crag	\N	conglomerate	S	\N	0101000020E61000000AD7A3703D0AFD3F41F163CC5DCB4440	\N
289	204	Sail Rock	crag	\N	quartzite	\N	\N	0101000020E61000003B70CE88D25E21C0AA60545227504B40	\N
290	210	Sass Pordoi	crag	\N	dolomite	NW	\N	0101000020E6100000423EE8D9AC9A2740D50968226C404740	\N
291	224	Sass Pordoi South Face	crag	\N	dolomite	S	\N	0101000020E610000004560E2DB29D274080B74082E23F4740	\N
292	209	Scafell	crag	\N	rhyolite	N	\N	0101000020E61000006C787AA52CC309C05227A089B0394B40	\N
293	224	Sella Towers	crag	\N	dolomite	SW	\N	0101000020E6100000234A7B832F8C2740613255302A414740	\N
294	\N	Setesdal	crag	\N	granite	\N	\N	0101000020E61000009A99999999991D403333333333734D40	\N
295	\N	Sicilly	crag	\N	limestone	\N	\N	0101000020E61000007B14AE47E17A2940F6285C8FC2154340	\N
296	208	Slieve Beg	crag	\N	granite	SW	\N	0101000020E610000043AD69DE71CA17C01E166A4DF3164B40	\N
297	219	Slieve Lamagan	crag	\N	granite	SE	\N	0101000020E6100000637FD93D79D817C06ADE718A8E144B40	\N
298	2	Snowdonia (Llanberis Pass)	crag	\N	rhyolite	\N	\N	0101000020E610000079E92631082C10C077BE9F1A2F8D4A40	\N
299	\N	Spitzkoppe	crag	\N	granite	\N	\N	0101000020E6100000E17A14AE47612E4014AE47E17AD435C0	\N
300	220	Stetind	crag	\N	granite	\N	\N	0101000020E610000048BF7D1D3897304066666666660A5140	\N
301	193	Stetind (Norway)	crag	\N	granite	\N	\N	0101000020E61000009EEFA7C64B973040EE7C3F355E0A5140	\N
302	\N	Tenerife	crag	\N	volcanic	\N	\N	0101000020E6100000A4703D0AD7A330C085EB51B81E453C40	\N
303	230	The Devils Tower	crag	\N	volcanic	S	\N	0101000020E61000000BB5A679C72D5AC0C139234A7B4B4640	\N
304	211	Tormore Group	crag	\N	quartzite	E	\N	0101000020E6100000C3D32B65196221C08CDB68006F614B40	\N
305	\N	Triglav	crag	\N	limestone	\N	\N	0101000020E6100000AE47E17A14AE2B40713D0AD7A3304740	\N
306	205	Tryfan	crag	\N	rhyolite	E	\N	0101000020E61000004CA60A4625F50FC074B515FBCB8E4A40	\N
307	200	Vajolet towers	crag	\N	dolomite	SW	\N	0101000020E610000039B4C876BE3F2740098A1F63EE3A4740	\N
308	\N	Wadi Rum	crag	\N	sandstone	\N	\N	0101000020E6100000F6285C8FC2B5414052B81E85EB913D40	\N
309	3	West Cornwall (Bosigran)	crag	\N	granite	NW	\N	0101000020E61000007B14AE47E17A16C04A0C022B87164940	\N
310	212	Wintours Leap	crag	\N	limestone	\N	\N	0101000020E6100000C6DCB5847C5005C0BE30992A18D54940	\N
311	\N	Zadiel	crag	\N	limestone	\N	\N	0101000020E610000014AE47E17AD434408FC2F5285C4F4840	\N
312	6	Écrins (Aiguille Dibona)	crag	\N	granite	\N	\N	0101000020E610000060E5D022DBF918405EBA490C027B4640	\N
318	219	North Tor, Slieve Binnian	crag	GB	granite	NE	Europe/London	\N	\N
\.


--
-- Data for Name: area_reference; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.area_reference (id, area_id, title, source_name, url, note, verified_at) FROM stdin;
\.


--
-- Data for Name: ascent_style; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.ascent_style (code, meaning, is_modifier) FROM stdin;
onsight	Lead first try, clean, no prior beta.	f
flash	Lead first try, clean, with prior beta.	f
redpoint	Clean lead after rehearsal.	f
pinkpoint	Redpoint with gear pre-placed (now usually folded into redpoint).	f
headpoint	Trad: clean lead after top-rope practice.	f
groundup	Attempted from the ground up, no top-rope rehearsal.	f
second	Climbed after the leader, roped from above.	f
toprope	Climbed on a rope anchored above.	f
solo	Climbed with no rope.	f
aid	Weighting gear to make upward progress.	f
clean	Modifier: no falls, no resting on gear.	t
dog	Modifier: worked the route resting on gear (hangdog).	t
\.


--
-- Data for Name: character; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing."character" (code, meaning) FROM stdin;
sustained	Lots of hard moves with little respite (Rockfax "s").
pumpy	Steep endurance climbing — the pump is the crux.
powerful	Demands strength on steep ground (Rockfax "p").
technical	Intricate movement; body position over pulling.
fingery	Significant small holds on the hard sections (Rockfax "f").
crimpy	Specifically small-edge crimping.
reachy	Move spans favour reach; height-dependent.
delicate	Balance/friction climbing; precision under little security.
exposed	Big-air positions beyond what the protection grade captures.
rounded	Rounded, sloping holds and breaks (gritstone-style) — Rockfax symbol; friction- and humidity-sensitive.
fluttery	Bold, heady climbing — spaced or marginal gear above hard moves (the Rockfax heart symbol; UK climbers say "bold").
\.


--
-- Data for Name: commitment_grade; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.commitment_grade (code, system, meaning) FROM stdin;
I	NCCS	A couple of hours.
II	NCCS	A few hours.
III	NCCS	Most of a morning.
IV	NCCS	A full day.
V	NCCS	Long day / possible bivvy.
VI	NCCS	Multi-day.
VII	NCCS	Remote multi-day big-wall.
F	IFAS	Facile — easy.
PD	IFAS	Peu difficile.
AD	IFAS	Assez difficile.
D	IFAS	Difficile.
TD	IFAS	Très difficile.
ED	IFAS	Extrêmement difficile.
ABO	IFAS	Abominable — beyond ED.
\.


--
-- Data for Name: crawl_frontier; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.crawl_frontier (id, source_id, external_id, kind, parent_frontier_id, path, corpus_area_id, area_id, route_id, fetch_status, passes_filter, tag_status, flagged_fields, attempts, last_error, claimed_at, last_attempted_at, fetched_at, tagged_at, raw_capture_path, created_at) FROM stdin;
26	ukclimbing	52580	route	1	\N	fair-head	40	32	done	\N	needs_review	{protection,character,feature}	0	\N	\N	2026-07-07 06:35:54.914495+00	2026-07-06 21:10:28.573806+00	2026-07-07 06:38:02.03806+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52580.json	2026-07-06 21:10:28.573806+00
27	ukclimbing	52581	route	1	\N	fair-head	40	33	done	\N	needs_review	{protection,character,feature}	0	\N	\N	2026-07-07 06:35:54.914495+00	2026-07-06 21:10:28.598929+00	2026-07-07 06:38:02.049875+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52581.json	2026-07-06 21:10:28.598929+00
60	ukclimbing	547464	route	1	\N	fair-head	77	66	done	\N	done	\N	0	\N	\N	2026-07-07 18:06:58.216894+00	2026-07-06 21:10:29.298184+00	2026-07-07 18:09:00.972692+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/547464.json	2026-07-06 21:10:29.298184+00
28	ukclimbing	162668	route	1	\N	fair-head	49	34	done	\N	needs_review	{protection,character}	0	\N	\N	2026-07-07 06:35:54.914495+00	2026-07-06 21:10:28.62369+00	2026-07-07 06:38:02.067796+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/162668.json	2026-07-06 21:10:28.62369+00
133	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834370709	area	2	Northern Ireland > Antrim > Fair Head > Under Your Nose Area	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:15:15.354019+00	2026-07-06 21:15:15.354019+00	2026-07-06 21:15:41.017539+00	\N	\N	2026-07-06 21:11:03.047212+00
134	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834331811/locate	area	2	Northern Ireland > Antrim > Fair Head > 1	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:15:15.354019+00	2026-07-06 21:15:15.354019+00	2026-07-06 21:15:57.256325+00	\N	\N	2026-07-06 21:11:03.05205+00
29	ukclimbing	38805	route	1	\N	fair-head	49	35	done	\N	needs_review	{protection,character,feature}	0	\N	\N	2026-07-07 06:35:54.914495+00	2026-07-06 21:10:28.645022+00	2026-07-07 06:38:02.07909+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/38805.json	2026-07-06 21:10:28.645022+00
30	ukclimbing	224056	route	1	\N	fair-head	49	36	done	\N	needs_review	{protection_style,belays}	0	\N	\N	2026-07-07 06:35:54.914495+00	2026-07-06 21:10:28.666552+00	2026-07-07 06:38:02.107747+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/224056.json	2026-07-06 21:10:28.666552+00
62	ukclimbing	53212	route	1	\N	fair-head	77	68	done	\N	done	\N	0	\N	\N	2026-07-07 18:06:58.216894+00	2026-07-06 21:10:29.337914+00	2026-07-07 18:09:01.024619+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53212.json	2026-07-06 21:10:29.337914+00
172	thecrag	7834192530	route	108	\N	fair-head	129	120	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 06:38:03.717876+00	2026-07-06 21:11:37.247411+00	2026-07-07 06:38:25.313824+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834192530.json	2026-07-06 21:11:37.247411+00
63	ukclimbing	590044	route	1	\N	fair-head	77	69	done	\N	done	\N	0	\N	\N	2026-07-07 18:06:58.216894+00	2026-07-06 21:10:29.357279+00	2026-07-07 18:09:01.056474+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/590044.json	2026-07-06 21:10:29.357279+00
64	ukclimbing	53213	route	1	\N	fair-head	77	70	done	\N	done	\N	0	\N	\N	2026-07-07 18:06:58.216894+00	2026-07-06 21:10:29.378259+00	2026-07-07 18:09:01.074654+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53213.json	2026-07-06 21:10:29.378259+00
65	ukclimbing	53217	route	1	\N	fair-head	77	71	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:06:58.216894+00	2026-07-06 21:10:29.401999+00	2026-07-07 18:09:01.083529+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53217.json	2026-07-06 21:10:29.401999+00
36	ukclimbing	226502	route	1	\N	fair-head	55	42	done	\N	done	\N	0	\N	\N	2026-07-07 18:02:18.877115+00	2026-07-06 21:10:28.791488+00	2026-07-07 18:04:18.180415+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/226502.json	2026-07-06 21:10:28.791488+00
73	ukclimbing	53325	route	1	\N	fair-head	91	79	done	\N	done	\N	0	\N	\N	2026-07-07 18:09:01.09559+00	2026-07-06 21:10:29.586257+00	2026-07-07 18:09:13.232488+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53325.json	2026-07-06 21:10:29.586257+00
75	ukclimbing	168292	route	1	\N	fair-head	91	81	done	\N	done	\N	0	\N	\N	2026-07-07 18:09:01.09559+00	2026-07-06 21:10:29.629465+00	2026-07-07 18:09:13.27437+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/168292.json	2026-07-06 21:10:29.629465+00
78	ukclimbing	53341	route	1	\N	fair-head	91	84	done	\N	done	\N	0	\N	\N	2026-07-07 18:09:13.288451+00	2026-07-06 21:10:29.692383+00	2026-07-07 18:10:50.04124+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53341.json	2026-07-06 21:10:29.692383+00
1	ukclimbing	https://www.ukclimbing.com/logbook/crags/fair_head-17029/	area	\N	Northern Ireland > Antrim > Fair Head	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:10:21.334899+00	2026-07-06 21:10:21.334899+00	2026-07-06 21:10:30.24648+00	\N	\N	2026-07-06 21:10:14.237299+00
8	ukclimbing	36923	route	1	\N	fair-head	26	14	done	\N	done	\N	0	\N	\N	2026-07-07 06:31:38.222536+00	2026-07-06 21:10:28.182708+00	2026-07-07 06:33:31.902203+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/36923.json	2026-07-06 21:10:28.182708+00
9	ukclimbing	379551	route	1	\N	fair-head	26	15	done	\N	done	\N	0	\N	\N	2026-07-07 06:31:38.222536+00	2026-07-06 21:10:28.205113+00	2026-07-07 06:33:31.956805+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/379551.json	2026-07-06 21:10:28.205113+00
2	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head	area	\N	Northern Ireland > Antrim > Fair Head	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:10:56.609923+00	2026-07-06 21:10:56.609923+00	2026-07-06 21:11:03.194664+00	\N	\N	2026-07-06 21:10:14.237299+00
16	ukclimbing	116391	route	1	\N	fair-head	34	22	done	\N	needs_review	{protection,character,feature,hazards}	0	\N	\N	2026-07-07 06:33:32.160109+00	2026-07-06 21:10:28.352271+00	2026-07-07 06:35:54.68084+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/116391.json	2026-07-06 21:10:28.352271+00
17	ukclimbing	52556	route	1	\N	fair-head	34	23	done	\N	needs_review	{protection,character,feature,hazards}	0	\N	\N	2026-07-07 06:33:32.160109+00	2026-07-06 21:10:28.372918+00	2026-07-07 06:35:54.696775+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52556.json	2026-07-06 21:10:28.372918+00
18	ukclimbing	629938	route	1	\N	fair-head	34	24	done	\N	done	\N	0	\N	\N	2026-07-07 06:33:32.160109+00	2026-07-06 21:10:28.396937+00	2026-07-07 06:35:54.731566+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/629938.json	2026-07-06 21:10:28.396937+00
19	ukclimbing	52574	route	1	\N	fair-head	40	25	done	\N	needs_review	{protection,character,feature,hazards}	0	\N	\N	2026-07-07 06:33:32.160109+00	2026-07-06 21:10:28.422512+00	2026-07-07 06:35:54.742419+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52574.json	2026-07-06 21:10:28.422512+00
20	ukclimbing	36944	route	1	\N	fair-head	40	26	done	\N	needs_review	{protection,character,feature,hazards}	0	\N	\N	2026-07-07 06:33:32.160109+00	2026-07-06 21:10:28.444238+00	2026-07-07 06:35:54.754933+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/36944.json	2026-07-06 21:10:28.444238+00
56	ukclimbing	489387	route	1	\N	fair-head	77	62	done	\N	done	\N	0	\N	\N	2026-07-07 18:06:58.216894+00	2026-07-06 21:10:29.211081+00	2026-07-07 18:09:00.874158+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/489387.json	2026-07-06 21:10:29.211081+00
57	ukclimbing	453856	route	1	\N	fair-head	77	63	done	\N	done	\N	0	\N	\N	2026-07-07 18:06:58.216894+00	2026-07-06 21:10:29.230543+00	2026-07-07 18:09:00.897173+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/453856.json	2026-07-06 21:10:29.230543+00
58	ukclimbing	487552	route	1	\N	fair-head	77	64	done	\N	done	\N	0	\N	\N	2026-07-07 18:06:58.216894+00	2026-07-06 21:10:29.25181+00	2026-07-07 18:09:00.932015+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/487552.json	2026-07-06 21:10:29.25181+00
59	ukclimbing	53209	route	1	\N	fair-head	77	65	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:06:58.216894+00	2026-07-06 21:10:29.275177+00	2026-07-07 18:09:00.942919+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53209.json	2026-07-06 21:10:29.275177+00
212	thecrag	7834356339	route	113	\N	fair-head	77	63	done	\N	needs_review	{protection,hazards,character,feature,incline}	0	\N	\N	2026-07-07 18:15:40.680978+00	2026-07-06 21:12:20.650785+00	2026-07-07 18:16:15.663657+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834356339.json	2026-07-06 21:12:20.650785+00
219	thecrag	7834360146	route	113	\N	fair-head	77	71	done	\N	needs_review	{protection,protection_style,belays,character,feature,incline}	0	\N	\N	2026-07-07 18:16:15.678415+00	2026-07-06 21:12:20.774499+00	2026-07-07 18:16:28.958616+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834360146.json	2026-07-06 21:12:20.774499+00
66	ukclimbing	53218	route	1	\N	fair-head	77	72	done	\N	done	\N	0	\N	\N	2026-07-07 18:09:01.09559+00	2026-07-06 21:10:29.4286+00	2026-07-07 18:09:13.140686+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53218.json	2026-07-06 21:10:29.4286+00
67	ukclimbing	53221	route	1	\N	fair-head	77	73	done	\N	done	\N	0	\N	\N	2026-07-07 18:09:01.09559+00	2026-07-06 21:10:29.455912+00	2026-07-07 18:09:13.151846+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53221.json	2026-07-06 21:10:29.455912+00
68	ukclimbing	53222	route	1	\N	fair-head	77	74	done	\N	done	\N	0	\N	\N	2026-07-07 18:09:01.09559+00	2026-07-06 21:10:29.479361+00	2026-07-07 18:09:13.164424+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53222.json	2026-07-06 21:10:29.479361+00
69	ukclimbing	53320	route	1	\N	fair-head	77	75	done	\N	done	\N	0	\N	\N	2026-07-07 18:09:01.09559+00	2026-07-06 21:10:29.499867+00	2026-07-07 18:09:13.174316+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53320.json	2026-07-06 21:10:29.499867+00
70	ukclimbing	53321	route	1	\N	fair-head	91	76	done	\N	done	\N	0	\N	\N	2026-07-07 18:09:01.09559+00	2026-07-06 21:10:29.522378+00	2026-07-07 18:09:13.183645+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53321.json	2026-07-06 21:10:29.522378+00
71	ukclimbing	116388	route	1	\N	fair-head	91	77	done	\N	done	\N	0	\N	\N	2026-07-07 18:09:01.09559+00	2026-07-06 21:10:29.543848+00	2026-07-07 18:09:13.198766+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/116388.json	2026-07-06 21:10:29.543848+00
72	ukclimbing	53322	route	1	\N	fair-head	91	78	done	\N	done	\N	0	\N	\N	2026-07-07 18:09:01.09559+00	2026-07-06 21:10:29.564567+00	2026-07-07 18:09:13.209065+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53322.json	2026-07-06 21:10:29.564567+00
220	thecrag	7834360377	route	113	\N	fair-head	77	72	done	\N	needs_review	{protection,protection_style,belays,character,feature,incline}	0	\N	\N	2026-07-07 18:16:15.678415+00	2026-07-06 21:12:20.791241+00	2026-07-07 18:16:28.968952+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834360377.json	2026-07-06 21:12:20.791241+00
79	ukclimbing	53342	route	1	\N	fair-head	91	85	done	\N	done	\N	0	\N	\N	2026-07-07 18:09:13.288451+00	2026-07-06 21:10:29.711854+00	2026-07-07 18:10:50.050611+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53342.json	2026-07-06 21:10:29.711854+00
80	ukclimbing	343328	route	1	\N	fair-head	91	86	done	\N	needs_review	{protection_style,belays}	0	\N	\N	2026-07-07 18:09:13.288451+00	2026-07-06 21:10:29.730555+00	2026-07-07 18:10:50.08565+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/343328.json	2026-07-06 21:10:29.730555+00
81	ukclimbing	53343	route	1	\N	fair-head	91	87	done	\N	done	\N	0	\N	\N	2026-07-07 18:09:13.288451+00	2026-07-06 21:10:29.753128+00	2026-07-07 18:10:50.104649+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53343.json	2026-07-06 21:10:29.753128+00
82	ukclimbing	468618	route	1	\N	fair-head	91	88	done	\N	needs_review	{protection_style,belays}	0	\N	\N	2026-07-07 18:09:13.288451+00	2026-07-06 21:10:29.777319+00	2026-07-07 18:10:50.149423+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/468618.json	2026-07-06 21:10:29.777319+00
83	ukclimbing	772861	route	1	\N	fair-head	91	89	done	\N	needs_review	{protection_style,belays}	0	\N	\N	2026-07-07 18:09:13.288451+00	2026-07-06 21:10:29.800081+00	2026-07-07 18:10:50.17336+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/772861.json	2026-07-06 21:10:29.800081+00
46	ukclimbing	676918	route	1	\N	fair-head	62	52	done	\N	done	\N	0	\N	\N	2026-07-07 18:04:18.446599+00	2026-07-06 21:10:28.994778+00	2026-07-07 18:06:58.023726+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/676918.json	2026-07-06 21:10:28.994778+00
47	ukclimbing	38825	route	1	\N	fair-head	62	53	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:04:18.446599+00	2026-07-06 21:10:29.014815+00	2026-07-07 18:06:58.03347+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/38825.json	2026-07-06 21:10:29.014815+00
48	ukclimbing	38806	route	1	\N	fair-head	62	54	done	\N	needs_review	{protection,incline}	0	\N	\N	2026-07-07 18:04:18.446599+00	2026-07-06 21:10:29.035022+00	2026-07-07 18:06:58.076778+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/38806.json	2026-07-06 21:10:29.035022+00
49	ukclimbing	52881	route	1	\N	fair-head	62	55	done	\N	needs_review	{character,feature,incline}	0	\N	\N	2026-07-07 18:04:18.446599+00	2026-07-06 21:10:29.055639+00	2026-07-07 18:06:58.086886+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52881.json	2026-07-06 21:10:29.055639+00
50	ukclimbing	52882	route	1	\N	fair-head	62	56	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:04:18.446599+00	2026-07-06 21:10:29.079342+00	2026-07-07 18:06:58.098466+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52882.json	2026-07-06 21:10:29.079342+00
51	ukclimbing	52883	route	1	\N	fair-head	72	57	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:04:18.446599+00	2026-07-06 21:10:29.103072+00	2026-07-07 18:06:58.108855+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52883.json	2026-07-06 21:10:29.103072+00
52	ukclimbing	52884	route	1	\N	fair-head	72	58	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:04:18.446599+00	2026-07-06 21:10:29.124905+00	2026-07-07 18:06:58.118414+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52884.json	2026-07-06 21:10:29.124905+00
53	ukclimbing	52885	route	1	\N	fair-head	72	59	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:04:18.446599+00	2026-07-06 21:10:29.146571+00	2026-07-07 18:06:58.127676+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52885.json	2026-07-06 21:10:29.146571+00
217	thecrag	7834358880	route	113	\N	fair-head	77	69	done	\N	needs_review	{protection,protection_style,belays,character,feature,incline}	0	\N	\N	2026-07-07 18:16:15.678415+00	2026-07-06 21:12:20.736812+00	2026-07-07 18:16:28.933033+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834358880.json	2026-07-06 21:12:20.736812+00
218	thecrag	7834359126	route	113	\N	fair-head	77	70	done	\N	needs_review	{protection,protection_style,belays,character,feature,incline}	0	\N	\N	2026-07-07 18:16:15.678415+00	2026-07-06 21:12:20.756599+00	2026-07-07 18:16:28.943878+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834359126.json	2026-07-06 21:12:20.756599+00
221	thecrag	7834361415	route	113	\N	fair-head	77	73	done	\N	needs_review	{protection,protection_style,belays,character,feature,incline}	0	\N	\N	2026-07-07 18:16:15.678415+00	2026-07-06 21:12:20.810047+00	2026-07-07 18:16:28.978212+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834361415.json	2026-07-06 21:12:20.810047+00
222	thecrag	7834361709	route	113	\N	fair-head	77	74	done	\N	needs_review	{protection,protection_style,belays,character,feature,incline}	0	\N	\N	2026-07-07 18:16:15.678415+00	2026-07-06 21:12:20.829749+00	2026-07-07 18:16:28.988461+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834361709.json	2026-07-06 21:12:20.829749+00
228	thecrag	7816371936	route	114	\N	fair-head	135	176	done	\N	done	\N	0	\N	\N	2026-07-07 18:16:29.002685+00	2026-07-06 21:12:28.412524+00	2026-07-07 18:16:45.429056+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7816371936.json	2026-07-06 21:12:28.412524+00
229	thecrag	7816386375	route	114	\N	fair-head	135	177	done	\N	done	\N	0	\N	\N	2026-07-07 18:16:29.002685+00	2026-07-06 21:12:28.426148+00	2026-07-07 18:16:45.439021+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7816386375.json	2026-07-06 21:12:28.426148+00
74	ukclimbing	168293	route	1	\N	fair-head	91	80	done	\N	done	\N	0	\N	\N	2026-07-07 18:09:01.09559+00	2026-07-06 21:10:29.608269+00	2026-07-07 18:09:13.242497+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/168293.json	2026-07-06 21:10:29.608269+00
3	ukclimbing	420411	route	1	\N	fair-head	24	9	done	\N	needs_review	{protection_style,feature:arete}	1		\N	2026-07-07 06:28:55.654418+00	2026-07-06 21:10:28.060428+00	2026-07-07 06:30:35.442193+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/420411.json	2026-07-06 21:10:28.060428+00
7	ukclimbing	51514	route	1	\N	fair-head	26	13	done	\N	done	\N	0	\N	\N	2026-07-07 06:31:38.222536+00	2026-07-06 21:10:28.155922+00	2026-07-07 06:33:32.123314+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/51514.json	2026-07-06 21:10:28.155922+00
38	ukclimbing	53713	route	1	\N	fair-head	55	44	done	\N	done	\N	0	\N	\N	2026-07-07 18:02:18.877115+00	2026-07-06 21:10:28.833842+00	2026-07-07 18:04:18.21575+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53713.json	2026-07-06 21:10:28.833842+00
76	ukclimbing	53335	route	1	\N	fair-head	91	82	done	\N	done	\N	0	\N	\N	2026-07-07 18:09:13.288451+00	2026-07-06 21:10:29.651839+00	2026-07-07 18:10:50.013676+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53335.json	2026-07-06 21:10:29.651839+00
6	ukclimbing	51510	route	1	\N	fair-head	26	12	done	\N	needs_review	{character,feature}	0	\N	\N	2026-07-07 06:31:38.222536+00	2026-07-06 21:10:28.132591+00	2026-07-07 06:33:32.137699+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/51510.json	2026-07-06 21:10:28.132591+00
86	ukclimbing	724709	route	1	\N	fair-head	91	92	done	\N	done	\N	0	\N	\N	2026-07-07 18:10:50.228587+00	2026-07-06 21:10:29.864367+00	2026-07-07 18:13:21.863917+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/724709.json	2026-07-06 21:10:29.864367+00
87	ukclimbing	53347	route	1	\N	fair-head	91	93	done	\N	done	\N	0	\N	\N	2026-07-07 18:10:50.228587+00	2026-07-06 21:10:29.886259+00	2026-07-07 18:13:21.874923+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53347.json	2026-07-06 21:10:29.886259+00
88	ukclimbing	53349	route	1	\N	fair-head	91	94	done	\N	done	\N	0	\N	\N	2026-07-07 18:10:50.228587+00	2026-07-06 21:10:29.906666+00	2026-07-07 18:13:21.91324+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53349.json	2026-07-06 21:10:29.906666+00
89	ukclimbing	53353	route	1	\N	fair-head	91	95	done	\N	done	\N	0	\N	\N	2026-07-07 18:10:50.228587+00	2026-07-06 21:10:29.928827+00	2026-07-07 18:13:21.930425+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53353.json	2026-07-06 21:10:29.928827+00
90	ukclimbing	194012	route	1	\N	fair-head	111	96	done	\N	done	\N	0	\N	\N	2026-07-07 18:10:50.228587+00	2026-07-06 21:10:29.950272+00	2026-07-07 18:13:21.947024+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/194012.json	2026-07-06 21:10:29.950272+00
91	ukclimbing	116385	route	1	\N	fair-head	111	97	done	\N	done	\N	0	\N	\N	2026-07-07 18:10:50.228587+00	2026-07-06 21:10:29.972942+00	2026-07-07 18:13:21.958156+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/116385.json	2026-07-06 21:10:29.972942+00
92	ukclimbing	52848	route	1	\N	fair-head	111	98	done	\N	done	\N	0	\N	\N	2026-07-07 18:10:50.228587+00	2026-07-06 21:10:29.993096+00	2026-07-07 18:13:21.973402+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52848.json	2026-07-06 21:10:29.993096+00
93	ukclimbing	52849	route	1	\N	fair-head	111	99	done	\N	done	\N	0	\N	\N	2026-07-07 18:10:50.228587+00	2026-07-06 21:10:30.012886+00	2026-07-07 18:13:21.988616+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52849.json	2026-07-06 21:10:30.012886+00
94	ukclimbing	52851	route	1	\N	fair-head	111	100	done	\N	needs_review	{protection,character,feature}	0	\N	\N	2026-07-07 18:10:50.228587+00	2026-07-06 21:10:30.032008+00	2026-07-07 18:13:21.998684+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52851.json	2026-07-06 21:10:30.032008+00
96	ukclimbing	51528	route	1	\N	fair-head	117	102	done	\N	done	\N	0	\N	\N	2026-07-07 18:13:22.031362+00	2026-07-06 21:10:30.076134+00	2026-07-07 18:14:53.183772+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/51528.json	2026-07-06 21:10:30.076134+00
97	ukclimbing	52853	route	1	\N	fair-head	117	103	done	\N	done	\N	0	\N	\N	2026-07-07 18:13:22.031362+00	2026-07-06 21:10:30.097012+00	2026-07-07 18:14:53.20793+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52853.json	2026-07-06 21:10:30.097012+00
98	ukclimbing	38815	route	1	\N	fair-head	117	104	done	\N	done	\N	0	\N	\N	2026-07-07 18:13:22.031362+00	2026-07-06 21:10:30.117012+00	2026-07-07 18:14:53.229388+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/38815.json	2026-07-06 21:10:30.117012+00
99	ukclimbing	36938	route	1	\N	fair-head	117	105	done	\N	done	\N	0	\N	\N	2026-07-07 18:13:22.031362+00	2026-07-06 21:10:30.136178+00	2026-07-07 18:14:53.250666+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/36938.json	2026-07-06 21:10:30.136178+00
100	ukclimbing	36937	route	1	\N	fair-head	117	106	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:13:22.031362+00	2026-07-06 21:10:30.157914+00	2026-07-07 18:14:53.261549+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/36937.json	2026-07-06 21:10:30.157914+00
101	ukclimbing	52870	route	1	\N	fair-head	122	107	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:13:22.031362+00	2026-07-06 21:10:30.180071+00	2026-07-07 18:14:53.27274+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52870.json	2026-07-06 21:10:30.180071+00
102	ukclimbing	52871	route	1	\N	fair-head	122	108	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:13:22.031362+00	2026-07-06 21:10:30.201533+00	2026-07-07 18:14:53.284436+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52871.json	2026-07-06 21:10:30.201533+00
127	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834249869	area	2	Northern Ireland > Antrim > Fair Head > Highlander Area	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:14:13.051408+00	2026-07-06 21:14:13.051408+00	2026-07-06 21:14:42.458605+00	\N	\N	2026-07-06 21:11:03.015397+00
128	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834260423	area	2	Northern Ireland > Antrim > Fair Head > Middle Band Area	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:14:13.051408+00	2026-07-06 21:14:13.051408+00	2026-07-06 21:14:58.797375+00	\N	\N	2026-07-06 21:11:03.020954+00
177	thecrag	7834241568	route	109	\N	fair-head	130	125	done	\N	done	\N	0	\N	\N	2026-07-07 06:38:25.465894+00	2026-07-06 21:11:44.402673+00	2026-07-07 06:38:53.231601+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834241568.json	2026-07-06 21:11:44.402673+00
130	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834278801	area	2	Northern Ireland > Antrim > Fair Head > Murlough Bay Area	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:15:15.354019+00	2026-07-06 21:15:15.354019+00	2026-07-06 21:15:21.459325+00	\N	\N	2026-07-06 21:11:03.031899+00
131	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834287906	area	2	Northern Ireland > Antrim > Fair Head > Outlying Areas	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:15:15.354019+00	2026-07-06 21:15:15.354019+00	2026-07-06 21:15:27.486679+00	\N	\N	2026-07-06 21:11:03.037127+00
132	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834302681	area	2	Northern Ireland > Antrim > Fair Head > Shoreline Area	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:15:15.354019+00	2026-07-06 21:15:15.354019+00	2026-07-06 21:15:34.697645+00	\N	\N	2026-07-06 21:11:03.042309+00
135	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834330263/locate	area	2	Northern Ireland > Antrim > Fair Head > 2	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:15:57.294436+00	2026-07-06 21:15:57.294436+00	2026-07-06 21:16:14.071506+00	\N	\N	2026-07-06 21:11:03.0574+00
136	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834185765/locate	area	2	Northern Ireland > Antrim > Fair Head > 3	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:15:57.294436+00	2026-07-06 21:15:57.294436+00	2026-07-06 21:16:19.92779+00	\N	\N	2026-07-06 21:11:03.062253+00
137	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/12518263/locate	area	2	Northern Ireland > Antrim > Fair Head > 4	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:15:57.294436+00	2026-07-06 21:15:57.294436+00	2026-07-06 21:16:25.913227+00	\N	\N	2026-07-06 21:11:03.06687+00
138	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/12518287/locate	area	2	Northern Ireland > Antrim > Fair Head > 5	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:15:57.294436+00	2026-07-06 21:15:57.294436+00	2026-07-06 21:16:31.839667+00	\N	\N	2026-07-06 21:11:03.071857+00
143	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/12518407/locate	area	2	Northern Ireland > Antrim > Fair Head > 10	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:16:48.099845+00	2026-07-06 21:16:48.099845+00	2026-07-06 21:17:32.971296+00	\N	\N	2026-07-06 21:11:03.096264+00
144	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834362417/locate	area	2	Northern Ireland > Antrim > Fair Head > 11	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:16:48.099845+00	2026-07-06 21:16:48.099845+00	2026-07-06 21:17:49.486273+00	\N	\N	2026-07-06 21:11:03.10157+00
148	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834219356/locate	area	2	Northern Ireland > Antrim > Fair Head > 15	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:17:49.522186+00	2026-07-06 21:17:49.522186+00	2026-07-06 21:18:55.469335+00	\N	\N	2026-07-06 21:11:03.120978+00
149	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/3842053572/locate	area	2	Northern Ireland > Antrim > Fair Head > 16	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:17:49.522186+00	2026-07-06 21:17:49.522186+00	2026-07-06 21:19:11.7076+00	\N	\N	2026-07-06 21:11:03.125889+00
110	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/12518311	area	2	Northern Ireland > Antrim > Fair Head > White Lightning Amphitheatre	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:11:44.621594+00	2026-07-06 21:11:44.621594+00	2026-07-06 21:12:01.069722+00	\N	\N	2026-07-06 21:11:02.939048+00
111	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/12518335	area	2	Northern Ireland > Antrim > Fair Head > Bird Hide Block area	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:11:44.621594+00	2026-07-06 21:11:44.621594+00	2026-07-06 21:12:07.639489+00	\N	\N	2026-07-06 21:11:02.944725+00
112	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/12518359	area	2	Northern Ireland > Antrim > Fair Head > An Bealach Rúnda Area	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:11:44.621594+00	2026-07-06 21:11:44.621594+00	2026-07-06 21:12:14.441782+00	\N	\N	2026-07-06 21:11:02.949241+00
113	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/12518383	area	2	Northern Ireland > Antrim > Fair Head > The Terraces	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:11:44.621594+00	2026-07-06 21:11:44.621594+00	2026-07-06 21:12:20.865665+00	\N	\N	2026-07-06 21:11:02.953774+00
115	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834362417	area	2	Northern Ireland > Antrim > Fair Head > The Wall of Prey	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:12:28.716775+00	2026-07-06 21:12:28.716775+00	2026-07-06 21:12:45.106713+00	\N	\N	2026-07-06 21:11:02.961884+00
116	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/923054925	area	2	Northern Ireland > Antrim > Fair Head > Ballycastle Descent Gully East	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:12:28.716775+00	2026-07-06 21:12:28.716775+00	2026-07-06 21:13:01.56292+00	\N	\N	2026-07-06 21:11:02.966019+00
117	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/1792467888	area	2	Northern Ireland > Antrim > Fair Head > Ballycastle Descent Gully West	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:12:28.716775+00	2026-07-06 21:12:28.716775+00	2026-07-06 21:13:08.285814+00	\N	\N	2026-07-06 21:11:02.969886+00
118	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/12518431	area	2	Northern Ireland > Antrim > Fair Head > The Prow	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:12:28.716775+00	2026-07-06 21:12:28.716775+00	2026-07-06 21:13:14.783841+00	\N	\N	2026-07-06 21:11:02.973922+00
120	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/3842053572	area	2	Northern Ireland > Antrim > Fair Head > Na Bolláin Rúnda	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:13:20.954308+00	2026-07-06 21:13:20.954308+00	2026-07-06 21:13:27.117877+00	\N	\N	2026-07-06 21:11:02.981663+00
121	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834162017	area	2	Northern Ireland > Antrim > Fair Head > Agent Orange Area	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:13:20.954308+00	2026-07-06 21:13:20.954308+00	2026-07-06 21:13:33.796659+00	\N	\N	2026-07-06 21:11:02.985416+00
122	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834173183	area	2	Northern Ireland > Antrim > Fair Head > Ballycastle Descent Area	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:13:20.954308+00	2026-07-06 21:13:20.954308+00	2026-07-06 21:13:50.512664+00	\N	\N	2026-07-06 21:11:02.989649+00
123	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834181688	area	2	Northern Ireland > Antrim > Fair Head > Beach Ball Area	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:13:20.954308+00	2026-07-06 21:13:20.954308+00	2026-07-06 21:14:06.845306+00	\N	\N	2026-07-06 21:11:02.993864+00
125	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834200897	area	2	Northern Ireland > Antrim > Fair Head > Cockus Maximus Area	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:14:13.051408+00	2026-07-06 21:14:13.051408+00	2026-07-06 21:14:19.376596+00	\N	\N	2026-07-06 21:11:03.004058+00
126	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834206102	area	2	Northern Ireland > Antrim > Fair Head > Eat It Area	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:14:13.051408+00	2026-07-06 21:14:13.051408+00	2026-07-06 21:14:26.144966+00	\N	\N	2026-07-06 21:11:03.010132+00
155	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834206102/locate	area	2	Northern Ireland > Antrim > Fair Head > 22	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:20:33.610978+00	2026-07-06 21:20:33.610978+00	2026-07-06 21:20:49.94322+00	\N	\N	2026-07-06 21:11:03.155245+00
159	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834278801/locate	area	2	Northern Ireland > Antrim > Fair Head > 26	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:20:33.610978+00	2026-07-06 21:20:33.610978+00	2026-07-06 21:21:06.253624+00	\N	\N	2026-07-06 21:11:03.176135+00
158	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834272564/locate	area	2	Northern Ireland > Antrim > Fair Head > 25	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:20:33.610978+00	2026-07-06 21:20:33.610978+00	2026-07-06 21:21:22.69456+00	\N	\N	2026-07-06 21:11:03.171251+00
157	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834260423/locate	area	2	Northern Ireland > Antrim > Fair Head > 24	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:20:33.610978+00	2026-07-06 21:20:33.610978+00	2026-07-06 21:21:38.903351+00	\N	\N	2026-07-06 21:11:03.166147+00
163	thecrag	7834342203	route	105	\N	fair-head	24	9	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 06:38:03.717876+00	2026-07-06 21:11:18.199887+00	2026-07-07 06:38:25.327153+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834342203.json	2026-07-06 21:11:18.199887+00
162	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834370709/locate	area	2	Northern Ireland > Antrim > Fair Head > 29	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:21:55.311983+00	2026-07-06 21:21:55.311983+00	2026-07-06 21:22:11.557543+00	\N	\N	2026-07-06 21:11:03.190304+00
161	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834302681/locate	area	2	Northern Ireland > Antrim > Fair Head > 28	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:21:55.311983+00	2026-07-06 21:21:55.311983+00	2026-07-06 21:22:28.41078+00	\N	\N	2026-07-06 21:11:03.185696+00
160	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834287906/locate	area	2	Northern Ireland > Antrim > Fair Head > 27	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:21:55.311983+00	2026-07-06 21:21:55.311983+00	2026-07-06 21:22:44.673696+00	\N	\N	2026-07-06 21:11:03.18085+00
164	thecrag	7834342464	route	105	\N	fair-head	24	10	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 06:38:03.717876+00	2026-07-06 21:11:18.216466+00	2026-07-07 06:38:25.339891+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834342464.json	2026-07-06 21:11:18.216466+00
181	thecrag	7834247646	route	109	\N	fair-head	130	129	done	\N	done	\N	0	\N	\N	2026-07-07 06:38:25.465894+00	2026-07-06 21:11:44.469838+00	2026-07-07 06:38:53.245048+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834247646.json	2026-07-06 21:11:44.469838+00
41	ukclimbing	53715	route	1	\N	fair-head	62	47	done	\N	done	\N	0	\N	\N	2026-07-07 18:02:18.877115+00	2026-07-06 21:10:28.894548+00	2026-07-07 18:04:18.258678+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53715.json	2026-07-06 21:10:28.894548+00
10	ukclimbing	36926	route	1	\N	fair-head	26	16	done	\N	done	\N	0	\N	\N	2026-07-07 06:31:38.222536+00	2026-07-06 21:10:28.225816+00	2026-07-07 06:33:31.982047+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/36926.json	2026-07-06 21:10:28.225816+00
11	ukclimbing	51527	route	1	\N	fair-head	26	17	done	\N	needs_review	{protection,character,feature}	0	\N	\N	2026-07-07 06:31:38.222536+00	2026-07-06 21:10:28.248993+00	2026-07-07 06:33:31.995321+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/51527.json	2026-07-06 21:10:28.248993+00
12	ukclimbing	800810	route	1	\N	fair-head	26	18	done	\N	done	\N	0	\N	\N	2026-07-07 06:31:38.222536+00	2026-07-06 21:10:28.269796+00	2026-07-07 06:33:32.027981+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/800810.json	2026-07-06 21:10:28.269796+00
139	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/12518311/locate	area	2	Northern Ireland > Antrim > Fair Head > 6	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:15:57.294436+00	2026-07-06 21:15:57.294436+00	2026-07-06 21:16:48.062214+00	\N	\N	2026-07-06 21:11:03.077029+00
13	ukclimbing	52553	route	1	\N	fair-head	34	19	done	\N	done	\N	0	\N	\N	2026-07-07 06:31:38.222536+00	2026-07-06 21:10:28.291212+00	2026-07-07 06:33:32.060121+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52553.json	2026-07-06 21:10:28.291212+00
140	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/12518335/locate	area	2	Northern Ireland > Antrim > Fair Head > 7	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:16:48.099845+00	2026-07-06 21:16:48.099845+00	2026-07-06 21:17:04.377989+00	\N	\N	2026-07-06 21:11:03.082089+00
141	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/12518359/locate	area	2	Northern Ireland > Antrim > Fair Head > 8	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:16:48.099845+00	2026-07-06 21:16:48.099845+00	2026-07-06 21:17:10.365603+00	\N	\N	2026-07-06 21:11:03.086928+00
105	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834331811	area	2	Northern Ireland > Antrim > Fair Head > The Small Crag	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:11:11.851685+00	2026-07-06 21:11:11.851685+00	2026-07-06 21:11:18.221492+00	\N	\N	2026-07-06 21:11:02.912931+00
106	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834330263	area	2	Northern Ireland > Antrim > Fair Head > The Middle Crag	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:11:11.851685+00	2026-07-06 21:11:11.851685+00	2026-07-06 21:11:24.518627+00	\N	\N	2026-07-06 21:11:02.91964+00
107	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834185765	area	2	Northern Ireland > Antrim > Fair Head > Below the Main Crag	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:11:11.851685+00	2026-07-06 21:11:11.851685+00	2026-07-06 21:11:30.964881+00	\N	\N	2026-07-06 21:11:02.924636+00
142	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/12518383/locate	area	2	Northern Ireland > Antrim > Fair Head > 9	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:16:48.099845+00	2026-07-06 21:16:48.099845+00	2026-07-06 21:17:16.737487+00	\N	\N	2026-07-06 21:11:03.091648+00
108	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/12518263	area	2	Northern Ireland > Antrim > Fair Head > Binnagapple	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:11:11.851685+00	2026-07-06 21:11:11.851685+00	2026-07-06 21:11:37.265969+00	\N	\N	2026-07-06 21:11:02.929422+00
145	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/923054925/locate	area	2	Northern Ireland > Antrim > Fair Head > 12	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:17:49.522186+00	2026-07-06 21:17:49.522186+00	2026-07-06 21:18:06.050347+00	\N	\N	2026-07-06 21:11:03.106768+00
146	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/1792467888/locate	area	2	Northern Ireland > Antrim > Fair Head > 13	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:17:49.522186+00	2026-07-06 21:17:49.522186+00	2026-07-06 21:18:22.693741+00	\N	\N	2026-07-06 21:11:03.111643+00
147	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/12518431/locate	area	2	Northern Ireland > Antrim > Fair Head > 14	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:17:49.522186+00	2026-07-06 21:17:49.522186+00	2026-07-06 21:18:38.997238+00	\N	\N	2026-07-06 21:11:03.116132+00
150	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834162017/locate	area	2	Northern Ireland > Antrim > Fair Head > 17	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:19:11.744511+00	2026-07-06 21:19:11.744511+00	2026-07-06 21:19:28.061494+00	\N	\N	2026-07-06 21:11:03.130718+00
151	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834173183/locate	area	2	Northern Ireland > Antrim > Fair Head > 18	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:19:11.744511+00	2026-07-06 21:19:11.744511+00	2026-07-06 21:19:44.285318+00	\N	\N	2026-07-06 21:11:03.135327+00
152	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834181688/locate	area	2	Northern Ireland > Antrim > Fair Head > 19	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:19:11.744511+00	2026-07-06 21:19:11.744511+00	2026-07-06 21:20:00.71618+00	\N	\N	2026-07-06 21:11:03.14019+00
31	ukclimbing	226493	route	1	\N	fair-head	49	37	done	\N	needs_review	{protection}	0	\N	\N	2026-07-07 06:35:54.914495+00	2026-07-06 21:10:28.685008+00	2026-07-07 06:38:02.123742+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/226493.json	2026-07-06 21:10:28.685008+00
32	ukclimbing	162544	route	1	\N	fair-head	49	38	done	\N	needs_review	{protection,character,feature}	0	\N	\N	2026-07-07 06:35:54.914495+00	2026-07-06 21:10:28.706289+00	2026-07-07 06:38:02.134262+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/162544.json	2026-07-06 21:10:28.706289+00
33	ukclimbing	798188	route	1	\N	fair-head	49	39	done	\N	needs_review	{protection,character}	0	\N	\N	2026-07-07 06:35:54.914495+00	2026-07-06 21:10:28.728288+00	2026-07-07 06:38:02.151056+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/798188.json	2026-07-06 21:10:28.728288+00
34	ukclimbing	222311	route	1	\N	fair-head	55	40	done	\N	needs_review	{protection,character,feature}	0	\N	\N	2026-07-07 06:35:54.914495+00	2026-07-06 21:10:28.749935+00	2026-07-07 06:38:02.162745+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/222311.json	2026-07-06 21:10:28.749935+00
35	ukclimbing	800193	route	1	\N	fair-head	55	41	done	\N	needs_review	{protection_style,belays}	0	\N	\N	2026-07-07 06:35:54.914495+00	2026-07-06 21:10:28.77141+00	2026-07-07 06:38:02.208366+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/800193.json	2026-07-06 21:10:28.77141+00
77	ukclimbing	53336	route	1	\N	fair-head	91	83	done	\N	done	\N	0	\N	\N	2026-07-07 18:09:13.288451+00	2026-07-06 21:10:29.672443+00	2026-07-07 18:10:50.025516+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53336.json	2026-07-06 21:10:29.672443+00
84	ukclimbing	53344	route	1	\N	fair-head	91	90	done	\N	done	\N	0	\N	\N	2026-07-07 18:09:13.288451+00	2026-07-06 21:10:29.820869+00	2026-07-07 18:10:50.188952+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53344.json	2026-07-06 21:10:29.820869+00
178	thecrag	7834241805	route	109	\N	fair-head	130	126	done	\N	done	\N	0	\N	\N	2026-07-07 06:38:25.465894+00	2026-07-06 21:11:44.418149+00	2026-07-07 06:38:53.269856+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834241805.json	2026-07-06 21:11:44.418149+00
179	thecrag	7834245591	route	109	\N	fair-head	130	127	done	\N	done	\N	0	\N	\N	2026-07-07 06:38:25.465894+00	2026-07-06 21:11:44.433695+00	2026-07-07 06:38:53.281428+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834245591.json	2026-07-06 21:11:44.433695+00
180	thecrag	7834247412	route	109	\N	fair-head	130	128	done	\N	done	\N	0	\N	\N	2026-07-07 06:38:25.465894+00	2026-07-06 21:11:44.451871+00	2026-07-07 06:38:53.293012+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834247412.json	2026-07-06 21:11:44.451871+00
188	thecrag	7834249629	route	109	\N	fair-head	130	136	done	\N	needs_review	{protection,protection_style,belays,character,feature,incline}	0	\N	\N	2026-07-07 06:38:53.362015+00	2026-07-06 21:11:44.578133+00	2026-07-07 06:39:20.438218+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834249629.json	2026-07-06 21:11:44.578133+00
43	ukclimbing	343329	route	1	\N	fair-head	62	49	done	\N	needs_review	{protection_style}	0	\N	\N	2026-07-07 18:02:18.877115+00	2026-07-06 21:10:28.932142+00	2026-07-07 18:04:18.33+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/343329.json	2026-07-06 21:10:28.932142+00
109	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/12518287	area	2	Northern Ireland > Antrim > Fair Head > Grey Man's Path	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:11:11.851685+00	2026-07-06 21:11:11.851685+00	2026-07-06 21:11:44.582462+00	\N	\N	2026-07-06 21:11:02.934186+00
114	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/12518407	area	2	Northern Ireland > Antrim > Fair Head > Rathlin Wall	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:11:44.621594+00	2026-07-06 21:11:44.621594+00	2026-07-06 21:12:28.681258+00	\N	\N	2026-07-06 21:11:02.957939+00
4	ukclimbing	420412	route	1	\N	fair-head	24	10	done	\N	needs_review	{protection_style}	1		\N	2026-07-07 06:28:55.654418+00	2026-07-06 21:10:28.086447+00	2026-07-07 06:30:35.402304+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/420412.json	2026-07-06 21:10:28.086447+00
5	ukclimbing	51508	route	1	\N	fair-head	26	11	done	\N	done	\N	1		\N	2026-07-07 06:28:55.654418+00	2026-07-06 21:10:28.111754+00	2026-07-07 06:30:35.483227+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/51508.json	2026-07-06 21:10:28.111754+00
14	ukclimbing	52554	route	1	\N	fair-head	34	20	done	\N	needs_review	{character}	0	\N	\N	2026-07-07 06:31:38.222536+00	2026-07-06 21:10:28.312111+00	2026-07-07 06:33:32.08504+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52554.json	2026-07-06 21:10:28.312111+00
15	ukclimbing	52555	route	1	\N	fair-head	34	21	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 06:31:38.222536+00	2026-07-06 21:10:28.331831+00	2026-07-07 06:33:32.097569+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52555.json	2026-07-06 21:10:28.331831+00
21	ukclimbing	364671	route	1	\N	fair-head	40	27	done	\N	done	\N	0	\N	\N	2026-07-07 06:33:32.160109+00	2026-07-06 21:10:28.466335+00	2026-07-07 06:35:54.810556+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/364671.json	2026-07-06 21:10:28.466335+00
22	ukclimbing	52575	route	1	\N	fair-head	40	28	done	\N	needs_review	{protection,character,feature,hazards}	0	\N	\N	2026-07-07 06:33:32.160109+00	2026-07-06 21:10:28.487124+00	2026-07-07 06:35:54.82271+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52575.json	2026-07-06 21:10:28.487124+00
23	ukclimbing	52576	route	1	\N	fair-head	40	29	done	\N	done	\N	0	\N	\N	2026-07-07 06:33:32.160109+00	2026-07-06 21:10:28.508263+00	2026-07-07 06:35:54.87777+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52576.json	2026-07-06 21:10:28.508263+00
24	ukclimbing	52578	route	1	\N	fair-head	40	30	done	\N	needs_review	{protection,character,feature,hazards}	0	\N	\N	2026-07-07 06:33:32.160109+00	2026-07-06 21:10:28.530222+00	2026-07-07 06:35:54.888372+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52578.json	2026-07-06 21:10:28.530222+00
25	ukclimbing	52579	route	1	\N	fair-head	40	31	done	\N	needs_review	{protection,character,feature,hazards}	0	\N	\N	2026-07-07 06:33:32.160109+00	2026-07-06 21:10:28.551226+00	2026-07-07 06:35:54.899078+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52579.json	2026-07-06 21:10:28.551226+00
153	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834200132/locate	area	2	Northern Ireland > Antrim > Fair Head > 20	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:19:11.744511+00	2026-07-06 21:19:11.744511+00	2026-07-06 21:20:17.246442+00	\N	\N	2026-07-06 21:11:03.144886+00
154	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834200897/locate	area	2	Northern Ireland > Antrim > Fair Head > 21	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:19:11.744511+00	2026-07-06 21:19:11.744511+00	2026-07-06 21:20:33.570509+00	\N	\N	2026-07-06 21:11:03.149824+00
203	thecrag	7834172703	route	112	\N	fair-head	62	55	done	\N	needs_review	{protection,hazards,character,feature,incline}	0	\N	\N	2026-07-07 18:15:40.680978+00	2026-07-06 21:12:14.358628+00	2026-07-07 18:16:15.563147+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834172703.json	2026-07-06 21:12:14.358628+00
204	thecrag	7834172940	route	112	\N	fair-head	62	56	done	\N	needs_review	{protection,hazards,character,feature,incline}	0	\N	\N	2026-07-07 18:15:40.680978+00	2026-07-06 21:12:14.371589+00	2026-07-07 18:16:15.574576+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834172940.json	2026-07-06 21:12:14.371589+00
205	thecrag	7834327389	route	112	\N	fair-head	62	153	done	\N	needs_review	{protection,hazards,character,feature,incline}	0	\N	\N	2026-07-07 18:15:40.680978+00	2026-07-06 21:12:14.385145+00	2026-07-07 18:16:15.585862+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834327389.json	2026-07-06 21:12:14.385145+00
206	thecrag	7834327689	route	112	\N	fair-head	62	154	done	\N	needs_review	{protection,hazards,character,feature,incline}	0	\N	\N	2026-07-07 18:15:40.680978+00	2026-07-06 21:12:14.398276+00	2026-07-07 18:16:15.596776+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834327689.json	2026-07-06 21:12:14.398276+00
207	thecrag	7834327926	route	112	\N	fair-head	62	155	done	\N	needs_review	{protection,hazards,character,feature,incline}	0	\N	\N	2026-07-07 18:15:40.680978+00	2026-07-06 21:12:14.411572+00	2026-07-07 18:16:15.607791+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834327926.json	2026-07-06 21:12:14.411572+00
208	thecrag	7834328163	route	112	\N	fair-head	62	156	done	\N	needs_review	{protection,hazards,character,feature,incline}	0	\N	\N	2026-07-07 18:15:40.680978+00	2026-07-06 21:12:14.424488+00	2026-07-07 18:16:15.619978+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834328163.json	2026-07-06 21:12:14.424488+00
209	thecrag	7834328973	route	112	\N	fair-head	62	157	done	\N	needs_review	{protection,hazards,character,feature,incline}	0	\N	\N	2026-07-07 18:15:40.680978+00	2026-07-06 21:12:14.438051+00	2026-07-07 18:16:15.631674+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834328973.json	2026-07-06 21:12:14.438051+00
210	thecrag	7816333950	route	113	\N	fair-head	77	68	done	\N	needs_review	{protection,hazards,character,feature,incline}	0	\N	\N	2026-07-07 18:15:40.680978+00	2026-07-06 21:12:20.61604+00	2026-07-07 18:16:15.642902+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7816333950.json	2026-07-06 21:12:20.61604+00
211	thecrag	7834356108	route	113	\N	fair-head	77	62	done	\N	needs_review	{protection,hazards,character,feature,incline}	0	\N	\N	2026-07-07 18:15:40.680978+00	2026-07-06 21:12:20.634533+00	2026-07-07 18:16:15.653801+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834356108.json	2026-07-06 21:12:20.634533+00
213	thecrag	7834356570	route	113	\N	fair-head	77	64	done	\N	needs_review	{protection,protection_style,belays,character,feature,incline}	0	\N	\N	2026-07-07 18:16:15.678415+00	2026-07-06 21:12:20.666763+00	2026-07-07 18:16:28.885619+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834356570.json	2026-07-06 21:12:20.666763+00
214	thecrag	7834357353	route	113	\N	fair-head	77	65	done	\N	needs_review	{protection,protection_style,belays,character,feature,incline}	0	\N	\N	2026-07-07 18:16:15.678415+00	2026-07-06 21:12:20.683011+00	2026-07-07 18:16:28.898297+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834357353.json	2026-07-06 21:12:20.683011+00
215	thecrag	7834357593	route	113	\N	fair-head	77	66	done	\N	needs_review	{protection,protection_style,belays,character,feature,incline}	0	\N	\N	2026-07-07 18:16:15.678415+00	2026-07-06 21:12:20.701271+00	2026-07-07 18:16:28.909918+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834357593.json	2026-07-06 21:12:20.701271+00
216	thecrag	7834357824	route	113	\N	fair-head	77	67	done	\N	needs_review	{protection,protection_style,belays,character,feature,incline}	0	\N	\N	2026-07-07 18:16:15.678415+00	2026-07-06 21:12:20.7183+00	2026-07-07 18:16:28.921927+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834357824.json	2026-07-06 21:12:20.7183+00
223	thecrag	7834362186	route	113	\N	fair-head	77	75	done	\N	done	\N	0	\N	\N	2026-07-07 18:16:29.002685+00	2026-07-06 21:12:20.856614+00	2026-07-07 18:16:45.372299+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834362186.json	2026-07-06 21:12:20.856614+00
224	thecrag	7816358109	route	114	\N	fair-head	135	172	done	\N	done	\N	0	\N	\N	2026-07-07 18:16:29.002685+00	2026-07-06 21:12:28.356659+00	2026-07-07 18:16:45.384875+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7816358109.json	2026-07-06 21:12:28.356659+00
225	thecrag	7816355619	route	114	\N	fair-head	135	173	done	\N	done	\N	0	\N	\N	2026-07-07 18:16:29.002685+00	2026-07-06 21:12:28.371419+00	2026-07-07 18:16:45.396548+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7816355619.json	2026-07-06 21:12:28.371419+00
226	thecrag	7816361481	route	114	\N	fair-head	135	174	done	\N	done	\N	0	\N	\N	2026-07-07 18:16:29.002685+00	2026-07-06 21:12:28.386532+00	2026-07-07 18:16:45.407951+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7816361481.json	2026-07-06 21:12:28.386532+00
227	thecrag	7816367586	route	114	\N	fair-head	135	175	done	\N	done	\N	0	\N	\N	2026-07-07 18:16:29.002685+00	2026-07-06 21:12:28.400313+00	2026-07-07 18:16:45.418656+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7816367586.json	2026-07-06 21:12:28.400313+00
230	thecrag	7834291074	route	114	\N	fair-head	135	178	done	\N	done	\N	0	\N	\N	2026-07-07 18:16:29.002685+00	2026-07-06 21:12:28.44102+00	2026-07-07 18:16:45.448848+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834291074.json	2026-07-06 21:12:28.44102+00
231	thecrag	7834291317	route	114	\N	fair-head	135	179	done	\N	done	\N	0	\N	\N	2026-07-07 18:16:29.002685+00	2026-07-06 21:12:28.456408+00	2026-07-07 18:16:45.459656+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834291317.json	2026-07-06 21:12:28.456408+00
232	thecrag	7834292130	route	114	\N	fair-head	135	180	done	\N	done	\N	0	\N	\N	2026-07-07 18:16:29.002685+00	2026-07-06 21:12:28.473077+00	2026-07-07 18:16:45.470834+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834292130.json	2026-07-06 21:12:28.473077+00
239	thecrag	7834298766	route	114	\N	fair-head	135	187	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:16:45.48755+00	2026-07-06 21:12:28.586845+00	2026-07-07 18:16:53.196422+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834298766.json	2026-07-06 21:12:28.586845+00
240	thecrag	7834299027	route	114	\N	fair-head	135	188	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:16:45.48755+00	2026-07-06 21:12:28.603108+00	2026-07-07 18:16:53.208056+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834299027.json	2026-07-06 21:12:28.603108+00
241	thecrag	7834299258	route	114	\N	fair-head	135	189	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:16:45.48755+00	2026-07-06 21:12:28.618623+00	2026-07-07 18:16:53.218769+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834299258.json	2026-07-06 21:12:28.618623+00
253	thecrag	14071519	route	118	\N	fair-head	124	201	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:17:11.697471+00	2026-07-06 21:13:14.726659+00	2026-07-07 18:17:45.355864+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/14071519.json	2026-07-06 21:13:14.726659+00
254	thecrag	14071639	route	118	\N	fair-head	124	202	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:17:11.697471+00	2026-07-06 21:13:14.743736+00	2026-07-07 18:17:45.369134+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/14071639.json	2026-07-06 21:13:14.743736+00
255	thecrag	14071747	route	118	\N	fair-head	124	203	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:17:11.697471+00	2026-07-06 21:13:14.761495+00	2026-07-07 18:17:45.38081+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/14071747.json	2026-07-06 21:13:14.761495+00
256	thecrag	14072191	route	118	\N	fair-head	124	204	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:17:11.697471+00	2026-07-06 21:13:14.778922+00	2026-07-07 18:17:45.393735+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/14072191.json	2026-07-06 21:13:14.778922+00
257	thecrag	7834227774	route	119	\N	fair-head	125	110	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:17:11.697471+00	2026-07-06 21:13:20.911695+00	2026-07-07 18:17:45.40565+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834227774.json	2026-07-06 21:13:20.911695+00
189	thecrag	7834196592	route	111	\N	fair-head	55	40	done	\N	needs_review	{protection,protection_style,belays,character,feature,incline}	0	\N	\N	2026-07-07 06:38:53.362015+00	2026-07-06 21:12:07.553909+00	2026-07-07 06:39:20.451358+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834196592.json	2026-07-06 21:12:07.553909+00
190	thecrag	7834198353	route	111	\N	fair-head	55	42	done	\N	needs_review	{protection,protection_style,belays,character,feature,incline}	0	\N	\N	2026-07-07 06:38:53.362015+00	2026-07-06 21:12:07.570474+00	2026-07-07 06:39:20.463507+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834198353.json	2026-07-06 21:12:07.570474+00
191	thecrag	7834198953	route	111	\N	fair-head	55	43	done	\N	needs_review	{protection,protection_style,belays,character,feature,incline}	0	\N	\N	2026-07-07 06:38:53.362015+00	2026-07-06 21:12:07.586932+00	2026-07-07 06:39:20.475049+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834198953.json	2026-07-06 21:12:07.586932+00
129	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834272564	area	2	Northern Ireland > Antrim > Fair Head > Miner's House Area	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:14:13.051408+00	2026-07-06 21:14:13.051408+00	2026-07-06 21:15:15.316337+00	\N	\N	2026-07-06 21:11:03.025911+00
119	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834219356	area	2	Northern Ireland > Antrim > Fair Head > Farrangandoo	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:12:28.716775+00	2026-07-06 21:12:28.716775+00	2026-07-06 21:13:20.916678+00	\N	\N	2026-07-06 21:11:02.977852+00
85	ukclimbing	53345	route	1	\N	fair-head	91	91	done	\N	done	\N	0	\N	\N	2026-07-07 18:09:13.288451+00	2026-07-06 21:10:29.843093+00	2026-07-07 18:10:50.212403+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53345.json	2026-07-06 21:10:29.843093+00
124	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834200132	area	2	Northern Ireland > Antrim > Fair Head > Cockus Maximus and Beyond 1	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:13:20.954308+00	2026-07-06 21:13:20.954308+00	2026-07-06 21:14:13.013942+00	\N	\N	2026-07-06 21:11:02.99874+00
183	thecrag	7834248114	route	109	\N	fair-head	130	131	done	\N	needs_review	{protection,protection_style,belays,character,feature,incline}	0	\N	\N	2026-07-07 06:38:53.362015+00	2026-07-06 21:11:44.499913+00	2026-07-07 06:39:20.499092+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834248114.json	2026-07-06 21:11:44.499913+00
233	thecrag	7834292349	route	114	\N	fair-head	135	181	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:16:45.48755+00	2026-07-06 21:12:28.49014+00	2026-07-07 18:16:53.133991+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834292349.json	2026-07-06 21:12:28.49014+00
234	thecrag	7834292580	route	114	\N	fair-head	135	182	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:16:45.48755+00	2026-07-06 21:12:28.506181+00	2026-07-07 18:16:53.144804+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834292580.json	2026-07-06 21:12:28.506181+00
235	thecrag	7834296903	route	114	\N	fair-head	135	183	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:16:45.48755+00	2026-07-06 21:12:28.521886+00	2026-07-07 18:16:53.156133+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834296903.json	2026-07-06 21:12:28.521886+00
236	thecrag	7834297242	route	114	\N	fair-head	135	184	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:16:45.48755+00	2026-07-06 21:12:28.537898+00	2026-07-07 18:16:53.166851+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834297242.json	2026-07-06 21:12:28.537898+00
243	thecrag	7834299816	route	114	\N	fair-head	135	191	done	\N	done	\N	0	\N	\N	2026-07-07 18:16:53.24897+00	2026-07-06 21:12:28.649294+00	2026-07-07 18:17:11.58304+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834299816.json	2026-07-06 21:12:28.649294+00
244	thecrag	7834300527	route	114	\N	fair-head	135	192	done	\N	done	\N	0	\N	\N	2026-07-07 18:16:53.24897+00	2026-07-06 21:12:28.663226+00	2026-07-07 18:17:11.595547+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834300527.json	2026-07-06 21:12:28.663226+00
245	thecrag	7834301622	route	114	\N	fair-head	135	193	done	\N	done	\N	0	\N	\N	2026-07-07 18:16:53.24897+00	2026-07-06 21:12:28.6771+00	2026-07-07 18:17:11.607332+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834301622.json	2026-07-06 21:12:28.6771+00
246	thecrag	7834179147	route	117	\N	fair-head	122	107	done	\N	done	\N	0	\N	\N	2026-07-07 18:16:53.24897+00	2026-07-06 21:13:08.264926+00	2026-07-07 18:17:11.618754+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834179147.json	2026-07-06 21:13:08.264926+00
61	ukclimbing	531194	route	1	\N	fair-head	77	67	done	\N	done	\N	0	\N	\N	2026-07-07 18:06:58.216894+00	2026-07-06 21:10:29.318195+00	2026-07-07 18:09:01.000446+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/531194.json	2026-07-06 21:10:29.318195+00
156	thecrag	https://www.thecrag.com/en/climbing/ireland/fair-head/area/7834249869/locate	area	2	Northern Ireland > Antrim > Fair Head > 23	fair-head	20	\N	done	\N	not_applicable	\N	0	\N	2026-07-06 21:20:33.610978+00	2026-07-06 21:20:33.610978+00	2026-07-06 21:21:55.27548+00	\N	\N	2026-07-06 21:11:03.161281+00
237	thecrag	7834298199	route	114	\N	fair-head	135	185	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:16:45.48755+00	2026-07-06 21:12:28.554867+00	2026-07-07 18:16:53.176172+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834298199.json	2026-07-06 21:12:28.554867+00
168	thecrag	7816307265	route	108	\N	fair-head	129	116	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 06:38:03.717876+00	2026-07-06 21:11:37.183403+00	2026-07-07 06:38:25.35206+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7816307265.json	2026-07-06 21:11:37.183403+00
169	thecrag	7834188216	route	108	\N	fair-head	129	117	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 06:38:03.717876+00	2026-07-06 21:11:37.203862+00	2026-07-07 06:38:25.364898+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834188216.json	2026-07-06 21:11:37.203862+00
170	thecrag	7834188966	route	108	\N	fair-head	129	118	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 06:38:03.717876+00	2026-07-06 21:11:37.219541+00	2026-07-07 06:38:25.379468+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834188966.json	2026-07-06 21:11:37.219541+00
165	thecrag	4584917313	route	108	\N	fair-head	129	113	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 06:38:03.717876+00	2026-07-06 21:11:37.124847+00	2026-07-07 06:38:25.396951+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/4584917313.json	2026-07-06 21:11:37.124847+00
166	thecrag	4584922620	route	108	\N	fair-head	129	114	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 06:38:03.717876+00	2026-07-06 21:11:37.147133+00	2026-07-07 06:38:25.417792+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/4584922620.json	2026-07-06 21:11:37.147133+00
167	thecrag	7816306374	route	108	\N	fair-head	129	115	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 06:38:03.717876+00	2026-07-06 21:11:37.163377+00	2026-07-07 06:38:25.432924+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7816306374.json	2026-07-06 21:11:37.163377+00
171	thecrag	7834190028	route	108	\N	fair-head	129	119	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 06:38:03.717876+00	2026-07-06 21:11:37.234525+00	2026-07-07 06:38:25.44934+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834190028.json	2026-07-06 21:11:37.234525+00
173	thecrag	7834195650	route	108	\N	fair-head	129	121	done	\N	done	\N	0	\N	\N	2026-07-07 06:38:25.465894+00	2026-07-06 21:11:37.261883+00	2026-07-07 06:38:53.303384+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834195650.json	2026-07-06 21:11:37.261883+00
174	thecrag	7834238823	route	109	\N	fair-head	130	122	done	\N	done	\N	0	\N	\N	2026-07-07 06:38:25.465894+00	2026-07-06 21:11:44.354796+00	2026-07-07 06:38:53.314236+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834238823.json	2026-07-06 21:11:44.354796+00
175	thecrag	7834240767	route	109	\N	fair-head	130	123	done	\N	done	\N	0	\N	\N	2026-07-07 06:38:25.465894+00	2026-07-06 21:11:44.370145+00	2026-07-07 06:38:53.325491+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834240767.json	2026-07-06 21:11:44.370145+00
176	thecrag	7834241331	route	109	\N	fair-head	130	124	done	\N	done	\N	0	\N	\N	2026-07-07 06:38:25.465894+00	2026-07-06 21:11:44.386315+00	2026-07-07 06:38:53.335202+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834241331.json	2026-07-06 21:11:44.386315+00
182	thecrag	7834247883	route	109	\N	fair-head	130	130	done	\N	done	\N	0	\N	\N	2026-07-07 06:38:25.465894+00	2026-07-06 21:11:44.485613+00	2026-07-07 06:38:53.346023+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834247883.json	2026-07-06 21:11:44.485613+00
184	thecrag	7834248351	route	109	\N	fair-head	130	132	done	\N	needs_review	{protection,protection_style,belays,character,feature,incline}	0	\N	\N	2026-07-07 06:38:53.362015+00	2026-07-06 21:11:44.514166+00	2026-07-07 06:39:20.509794+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834248351.json	2026-07-06 21:11:44.514166+00
185	thecrag	7834248927	route	109	\N	fair-head	130	133	done	\N	needs_review	{protection,protection_style,belays,character,feature,incline}	0	\N	\N	2026-07-07 06:38:53.362015+00	2026-07-06 21:11:44.529179+00	2026-07-07 06:39:20.519744+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834248927.json	2026-07-06 21:11:44.529179+00
186	thecrag	7834249158	route	109	\N	fair-head	130	134	done	\N	needs_review	{protection,protection_style,belays,character,feature,incline}	0	\N	\N	2026-07-07 06:38:53.362015+00	2026-07-06 21:11:44.546083+00	2026-07-07 06:39:20.529016+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834249158.json	2026-07-06 21:11:44.546083+00
187	thecrag	7834249395	route	109	\N	fair-head	130	135	done	\N	needs_review	{protection,protection_style,belays,character,feature,incline}	0	\N	\N	2026-07-07 06:38:53.362015+00	2026-07-06 21:11:44.562602+00	2026-07-07 06:39:20.537891+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834249395.json	2026-07-06 21:11:44.562602+00
37	ukclimbing	53711	route	1	\N	fair-head	55	43	done	\N	done	\N	0	\N	\N	2026-07-07 18:02:18.877115+00	2026-07-06 21:10:28.813062+00	2026-07-07 18:04:18.192426+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53711.json	2026-07-06 21:10:28.813062+00
39	ukclimbing	492862	route	1	\N	fair-head	55	45	done	\N	needs_review	{protection,character,feature}	0	\N	\N	2026-07-07 18:02:18.877115+00	2026-07-06 21:10:28.853875+00	2026-07-07 18:04:18.227638+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/492862.json	2026-07-06 21:10:28.853875+00
40	ukclimbing	53714	route	1	\N	fair-head	55	46	done	\N	done	\N	0	\N	\N	2026-07-07 18:02:18.877115+00	2026-07-06 21:10:28.874027+00	2026-07-07 18:04:18.245106+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53714.json	2026-07-06 21:10:28.874027+00
42	ukclimbing	53716	route	1	\N	fair-head	62	48	done	\N	done	\N	0	\N	\N	2026-07-07 18:02:18.877115+00	2026-07-06 21:10:28.913869+00	2026-07-07 18:04:18.271782+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/53716.json	2026-07-06 21:10:28.913869+00
44	ukclimbing	343330	route	1	\N	fair-head	62	50	done	\N	needs_review	{protection_style}	0	\N	\N	2026-07-07 18:02:18.877115+00	2026-07-06 21:10:28.954335+00	2026-07-07 18:04:18.384652+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/343330.json	2026-07-06 21:10:28.954335+00
45	ukclimbing	596537	route	1	\N	fair-head	62	51	done	\N	done	\N	0	\N	\N	2026-07-07 18:02:18.877115+00	2026-07-06 21:10:28.974212+00	2026-07-07 18:04:18.428946+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/596537.json	2026-07-06 21:10:28.974212+00
54	ukclimbing	52886	route	1	\N	fair-head	72	60	done	\N	needs_review	{incline}	0	\N	\N	2026-07-07 18:04:18.446599+00	2026-07-06 21:10:29.168095+00	2026-07-07 18:06:58.162416+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52886.json	2026-07-06 21:10:29.168095+00
55	ukclimbing	52887	route	1	\N	fair-head	72	61	done	\N	needs_review	{protection,character,incline}	0	\N	\N	2026-07-07 18:04:18.446599+00	2026-07-06 21:10:29.188665+00	2026-07-07 18:06:58.202436+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/52887.json	2026-07-06 21:10:29.188665+00
95	ukclimbing	116387	route	1	\N	fair-head	111	101	done	\N	needs_review	{protection,character,feature}	0	\N	\N	2026-07-07 18:10:50.228587+00	2026-07-06 21:10:30.053822+00	2026-07-07 18:13:22.007638+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/116387.json	2026-07-06 21:10:30.053822+00
103	ukclimbing	757066	route	1	\N	fair-head	124	109	done	\N	needs_review	{protection_style}	0	\N	\N	2026-07-07 18:13:22.031362+00	2026-07-06 21:10:30.221817+00	2026-07-07 18:14:53.32293+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/757066.json	2026-07-06 21:10:30.221817+00
104	ukclimbing	220134	route	1	\N	fair-head	125	110	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:13:22.031362+00	2026-07-06 21:10:30.242003+00	2026-07-07 18:14:53.332808+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/ukclimbing/220134.json	2026-07-06 21:10:30.242003+00
192	thecrag	7834199415	route	111	\N	fair-head	55	44	done	\N	needs_review	{protection,protection_style,belays,character,feature,incline}	0	\N	\N	2026-07-07 06:38:53.362015+00	2026-07-06 21:12:07.602509+00	2026-07-07 06:39:20.487164+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834199415.json	2026-07-06 21:12:07.602509+00
193	thecrag	7834199664	route	111	\N	fair-head	55	45	done	\N	needs_review	{protection,character}	0	\N	\N	2026-07-07 18:15:09.885394+00	2026-07-06 21:12:07.619046+00	2026-07-07 18:15:40.412502+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834199664.json	2026-07-06 21:12:07.619046+00
194	thecrag	7834199895	route	111	\N	fair-head	55	46	done	\N	needs_review	{protection,character}	0	\N	\N	2026-07-07 18:15:09.885394+00	2026-07-06 21:12:07.634492+00	2026-07-07 18:15:40.425989+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834199895.json	2026-07-06 21:12:07.634492+00
195	thecrag	4584907635	route	112	\N	fair-head	62	54	done	\N	needs_review	{protection,character}	0	\N	\N	2026-07-07 18:15:09.885394+00	2026-07-06 21:12:14.24452+00	2026-07-07 18:15:40.438891+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/4584907635.json	2026-07-06 21:12:14.24452+00
196	thecrag	7816335711	route	112	\N	fair-head	62	53	done	\N	needs_review	{protection,character}	0	\N	\N	2026-07-07 18:15:09.885394+00	2026-07-06 21:12:14.259255+00	2026-07-07 18:15:40.450867+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7816335711.json	2026-07-06 21:12:14.259255+00
197	thecrag	7834169595	route	112	\N	fair-head	62	47	done	\N	needs_review	{protection,character}	0	\N	\N	2026-07-07 18:15:09.885394+00	2026-07-06 21:12:14.273756+00	2026-07-07 18:15:40.461722+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834169595.json	2026-07-06 21:12:14.273756+00
198	thecrag	7834169838	route	112	\N	fair-head	62	48	done	\N	needs_review	{protection,character}	0	\N	\N	2026-07-07 18:15:09.885394+00	2026-07-06 21:12:14.28728+00	2026-07-07 18:15:40.475466+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834169838.json	2026-07-06 21:12:14.28728+00
199	thecrag	7834170087	route	112	\N	fair-head	62	49	done	\N	needs_review	{protection,character}	0	\N	\N	2026-07-07 18:15:09.885394+00	2026-07-06 21:12:14.301957+00	2026-07-07 18:15:40.523331+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834170087.json	2026-07-06 21:12:14.301957+00
200	thecrag	7834170456	route	112	\N	fair-head	62	50	done	\N	needs_review	{protection,character}	0	\N	\N	2026-07-07 18:15:09.885394+00	2026-07-06 21:12:14.315468+00	2026-07-07 18:15:40.585782+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834170456.json	2026-07-06 21:12:14.315468+00
201	thecrag	7834170954	route	112	\N	fair-head	62	51	done	\N	needs_review	{protection,character}	0	\N	\N	2026-07-07 18:15:09.885394+00	2026-07-06 21:12:14.32926+00	2026-07-07 18:15:40.652778+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834170954.json	2026-07-06 21:12:14.32926+00
202	thecrag	7834171647	route	112	\N	fair-head	62	52	done	\N	needs_review	{protection,character}	0	\N	\N	2026-07-07 18:15:09.885394+00	2026-07-06 21:12:14.343731+00	2026-07-07 18:15:40.665439+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834171647.json	2026-07-06 21:12:14.343731+00
238	thecrag	7834298523	route	114	\N	fair-head	135	186	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:16:45.48755+00	2026-07-06 21:12:28.571098+00	2026-07-07 18:16:53.186403+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834298523.json	2026-07-06 21:12:28.571098+00
242	thecrag	7834299525	route	114	\N	fair-head	135	190	done	\N	needs_review	{protection,character,feature,incline}	0	\N	\N	2026-07-07 18:16:45.48755+00	2026-07-06 21:12:28.634071+00	2026-07-07 18:16:53.230484+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834299525.json	2026-07-06 21:12:28.634071+00
247	thecrag	7834179615	route	117	\N	fair-head	122	108	done	\N	done	\N	0	\N	\N	2026-07-07 18:16:53.24897+00	2026-07-06 21:13:08.280957+00	2026-07-07 18:17:11.629699+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/7834179615.json	2026-07-06 21:13:08.280957+00
248	thecrag	14070115	route	118	\N	fair-head	124	196	done	\N	done	\N	0	\N	\N	2026-07-07 18:16:53.24897+00	2026-07-06 21:13:14.646023+00	2026-07-07 18:17:11.640405+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/14070115.json	2026-07-06 21:13:14.646023+00
249	thecrag	14070175	route	118	\N	fair-head	124	197	done	\N	done	\N	0	\N	\N	2026-07-07 18:16:53.24897+00	2026-07-06 21:13:14.662858+00	2026-07-07 18:17:11.649711+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/14070175.json	2026-07-06 21:13:14.662858+00
250	thecrag	14070235	route	118	\N	fair-head	124	198	done	\N	done	\N	0	\N	\N	2026-07-07 18:16:53.24897+00	2026-07-06 21:13:14.678021+00	2026-07-07 18:17:11.660487+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/14070235.json	2026-07-06 21:13:14.678021+00
251	thecrag	14070481	route	118	\N	fair-head	124	199	done	\N	done	\N	0	\N	\N	2026-07-07 18:16:53.24897+00	2026-07-06 21:13:14.693603+00	2026-07-07 18:17:11.671716+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/14070481.json	2026-07-06 21:13:14.693603+00
252	thecrag	14071273	route	118	\N	fair-head	124	200	done	\N	done	\N	0	\N	\N	2026-07-07 18:16:53.24897+00	2026-07-06 21:13:14.710121+00	2026-07-07 18:17:11.682453+00	/Users/micheluncini/dev/climbing-agent/db/.raw_cache/thecrag/14071273.json	2026-07-06 21:13:14.710121+00
\.


--
-- Data for Name: discipline; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.discipline (code, meaning) FROM stdin;
trad	Leader-placed removable protection.
sport	Pre-placed bolts.
multi-pitch	Multiple rope-lengths with belay stances (the platform's focus).
single-pitch	One rope-length.
alpine	Mountain approach, altitude, mixed commitment.
big-wall	Multi-day / very long.
bouldering	Ropeless, low, over pads.
ice	Frozen falls/ice (WI grades).
mixed	Rock + ice (M grades).
snow	Snow climbing.
aid	Weighting gear to progress (A/C grades).
deepwatersolo	Ropeless over water (DWS).
tr	Top-rope.
via-ferrata	Protected cabled route.
scrambling	Easy ungraded/Grade 1-3 terrain between walking and climbing — approach ridges, easy alpine crests.
\.


--
-- Data for Name: external_ref; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.external_ref (entity_type, entity_id, source_id, external_id, url) FROM stdin;
area	1	dev-fixtures	area:Scotland	\N
area	2	dev-fixtures	area:Wales	\N
area	3	dev-fixtures	area:England	\N
area	4	dev-fixtures	area:Northern Ireland	\N
area	5	dev-fixtures	area:Spain	\N
area	6	dev-fixtures	area:France	\N
area	7	dev-fixtures	area:Croatia	\N
area	8	dev-fixtures	area:Assynt	\N
area	9	dev-fixtures	area:Snowdonia	\N
area	10	dev-fixtures	area:Gower	\N
area	11	dev-fixtures	area:Lake District	\N
area	12	dev-fixtures	area:Antrim	\N
area	13	dev-fixtures	area:Sierra de Gredos	\N
area	14	dev-fixtures	area:Écrins	\N
area	15	dev-fixtures	area:Paklenica	\N
area	16	dev-fixtures	area:Old Man of Stoer	\N
area	17	dev-fixtures	area:Idwal Slabs	\N
area	18	dev-fixtures	area:Three Cliffs Bay	\N
area	19	dev-fixtures	area:Gimmer Crag	\N
area	20	dev-fixtures	area:Fair Head	\N
area	21	dev-fixtures	area:Los Galayos	\N
area	22	dev-fixtures	area:Aiguille Dibona	\N
area	23	dev-fixtures	area:Anica Kuk	\N
route	1	dev-fixtures	route:Original Route	\N
route	2	dev-fixtures	route:Tennis Shoe	\N
route	3	dev-fixtures	route:Scavenger	\N
route	4	dev-fixtures	route:Ash Tree Slabs	\N
route	5	dev-fixtures	route:Girona	\N
route	6	dev-fixtures	route:Sur Clásica (Punta Margarita)	\N
route	7	dev-fixtures	route:Voie Boell	\N
route	8	dev-fixtures	route:Mosoraški	\N
route	9	ukclimbing	420411	https://www.ukclimbing.com/logbook/crags/fair_head-17029/nobody_move-420411
route	10	ukclimbing	420412	https://www.ukclimbing.com/logbook/crags/fair_head-17029/nobody_get_hurt-420412
route	11	ukclimbing	51508	https://www.ukclimbing.com/logbook/crags/fair_head-17029/poor_relation-51508
route	12	ukclimbing	51510	https://www.ukclimbing.com/logbook/crags/fair_head-17029/raglan_road-51510
route	13	ukclimbing	51514	https://www.ukclimbing.com/logbook/crags/fair_head-17029/doldrum-51514
route	14	ukclimbing	36923	https://www.ukclimbing.com/logbook/crags/fair_head-17029/hurricane-36923
route	15	ukclimbing	379551	https://www.ukclimbing.com/logbook/crags/fair_head-17029/cake_walk-379551
route	16	ukclimbing	36926	https://www.ukclimbing.com/logbook/crags/fair_head-17029/jolly_roger-36926
route	17	ukclimbing	51527	https://www.ukclimbing.com/logbook/crags/fair_head-17029/learning_to_fly-51527
route	18	ukclimbing	800810	https://www.ukclimbing.com/logbook/crags/fair_head-17029/twisted_relations-800810
route	19	ukclimbing	52553	https://www.ukclimbing.com/logbook/crags/fair_head-17029/night_rider-52553
route	20	ukclimbing	52554	https://www.ukclimbing.com/logbook/crags/fair_head-17029/njolds_saga-52554
route	21	ukclimbing	52555	https://www.ukclimbing.com/logbook/crags/fair_head-17029/cu_uladh-52555
route	22	ukclimbing	116391	https://www.ukclimbing.com/logbook/crags/fair_head-17029/the_grey_man-116391
route	23	ukclimbing	52556	https://www.ukclimbing.com/logbook/crags/fair_head-17029/soylent_green-52556
route	24	ukclimbing	629938	https://www.ukclimbing.com/logbook/crags/fair_head-17029/doss_in_choss-629938
route	25	ukclimbing	52574	https://www.ukclimbing.com/logbook/crags/fair_head-17029/zulu-52574
route	26	ukclimbing	36944	https://www.ukclimbing.com/logbook/crags/fair_head-17029/burn_up-36944
route	27	ukclimbing	364671	https://www.ukclimbing.com/logbook/crags/fair_head-17029/abyssinia-364671
route	28	ukclimbing	52575	https://www.ukclimbing.com/logbook/crags/fair_head-17029/the_famished_road-52575
route	29	ukclimbing	52576	https://www.ukclimbing.com/logbook/crags/fair_head-17029/creeper-52576
route	30	ukclimbing	52578	https://www.ukclimbing.com/logbook/crags/fair_head-17029/kraken-52578
route	31	ukclimbing	52579	https://www.ukclimbing.com/logbook/crags/fair_head-17029/cats_malacky-52579
route	32	ukclimbing	52580	https://www.ukclimbing.com/logbook/crags/fair_head-17029/saladin-52580
route	33	ukclimbing	52581	https://www.ukclimbing.com/logbook/crags/fair_head-17029/thran-52581
route	34	ukclimbing	162668	https://www.ukclimbing.com/logbook/crags/fair_head-17029/infidel-162668
route	35	ukclimbing	38805	https://www.ukclimbing.com/logbook/crags/fair_head-17029/born_to_run-38805
route	36	ukclimbing	224056	https://www.ukclimbing.com/logbook/crags/fair_head-17029/crusader-224056
route	37	ukclimbing	226493	https://www.ukclimbing.com/logbook/crags/fair_head-17029/streets_of_fire-226493
route	38	ukclimbing	162544	https://www.ukclimbing.com/logbook/crags/fair_head-17029/white_lightning-162544
route	39	ukclimbing	798188	https://www.ukclimbing.com/logbook/crags/fair_head-17029/lunasa-798188
route	40	ukclimbing	222311	https://www.ukclimbing.com/logbook/crags/fair_head-17029/november-222311
route	41	ukclimbing	800193	https://www.ukclimbing.com/logbook/crags/fair_head-17029/waiting_game-800193
route	42	ukclimbing	226502	https://www.ukclimbing.com/logbook/crags/fair_head-17029/rumours-226502
route	43	ukclimbing	53711	https://www.ukclimbing.com/logbook/crags/fair_head-17029/raven-53711
route	44	ukclimbing	53713	https://www.ukclimbing.com/logbook/crags/fair_head-17029/back_to_the_future_8-53713
route	45	ukclimbing	492862	https://www.ukclimbing.com/logbook/crags/fair_head-17029/blackout-492862
route	46	ukclimbing	53714	https://www.ukclimbing.com/logbook/crags/fair_head-17029/scorpion-53714
route	47	ukclimbing	53715	https://www.ukclimbing.com/logbook/crags/fair_head-17029/something_horrible-53715
route	48	ukclimbing	53716	https://www.ukclimbing.com/logbook/crags/fair_head-17029/walk_on_the_wild_side-53716
route	49	ukclimbing	343329	https://www.ukclimbing.com/logbook/crags/fair_head-17029/un_jour_peut-etre-343329
route	50	ukclimbing	343330	https://www.ukclimbing.com/logbook/crags/fair_head-17029/where_the_wild_things_are-343330
route	51	ukclimbing	596537	https://www.ukclimbing.com/logbook/crags/fair_head-17029/the_navvy-596537
route	52	ukclimbing	676918	https://www.ukclimbing.com/logbook/crags/fair_head-17029/horizon_tides-676918
route	53	ukclimbing	38825	https://www.ukclimbing.com/logbook/crags/fair_head-17029/the_x-men-38825
route	54	ukclimbing	38806	https://www.ukclimbing.com/logbook/crags/fair_head-17029/an_bealach_runda-38806
route	55	ukclimbing	52881	https://www.ukclimbing.com/logbook/crags/fair_head-17029/northern_exposure-52881
route	56	ukclimbing	52882	https://www.ukclimbing.com/logbook/crags/fair_head-17029/waiting_for_the_sun-52882
route	57	ukclimbing	52883	https://www.ukclimbing.com/logbook/crags/fair_head-17029/flashdance-52883
route	58	ukclimbing	52884	https://www.ukclimbing.com/logbook/crags/fair_head-17029/peacadh_marfach-52884
route	59	ukclimbing	52885	https://www.ukclimbing.com/logbook/crags/fair_head-17029/absolute_zero-52885
route	60	ukclimbing	52886	https://www.ukclimbing.com/logbook/crags/fair_head-17029/give_up-52886
route	61	ukclimbing	52887	https://www.ukclimbing.com/logbook/crags/fair_head-17029/dark_forces-52887
route	62	ukclimbing	489387	https://www.ukclimbing.com/logbook/crags/fair_head-17029/tristan-489387
route	63	ukclimbing	453856	https://www.ukclimbing.com/logbook/crags/fair_head-17029/iseult-453856
route	64	ukclimbing	487552	https://www.ukclimbing.com/logbook/crags/fair_head-17029/uisce_faoi_thalamh-487552
route	65	ukclimbing	53209	https://www.ukclimbing.com/logbook/crags/fair_head-17029/the_artful_dodger-53209
route	66	ukclimbing	547464	https://www.ukclimbing.com/logbook/crags/fair_head-17029/avarice-547464
route	67	ukclimbing	531194	https://www.ukclimbing.com/logbook/crags/fair_head-17029/heart_and_soul-531194
route	68	ukclimbing	53212	https://www.ukclimbing.com/logbook/crags/fair_head-17029/blockbuster-53212
route	69	ukclimbing	590044	https://www.ukclimbing.com/logbook/crags/fair_head-17029/the_big_big_movie-590044
route	70	ukclimbing	53213	https://www.ukclimbing.com/logbook/crags/fair_head-17029/herbivore-53213
route	71	ukclimbing	53217	https://www.ukclimbing.com/logbook/crags/fair_head-17029/aifric-53217
route	72	ukclimbing	53218	https://www.ukclimbing.com/logbook/crags/fair_head-17029/easy_rider-53218
route	73	ukclimbing	53221	https://www.ukclimbing.com/logbook/crags/fair_head-17029/batess_motel-53221
route	74	ukclimbing	53222	https://www.ukclimbing.com/logbook/crags/fair_head-17029/solid_mandala-53222
route	75	ukclimbing	53320	https://www.ukclimbing.com/logbook/crags/fair_head-17029/clontarf-53320
route	76	ukclimbing	53321	https://www.ukclimbing.com/logbook/crags/fair_head-17029/roaring_meg-53321
route	77	ukclimbing	116388	https://www.ukclimbing.com/logbook/crags/fair_head-17029/faerie_stories-116388
route	78	ukclimbing	53322	https://www.ukclimbing.com/logbook/crags/fair_head-17029/cuchulainn-53322
route	79	ukclimbing	53325	https://www.ukclimbing.com/logbook/crags/fair_head-17029/viking-53325
route	80	ukclimbing	168293	https://www.ukclimbing.com/logbook/crags/fair_head-17029/lochlannach-168293
route	81	ukclimbing	168292	https://www.ukclimbing.com/logbook/crags/fair_head-17029/waist_deep_in_alligators-168292
route	82	ukclimbing	53335	https://www.ukclimbing.com/logbook/crags/fair_head-17029/licence_to_kill-53335
route	83	ukclimbing	53336	https://www.ukclimbing.com/logbook/crags/fair_head-17029/cool_hand_luke-53336
route	84	ukclimbing	53341	https://www.ukclimbing.com/logbook/crags/fair_head-17029/flying_lizards-53341
route	85	ukclimbing	53342	https://www.ukclimbing.com/logbook/crags/fair_head-17029/smashing_pumpkins-53342
route	86	ukclimbing	343328	https://www.ukclimbing.com/logbook/crags/fair_head-17029/full_of_energy_ready_2_party-343328
route	87	ukclimbing	53343	https://www.ukclimbing.com/logbook/crags/fair_head-17029/the_stoat-53343
route	88	ukclimbing	468618	https://www.ukclimbing.com/logbook/crags/fair_head-17029/judgement_day-468618
route	89	ukclimbing	772861	https://www.ukclimbing.com/logbook/crags/fair_head-17029/terminator-772861
route	90	ukclimbing	53344	https://www.ukclimbing.com/logbook/crags/fair_head-17029/heaven_can_wait-53344
route	91	ukclimbing	53345	https://www.ukclimbing.com/logbook/crags/fair_head-17029/promised_land-53345
route	92	ukclimbing	724709	https://www.ukclimbing.com/logbook/crags/fair_head-17029/resurrection-724709
route	93	ukclimbing	53347	https://www.ukclimbing.com/logbook/crags/fair_head-17029/blind_pew-53347
route	94	ukclimbing	53349	https://www.ukclimbing.com/logbook/crags/fair_head-17029/mizen_star-53349
route	95	ukclimbing	53353	https://www.ukclimbing.com/logbook/crags/fair_head-17029/the_fame_game-53353
route	96	ukclimbing	194012	https://www.ukclimbing.com/logbook/crags/fair_head-17029/the_rathlin_effect-194012
route	97	ukclimbing	116385	https://www.ukclimbing.com/logbook/crags/fair_head-17029/below_and_behold-116385
route	98	ukclimbing	52848	https://www.ukclimbing.com/logbook/crags/fair_head-17029/the_wall_of_prey-52848
route	99	ukclimbing	52849	https://www.ukclimbing.com/logbook/crags/fair_head-17029/the_wall_of_prey_direct_start-52849
route	100	ukclimbing	52851	https://www.ukclimbing.com/logbook/crags/fair_head-17029/phil-52851
route	101	ukclimbing	116387	https://www.ukclimbing.com/logbook/crags/fair_head-17029/styx-116387
route	102	ukclimbing	51528	https://www.ukclimbing.com/logbook/crags/fair_head-17029/hells_kitchen-51528
route	103	ukclimbing	52853	https://www.ukclimbing.com/logbook/crags/fair_head-17029/manannan-52853
route	104	ukclimbing	38815	https://www.ukclimbing.com/logbook/crags/fair_head-17029/ocean_boulevard-38815
route	105	ukclimbing	36938	https://www.ukclimbing.com/logbook/crags/fair_head-17029/aoife-36938
route	106	ukclimbing	36937	https://www.ukclimbing.com/logbook/crags/fair_head-17029/girona-36937
route	107	ukclimbing	52870	https://www.ukclimbing.com/logbook/crags/fair_head-17029/odyssey-52870
route	108	ukclimbing	52871	https://www.ukclimbing.com/logbook/crags/fair_head-17029/dearg_doom-52871
route	109	ukclimbing	757066	https://www.ukclimbing.com/logbook/crags/fair_head-17029/tangled_traverse-757066
route	110	ukclimbing	220134	https://www.ukclimbing.com/logbook/crags/fair_head-17029/kashubia-220134
route	9	thecrag	7834342203	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834342203
route	10	thecrag	7834342464	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834342464
route	113	thecrag	4584917313	https://www.thecrag.com/en/climbing/ireland/fair-head/route/4584917313
route	114	thecrag	4584922620	https://www.thecrag.com/en/climbing/ireland/fair-head/route/4584922620
route	115	thecrag	7816306374	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7816306374
route	116	thecrag	7816307265	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7816307265
route	117	thecrag	7834188216	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834188216
route	118	thecrag	7834188966	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834188966
route	119	thecrag	7834190028	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834190028
route	120	thecrag	7834192530	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834192530
route	121	thecrag	7834195650	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834195650
route	122	thecrag	7834238823	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834238823
route	123	thecrag	7834240767	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834240767
route	124	thecrag	7834241331	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834241331
route	125	thecrag	7834241568	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834241568
route	126	thecrag	7834241805	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834241805
route	127	thecrag	7834245591	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834245591
route	128	thecrag	7834247412	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834247412
route	129	thecrag	7834247646	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834247646
route	130	thecrag	7834247883	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834247883
route	131	thecrag	7834248114	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834248114
route	132	thecrag	7834248351	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834248351
route	133	thecrag	7834248927	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834248927
route	134	thecrag	7834249158	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834249158
route	135	thecrag	7834249395	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834249395
route	136	thecrag	7834249629	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834249629
route	54	thecrag	4584907635	https://www.thecrag.com/en/climbing/ireland/fair-head/route/4584907635
route	53	thecrag	7816335711	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7816335711
route	47	thecrag	7834169595	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834169595
route	48	thecrag	7834169838	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834169838
route	49	thecrag	7834170087	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834170087
route	50	thecrag	7834170456	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834170456
route	51	thecrag	7834170954	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834170954
route	52	thecrag	7834171647	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834171647
route	55	thecrag	7834172703	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834172703
route	56	thecrag	7834172940	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834172940
route	153	thecrag	7834327389	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834327389
route	154	thecrag	7834327689	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834327689
route	155	thecrag	7834327926	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834327926
route	156	thecrag	7834328163	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834328163
route	157	thecrag	7834328973	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834328973
route	68	thecrag	7816333950	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7816333950
route	62	thecrag	7834356108	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834356108
route	63	thecrag	7834356339	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834356339
route	64	thecrag	7834356570	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834356570
route	65	thecrag	7834357353	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834357353
route	66	thecrag	7834357593	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834357593
route	67	thecrag	7834357824	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834357824
route	69	thecrag	7834358880	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834358880
route	70	thecrag	7834359126	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834359126
route	71	thecrag	7834360146	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834360146
route	72	thecrag	7834360377	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834360377
route	73	thecrag	7834361415	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834361415
route	74	thecrag	7834361709	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834361709
route	75	thecrag	7834362186	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834362186
route	172	thecrag	7816358109	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7816358109
route	173	thecrag	7816355619	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7816355619
route	174	thecrag	7816361481	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7816361481
route	175	thecrag	7816367586	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7816367586
route	176	thecrag	7816371936	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7816371936
route	177	thecrag	7816386375	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7816386375
route	178	thecrag	7834291074	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834291074
route	179	thecrag	7834291317	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834291317
route	180	thecrag	7834292130	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834292130
route	181	thecrag	7834292349	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834292349
route	182	thecrag	7834292580	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834292580
route	183	thecrag	7834296903	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834296903
route	184	thecrag	7834297242	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834297242
route	185	thecrag	7834298199	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834298199
route	186	thecrag	7834298523	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834298523
route	187	thecrag	7834298766	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834298766
route	188	thecrag	7834299027	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834299027
route	189	thecrag	7834299258	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834299258
route	190	thecrag	7834299525	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834299525
route	191	thecrag	7834299816	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834299816
route	192	thecrag	7834300527	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834300527
route	193	thecrag	7834301622	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834301622
route	107	thecrag	7834179147	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834179147
route	108	thecrag	7834179615	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834179615
route	196	thecrag	14070115	https://www.thecrag.com/en/climbing/ireland/fair-head/route/14070115
route	197	thecrag	14070175	https://www.thecrag.com/en/climbing/ireland/fair-head/route/14070175
route	198	thecrag	14070235	https://www.thecrag.com/en/climbing/ireland/fair-head/route/14070235
route	199	thecrag	14070481	https://www.thecrag.com/en/climbing/ireland/fair-head/route/14070481
route	200	thecrag	14071273	https://www.thecrag.com/en/climbing/ireland/fair-head/route/14071273
route	201	thecrag	14071519	https://www.thecrag.com/en/climbing/ireland/fair-head/route/14071519
route	202	thecrag	14071639	https://www.thecrag.com/en/climbing/ireland/fair-head/route/14071639
route	203	thecrag	14071747	https://www.thecrag.com/en/climbing/ireland/fair-head/route/14071747
route	204	thecrag	14072191	https://www.thecrag.com/en/climbing/ireland/fair-head/route/14072191
route	110	thecrag	7834227774	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834227774
route	1051	dev-fixtures	e2e-test-route	\N
route	40	thecrag	7834196592	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834196592
route	42	thecrag	7834198353	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834198353
route	43	thecrag	7834198953	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834198953
route	44	thecrag	7834199415	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834199415
route	45	thecrag	7834199664	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834199664
route	46	thecrag	7834199895	https://www.thecrag.com/en/climbing/ireland/fair-head/route/7834199895
route	214	multipitch	10	https://multi-pitch.com/climbs/wreakers-slab-on-cornakey-cliff/
route	215	multipitch	11	https://multi-pitch.com/climbs/south-ridge-on-cir-mhor/
route	216	multipitch	12	https://multi-pitch.com/climbs/esparraguera-on-roca-gris/
route	217	multipitch	13	https://multi-pitch.com/climbs/roaring-forties-on-sail-rock/
route	218	multipitch	14	https://multi-pitch.com/climbs/pegasus-on-chair-ladder/
route	219	multipitch	15	https://multi-pitch.com/climbs/durance-on-the-devils-tower/
route	220	multipitch	16	https://multi-pitch.com/climbs/longlands-continuation-on-lliwedd/
route	221	multipitch	17	https://multi-pitch.com/climbs/sydpillaren-on-stetind/
route	222	multipitch	18	https://multi-pitch.com/climbs/keswick-brothers-climb-on-scafell/
route	223	multipitch	19	https://multi-pitch.com/climbs/joy-on-mount-indefatigable/
route	224	multipitch	2	https://multi-pitch.com/climbs/doorpost-on-bosigran/
route	225	multipitch	20	https://multi-pitch.com/climbs/poetic-justice-on-slieve-beg/
route	247	multipitch	21	https://multi-pitch.com/climbs/gweilo-via-topcat-on-lion-rock/
route	248	multipitch	22	https://multi-pitch.com/climbs/diedro-ubsa-on-peñón-de-ifach/
route	249	multipitch	23	https://multi-pitch.com/climbs/traumpfeiler-on-heiliger-geist/
route	250	multipitch	24	https://multi-pitch.com/climbs/visite-obligatoire-on-aiguille-dibona/
route	251	multipitch	25	https://multi-pitch.com/climbs/direkte-plattenwand-on-brüggler/
route	252	multipitch	26	https://multi-pitch.com/climbs/piaz-arete-delagokante-on-vajolet-towers/
route	253	multipitch	28	https://multi-pitch.com/climbs/mendez-and-guillermo-on-cathedral-rock/
route	254	multipitch	29	https://multi-pitch.com/climbs/right-hand-route-on-wintours-leap/
route	255	multipitch	3	https://multi-pitch.com/climbs/great-slab-on-clogwyn-dur-arddu/
route	1	multipitch	1	https://multi-pitch.com/climbs/original-route-on-old-man-of-stoer/
route	256	multipitch	30	https://multi-pitch.com/climbs/morpheus-on-avon-gorge/
route	257	multipitch	32	https://multi-pitch.com/climbs/le-merinos-on-freÿr/
route	258	multipitch	33	https://multi-pitch.com/climbs/normal-route-on-grande-fermeda/
route	259	multipitch	34	https://multi-pitch.com/climbs/original-route-on-old-man-of-hoy/
route	260	multipitch	35	https://multi-pitch.com/climbs/east-buttress-on-ksar-rock/
route	261	multipitch	37	https://multi-pitch.com/climbs/high-sierra-on-high-sierra-dome/
route	262	multipitch	38	https://multi-pitch.com/climbs/pinnacle-slab-on-amzkhssan-wall/
route	263	multipitch	39	https://multi-pitch.com/climbs/donkey-serenades-on-lower-eagle-crag/
route	264	multipitch	4	https://multi-pitch.com/climbs/bulgaria-1300-on-vratsa/
route	265	multipitch	40	https://multi-pitch.com/climbs/east-ridge-on-great-tor/
route	266	multipitch	41	https://multi-pitch.com/climbs/fm-on-slieve-lamagan/
route	267	multipitch	42	https://multi-pitch.com/climbs/via-maria-on-sass-pordoi-south-face/
route	268	multipitch	43	https://multi-pitch.com/climbs/via-steger-on-sella-towers/
route	269	multipitch	44	https://multi-pitch.com/climbs/espolón-central-on-puig-campana/
route	270	multipitch	45	https://multi-pitch.com/climbs/australia-west-face-on-dinorwic-quarry/
route	271	multipitch	46	https://multi-pitch.com/climbs/cneifion-arete-on-cwm-cneifion/
route	272	multipitch	47	https://multi-pitch.com/climbs/dos-hermanos-on-penya-roc/
route	273	multipitch	48	https://multi-pitch.com/climbs/via-pany-on-peñón-de-ifach/
route	274	multipitch	49	https://multi-pitch.com/climbs/the-sheugh-on-buzzards-roost/
route	275	multipitch	5	https://multi-pitch.com/climbs/cnoc-na-mara-on-tormore-group/
route	276	multipitch	50	https://multi-pitch.com/climbs/virgo-on-pigeon-rock/
route	277	multipitch	51	https://multi-pitch.com/climbs/rincón-de-placa-on-el-castellet/
route	278	multipitch	52	https://multi-pitch.com/climbs/grooved-arete-on-tryfan/
route	279	multipitch	53	https://multi-pitch.com/climbs/aristotles-on-puig-campana/
route	280	multipitch	54	https://multi-pitch.com/climbs/sammy-higgins-on-eagle-mountain/
route	281	multipitch	6	https://multi-pitch.com/climbs/fedele-on-sass-pordoi/
route	282	multipitch	7	https://multi-pitch.com/climbs/ordinary-route-on-cwm-idwal/
route	283	multipitch	8	https://multi-pitch.com/climbs/the-devils-slide-on-lundy/
route	284	multipitch	9	https://multi-pitch.com/climbs/queles-on-meadinha/
\.


--
-- Data for Name: feature; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.feature (code, meaning) FROM stdin;
slab	Rock below vertical — friction and balance rather than pulling.
face	An open wall climbed on holds rather than a crack line.
crack	A fissure taking jams and natural protection — the classic trad medium.
ridge	A long crest line with exposure on both sides — alpine-flavoured climbing.
arête	A narrow outward-pointing edge or prow — climbed on or beside it, exposed on both sides.
chimney	A crack wide enough to fit the whole body inside; climbed by back-and-footing.
corner	An inside angle where two faces meet (dihedral / open book) — the opposite of an arête.
groove	A shallow rounded corner or scoop, often climbed by bridging.
roof	A horizontal overhang crossed on its underside.
offwidth	A crack too wide to jam and too narrow to chimney — awkward, specialist technique and big gear.
flake	A partly-detached sheet of rock forming an edge or crack behind it — check it is attached.
tufa	Calcite ribs and blobs left by flowing water on limestone; pinched rather than pulled.
pockets	Holes or solution pockets used as holds (limestone / conglomerate).
pillar	A free-standing or semi-detached column of rock.
bulge	A rounded steepening passed in a move or two — "pull through the bulge"; smaller than a roof.
gully	A wide mountain cleft or couloir line — common on UK/Irish mountain crags; often loose or wet.
ramp	An inclined ledge or weakness trending diagonally across steeper rock.
\.


--
-- Data for Name: first_ascent; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.first_ascent (route_id, kind, climber, year, style_code) FROM stdin;
\.


--
-- Data for Name: grade_conversion; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.grade_conversion (grade_system_code, original_grade, data_grade) FROM stdin;
BAS	D 3a	1
BAS	D 3b	1
BAS	VD 3c	2
UIAA	IV−	2
BAS	S 3c	3
BAS	S 4a	3
BAS	S 4b	3
YDS	5.7	3
FS	f4c	3
BAS	HS 4a	4
BAS	HS 4b	4
UIAA	IV+	4
ALP	D	4
BAS	VS 4b	5
BAS	VS 4c	5
BAS	VS 5a	5
UIAA	V+	5
YDS	5.8	5
FS	f5a	5
BAS	HVS 5b	6
BAS	HVS 5c	6
BAS	E1 5b	7
UIAA	VI+	7
ALP	TD	7
FS	f6b	7
N	N6−	7
\.


--
-- Data for Name: grade_system; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.grade_system (code, name, region, discipline, example) FROM stdin;
BAS	British Adjectival (adjective + technical)	UK/Ireland	rock	VS 4c, HVS 5b, E1 5b
UIAA	UIAA	Alps/Germany	rock	IV−, V+, VI+
YDS	Yosemite Decimal	US	rock	5.7, 5.10a
ALP	Alpine (overall commitment)	Alps	alpine	PD, AD, D, TD, ED
FS	French Sport	Europe/sport	rock	f4c, f6a+
N	Norwegian/Scandinavian	Scandinavia	rock	N6−
EW	Ewbank	Australia/NZ/ZA	rock	18, 24
SX	Saxon (Dresden)	Saxon Switzerland	rock	VIIb, VIIIa
BRZ	Brazilian (overall + technical)	Brazil	rock	VIsup, 7b
V	Hueco / V-scale	US	bouldering	V0, V7
Font	Fontainebleau	Europe	bouldering	6a+, 7c
WI	Water ice	worldwide	ice	WI3, WI5
AI	Alpine ice	worldwide	ice	AI3
M	Mixed (rock + ice)	worldwide	mixed	M6, M8
D	Drytooling	worldwide	mixed	D8
SCO	Scottish Winter (overall + technical)	Scotland	mixed	VI,7
A	Aid	worldwide	aid	A2
C	Clean aid	worldwide	aid	C3
VF	Via ferrata (Hüsler/Schall)	Alps	via-ferrata	K3, C
S	DWS seriousness (tide/depth/fall risk)	UK	deepwatersolo	S0–S3
\.


--
-- Data for Name: guide; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.guide (id, slug, title, subtitle, area_id, series, edition, status, intro_md, access_md, logistics_md, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: guide_edition; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.guide_edition (guide_id, edition, frozen, frozen_at) FROM stdin;
\.


--
-- Data for Name: guide_route; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.guide_route (guide_id, section_id, route_id, "position", note_md) FROM stdin;
\.


--
-- Data for Name: guide_section; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.guide_section (id, guide_id, "position", kind, title, body_md, area_id) FROM stdin;
\.


--
-- Data for Name: guidebook; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.guidebook (id, isbn, title, rrp, img_url, link, kind) FROM stdin;
3	9781906095581	Scottish Rock, Volume 1, South	25	img/guidebooks/scottish-rock-volume-1.jpg	https://amzn.to/2EmsTCn	guidebook
6	9781493016129	Rock Climbing Wyoming	20	img/guidebooks/rock-climbing-wyoming.jpg	https://amzn.to/2Ep6xjN	guidebook
8	0901601616	Lliwedd	10	img/guidebooks/lliwedd-guidebook.jpg	https://amzn.to/2TYdPUI	guidebook
9	9781873341230	Lofoten Climbs	34.99	img/guidebooks/loften-climbs.jpg	https://amzn.to/2S4G1A6	guidebook
10	9780850280555	Scafell & Wasdale	25	img/guidebooks/Scafell-Wasdale-climbing-guidebook.jpg	https://amzn.to/2Bp4EjV	guidebook
11	9780986519109	Canadian Rock: Select Climbs of the West	34.99	img/guidebooks/canadian-rock-select-climbs-of-the-west.jpg	https://amzn.to/2BkLsnn	guidebook
4	no ISBN	Lion Rock	FREE	img/guidebooks/rock-climbs-in-hong-kong.jpg	https://hongkongclimbing.files.wordpress.com/2012/06/lionrock.pdf	pdf
16	9780762727179	Rock Climbing Europe	10	img/guidebooks/rock-climbing-europe.jpg	https://amzn.to/2BwCB2b	guidebook
17	9782952638876	Rock Around The World	35	img/guidebooks/rock-around-the-world.jpg	https://amzn.to/2RmOhyX	guidebook
18	9783906087405	Plaisir Selection	38	img/guidebooks/plaisir-selection.jpg	https://amzn.to/2QTmPrH	guidebook
20	9788827219652	La nuova guida del Catinaccio	25	img/guidebooks/new-guide-to-catinaccio-in-the-dolomites.jpg	https://www.amazon.it/nuova-guida-Catinaccio-Ediz-illustrata/dp/882721965X	guidebook
21	9780901601797	Lower Wye Valley	25	img/guidebooks/lower-wye-valley-climbing-guidebook.jpg	https://amzn.to/2XxjnCx	guidebook
22	9781852841553	Selected Rock Climbs in Belgium and Luxembourg	10	img/guidebooks/selected-rock-climbs-in-belgium-and-luxembourg.jpg	https://amzn.to/2ZiZPHr	guidebook
23	9781906095468	Scottish Rock, Volume 2, North	25	img/guidebooks/scottish-rock-volume-2.jpg	https://amzn.to/2C1KKgp	guidebook
24	9780993548628	Climb Tafraout - 100 Classic Climbs	27.95	img/guidebooks/climb-tafraout-100-classic-climbs.jpg	https://amzn.to/32OTqBc	guidebook
25	9780957366602	Morocco Rock: Jebel El Kest & Taskra North	27.5	img/guidebooks/morocco-rock-guidebook.jpg	https://amzn.to/2s3X3pQ	guidebook
26	9786199010518	Vratsa Climbing	24.99	img/guidebooks/vratsa-climbing-guidebook-for-bulgaria.jpg	https://amzn.to/349atQ6	guidebook
27	9781906095369	Gower Rock Selected Rock Climbs	12.99	img/guidebooks/gower-rock-selected-rock-climbs.jpg	https://amzn.to/3bpSwzI	guidebook
28	\N	Classic Rock Climbs in Ulster	18	img/guidebooks/classic-ulster-rock-climbs-guidebook.jpg	https://www.mountaineering.ie/shop/	guidebook
30	9788868392253	Clibing in Val Gardena, Dolomites	24.99	img/guidebooks/climbing-in-val-gardena-dolomites.jpg	https://goo.gl/maps/spCT4ZUHZwQCA3UKA	guidebook
31	9781873341674	Spain: Costa Blanca	29.95	img/guidebooks/costa-blanca.jpg	https://amzn.to/2Emt6Wb	guidebook
32	9780955441769	Llanberis Slate	29.95	img/guidebooks/llanberis-slate-ground-up-guidebook.jpg	https://amzn.to/3uzFTym	guidebook
33	n/a	Dos Hermanos	Free	img/guidebooks/compass-west.png	http://www.compasswest.co.uk/topos/	guidebook
5	9780902940994	Rock Climbing in Donegal	20	img/guidebooks/rock-climbing-in-donegal.jpg	https://amzn.to/2zQOEY3	guidebook
29	9780956787422	Rock Climbing in Ireland	20	img/guidebooks/rock-climbing-in-ireland.jpg	https://amzn.to/32Nqn4q	guidebook
14	9781873341954	Costa Blanca	29.95	img/guidebooks/costa-blanca.jpg	https://amzn.to/2Emt6Wb	guidebook
34	9781786310330	Costa Blanca Mountain Adventures	13.99	img/guidebooks/costa-blanca-mountain-adventures.jpg	https://amzn.to/3Mpfgrm	guidebook
15	9788412230642	Escaladas en Alacant / Selección de itinerarios	35	img/guidebooks/Escaladas-en-Alacant.jpg	https://www.climbing-guide.eu/climbing-guidebook-escaladas-en-alacant-seleccion-de-itinerarios-20004/	guidebook
13	9780902940291	Rock Climbs in the Mourne Mountains	19.95	img/guidebooks/rock-climbs-in-the-mournes-mountains.jpg	https://amzn.to/2SKowVu	guidebook
19	9781873341971	The Dolomites, Rock Climbs and Via Ferrata	29.95	img/guidebooks/the-dolomites-climbing-guide.jpg	https://amzn.to/2NdBIQw	guidebook
7	9781873341827	North Wales Climbs	24.99	img/guidebooks/north-wales-climbs.jpg	https://amzn.to/2RJohKd	guidebook
1	9781873341377	West Country Climbs	24.99	img/guidebooks/west-country-climbs.jpg	https://amzn.to/2UxZN8z	guidebook
12	9781898573708	Classic Rock	29.99	img/guidebooks/classic-rock-by-ken-wilson.jpg	https://amzn.to/3htOMjS	guidebook
2	9781898573470	South West Climbs	19.99	img/guidebooks/south-west-climbs-guidebook.jpg	https://amzn.to/2lT6FRL	guidebook
35	9788898609772	Portugal, Rock climbs on the western tip of Europe	34.95	img/guidebooks/rock-climbs-in-portugal.jpg	https://www.needlesports.com/54396/products/portugal--rock-climbs-on-the-western-tip-of-europe.aspx	guidebook
\.


--
-- Data for Name: hazard; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.hazard (code, kind, meaning, safety_critical, feeds) FROM stdin;
tidal	route	Access/base tide-dependent (sea cliffs).	t	tide-window logic (live 2026-07-05: planner tide tiles, Open-Meteo Marine)
seepage	route	Weeps / holds water after rain.	t	Predictive Condition Algorithm
abseil	route	Requires an abseil (approach/descent).	f	gear & planning
boat	route	Reached by boat or swim.	f	logistics
loose	route	Loose / friable rock.	t	safety
grassLedges	route	Vegetated ledges (wet/awkward).	f	conditions
rockfall	objective	Rockfall-prone (loose gullies, thaw, parties above).	t	safety
avalanche	objective	Avalanche terrain (snow slopes, couloirs).	t	safety
serac	objective	Serac hazard on the approach/route.	t	safety
crevasse	objective	Crevasse hazard on the approach/route.	t	safety
altitude	objective	High enough for thin air / altitude effects.	t	planning
stormExposed	objective	Exposed to lightning / no quick escape in a storm.	t	safety
cornice	objective	Corniced ridge/summit.	t	safety
nesting-birds	route	Seasonal nesting restriction (BMC RAD-style) — the crag or route may be banned in spring/summer.	f	access gating by date
vegetated	route	Dirty or vegetated rock — needs traffic or a dry spell; slower to dry after rain.	f	drying-time model
traverse	route	Sustained sideways climbing — complicates retreat, rope-work and seconding; kept as a hazard because it gates escapability.	f	rope management / commitment
polished	route	Glassy, traffic-polished rock — badly friction-dependent; treacherous when humid or damp (Rockfax condition note).	f	difficulty-in-practice
\.


--
-- Data for Name: incline; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.incline (code, sort_order) FROM stdin;
Slab	1
Slab & Vertical	2
Vertical	3
Slab, Vertical & Overhanging	4
Vertical & Overhanging	5
Overhanging	6
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.media (id, area_id, kind, uri, width_px, height_px, credit, license, permission_note, taken_at, created_at) FROM stdin;
1	16	crag_photo	uploads/topos/mp/1-crag.jpg	3024	4032	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
2	245	crag_photo	uploads/topos/mp/10-crag.jpg	3600	2496	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
3	288	crag_photo	uploads/topos/mp/12-crag.jpg	2800	2800	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
4	242	crag_photo	uploads/topos/mp/14-crag.jpg	3013	1996	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
5	270	crag_photo	uploads/topos/mp/16-crag.jpg	2831	1519	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
6	278	crag_photo	uploads/topos/mp/19-crag.jpg	6000	4000	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
7	235	crag_photo	uploads/topos/mp/2-crag.jpg	4500	2943	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
8	296	crag_photo	uploads/topos/mp/20-crag.jpg	4000	3430	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
9	283	crag_photo	uploads/topos/mp/22-crag.jpg	3278	4765	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
10	307	crag_photo	uploads/topos/mp/26-crag.jpg	4301	5185	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
11	241	crag_photo	uploads/topos/mp/28-crag.jpg	3024	4032	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
12	310	crag_photo	uploads/topos/mp/29-wintours-leap-crag.jpg	2400	2170	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
13	244	crag_photo	uploads/topos/mp/3-crag.jpg	2736	1755	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
14	234	crag_photo	uploads/topos/mp/30-crag.jpg	3600	2969	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
15	258	crag_photo	uploads/topos/mp/32-crag.jpg	3042	2545	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
16	259	crag_photo	uploads/topos/mp/33-crag.jpg	2792	2236	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
17	280	crag_photo	uploads/topos/mp/34-crag.jpg	2055	2144	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
18	267	crag_photo	uploads/topos/mp/35-crag.jpg	4000	3000	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
19	263	crag_photo	uploads/topos/mp/37-crag.jpg	4032	3024	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
20	232	crag_photo	uploads/topos/mp/38-crag.jpg	4000	2976	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
21	272	crag_photo	uploads/topos/mp/39-crag.jpg	3389	3509	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
22	228	crag_photo	uploads/topos/mp/4-crag.jpg	3264	2448	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
23	260	crag_photo	uploads/topos/mp/40-crag.jpg	4000	3000	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
24	297	crag_photo	uploads/topos/mp/41-crag.jpg	3664	3672	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
25	291	crag_photo	uploads/topos/mp/42-crag.jpg	4000	2676	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
26	293	crag_photo	uploads/topos/mp/43-crag.jpg	4000	3000	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
27	286	crag_photo	uploads/topos/mp/44-crag.jpg	3200	2728	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
28	250	crag_photo	uploads/topos/mp/45-crag.jpg	6000	3228	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
29	246	crag_photo	uploads/topos/mp/46-crag.jpg	3672	4896	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
30	283	crag_photo	uploads/topos/mp/48-via-pany-topo.jpg	4816	7368	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
31	237	crag_photo	uploads/topos/mp/49-crag.jpg	2852	2837	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
32	285	crag_photo	uploads/topos/mp/50-crag.jpg	2874	3149	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
33	255	crag_photo	uploads/topos/mp/51-crag.jpg	4000	3000	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
34	306	crag_photo	uploads/topos/mp/52-crag.jpg	1957	1150	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
35	286	crag_photo	uploads/topos/mp/53-crag.jpg	2687	4144	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
36	253	crag_photo	uploads/topos/mp/54-crag.jpg	3072	4096	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
37	247	crag_photo	uploads/topos/mp/7-crag.jpg	4012	2000	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
38	217	crag_photo	uploads/topos/mp/8-crag.jpg	3141	3076	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 09:18:20.131945+00
47	318	crag_photo	uploads/topos/studio/a318-1784314641.jpg	3664	3672	Dan Knight / multi-pitch.com	owned	\N	\N	2026-07-17 18:57:23.497981+00
\.


--
-- Data for Name: pitch; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.pitch (route_id, number, length_m, original_grade, grade_system_code, bolts_count, description) FROM stdin;
256	1	28	4a	\N	\N	Climb the short wall to a ledge with some better gear options. The initial wall does have some good holds, but they are well disguised in the limestone. Once on the first ledge, carefully walk right to a blocky corner. Place gear and move up this a little, before cutting back left. The next belay is a crack on the left side of the white stained block. It allows good protection behind it.
256	2	16	3c	\N	\N	Climb the block either by layback or reaching up and over while moving the feet up. From above the block move slightly right to good holds and climb onto one smaller ledge before moving up to a large ledge with some broken blocks below a corners system with a crack running through it. A belay can be created in the crack below the corner.
256	3	10	4a	\N	\N	Originally not a graded pitch, years of climber’s feet have polished the stone here to make it arguably the hardest part of Morpheus whichever way you climb it. The original route suggests moving up the corner to the piton then moving out to the right before going up to the next belay. Whilst arguably still the easiest option, the move requires the climber to trust their feet on a highly polished hold where the foot slipping mid move could lead to an awkward fall. The alternative is to climb the corner directly. This means harder moves, especially for the shorter climber, however it feels much less exposed in the corner. Once this section is dealt with there are a couple of easy moves up onto a ledge with a stone seat and decent options for an anchor in the wall behind.
256	4	12	3b	\N	\N	This pitch is much easier than it looks. Take good holds diagonally right, initially passing a under a small bush. A belay can be made at the end of the climbing. Alternatively, there is a good tree belay around the corner, however verbal communication with your partner here will be impossible. \r\nIt’s a short scramble up the back wall and a walk off after the tree belay point.
224	1	27	4a	\N	\N	The first pitch starts with easy holds up into a corner before following the striking crack line across and up. There is some delicate footwork required but the hand holds are good and the crack will happily take one to two finger width cams. As the crack ends the climber can climb good holds to a ledge with an option for a sitting belay on the left hand side of the ledge (back to the sea) or you can move further right (back to the sea) for a standing  belay that is shared with the first pitch of the popular little brown jug.
224	2	15	4b	\N	\N	This is a short and interesting pitch. The goal is to climb the twin cracks to a ledge above. The pitch starts with moves out to the left crack. This is climbed up to the crux of the route which sits at the point where the climber has to move from the left crack, to the right crack. Once in the right crack move up to a good ledge with a belay in the corner.
224	3	25	4a	\N	\N	A glorious and easy part of the climb with good protection and incredible exposure as the climb moves onto one of the highest points of the cliff at Bosigran. Follow a reasonably obvious path up good holds to the top, where a belay can be made by slinging a boulder and backed up by large gear if desired.
218	1	32	4b	\N	\N	Climb the wide and obvious crack to the top. The climber can choose their preferred style including layback, crack climbing or bridging. At the top of the crack move up and slightly right to reach a good ledge and belay.
218	2	20	4a	\N	\N	Move out right from the stance and then follow the corner and striking obvious swooping crack that leads up then right. Once the crack ends, follow the ledge all the way to the end. The climber can create a belay there or step over a small crevasse to create a belay on the opposite ledge which has different options for an anchor.
218	3	18	4b	\N	\N	Move back left, reversing the last few meters of pitch two. Then make some steep awkward moves up onto a small ledge. Move left on this and up to another ledge with a slab and a crack that sweeps up and right. This leads to large ledge where a belay can be created before the final walk off.
214	1	40	4a	\N	\N	My experience here is reasonably worthless except to say if you leave the guidebook at the top of the cliff (because who wants to climb with a guide book in their bag), then the chances are you won’t actually know exactly which way to go and may attack the first belay head on. This takes you over loose ground with little or no gear and possibly makes the route a harder grade. Instead I’d recommend you don’t start too far right, climb up a few of meters to where the cliff eases off then traverse all the way left to the arete and head up to the belay.\r\n\r\nThere are 2 pegs that you can use to form part of your belay. I’d highly recommend a 3 or 4 point anchor in addition to them. I placed my gear below the pegs giving a reasonably comfy ledge to belay from. Your nut tool comes in handy to clean the cracks when you lead this pitch!
214	2	40	4b	\N	\N	Head up and around the overhanging block just above the belay. Whilst this is probably the steepest part of the climb it’s not fully vertical making gear placements easier than it looks. Be careful not to throw too many handholds at the belay below and follow the reasonably obvious crack up to a big grassy ledge with a pillar of rock on it.  There are lots of options to build a traditional anchor here. You can use the front of the pillar, side or even the nearby crack further up.
214	3	50	4a	\N	\N	This is where the rock climbing becomes utterly enjoyable. For the most part the rock is solid and there are plenty of placements for gear, the left ridge is recommended with its stunning if a little intense views. Guidebooks suggest the pitch is 45m, but a the full 50m will take you over the top and right a little. A good belay can be built on the other side of the top ridge. Consider belaying your partner off the top 10m walk. It would be a stretch to call it a 4th pitch, but placing a couple of pieces of gear makes it a safer scramble.
254	1	18	3c	\N	\N	Climb the cracked gully diagonally right to get around some bushes then cut back left above them. There is a small stance and a decent tree belay just above the main ledge. The tree can be backed up with some protection in the rock.
254	2	21	4b	\N	\N	The second pitch ups the grade after an easy start. Climb straight up behind the belay past some vegetation. Keep moving up until you’re below a left leaning thin crack that leads to another small ledge with a tree belay (again back it up with the rock). The crack offers good holds and protection but can feel a bit exposed and is a slight step up in the grade, especially if you can’t find the good holds.
254	3	17	4b	\N	\N	Climb up and slightly right onto some ledges. Take the left of two groves, this should have a peg you could use for additional protection. After that there should be a short neat slab and easier ground up onto the great ledge where there is a peg and tree belay at the back. Traversing left on a thin finger ledge before the great ledge offers a lovely if exposed climb with a big mantle move up.
1051	1	30	4a	BAS	\N	Pad up the slab on positive edges, trending left to the ledge below the corner.
1051	2	35	4c	BAS	\N	The corner crack — bridge and jam past the bulge (crux), stance out on the arete.
1051	3	25	4b	BAS	\N	Step right onto the exposed nose; juggy granite to the summit blocks.
254	4	30	4a	\N	\N	A brilliant and rewarding pitch with great protection. Essentially you are looking to head though the broken V shape in the headwall above the ledge. The route has good holds, making it easer than it looks. After the broken V, climb the short wall above and then keep heading up to slings and an abseil ring set up on a tree. You can climb the chimney or the wall directly below the abseil and anchor point. Both are short but fun.
252	1	30	IV	UIAA	\N	For the first proper pitch, climb more or less directly up to the next obvious ledge with a bolted belay point. Modern guidebooks suggest this pitch is the technical crux at grade IV+, but older guides grade it the same as later pitches, at grade IV.
267	1	25	IV	UIAA	\N	The first pitch is just under 25m, and is polished at the start, but has mostly good holds. Starting just left of the big break, climb the short-polished wall, then move left slightly before heading up the cracked section to a large cemented bolt belay.
267	2	35	IV+	UIAA	\N	The crux pitch of the route, moves into the gully a little before heading up the slab on the left. The pitch will steepen after a couple of pitons are passed and the crux will loosely follow a crack on good holds over steep ground protected by another couple of pitons. The pitch finishes on an obvious ledge below a crack, with a bolted belay.
267	3	25	IV	UIAA	\N	A solid pitch that tackles the crack above the belay for 5m before moving left, up and then back right. After this an easier crack leads to a bolted belay on a ledge. Note, the Rockfax guide description is not completely accurate here, i.e. don’t climb 45m.
267	4	40	IV	UIAA	\N	Follow a few pitons up the ramp towards the right side of the triangular roof. There is a bolted intermediate stance around the middle of this pitch, which is a bit of an awkward place to stop. Clipping the belay and moving on, following past a couple more pitons leads to a better belay on a bigger ledge.
267	5	50	III+	UIAA	\N	Traverse right and then up on loose rock using natural protection (some good options for threads). Climb more or less any line up to the block between where the two parts of the mountain meet on the right. A belay can be created on the block next to the main wall where there may already be an in-situ thread. 50m rope will make the block assuming there isn’t lots of zig-zagging.
267	6	35	IV	UIAA	\N	Climb up the block slightly before crossing over to the main wall on good holds in an exposed an airy position. Make a rising traverse all the way out to the right edge, moving up past a niche on the right side (protected by a piton) to reach a belay on a good ledge. From the start of this pitch there will be 4 pocket looking niches higher up on the main wall, the climber is aiming to pass the right most of these on the right.
267	7	50	IV	UIAA	\N	This pitch is likely best broken into two. First traverse right to reach a scoop / shallow cave type structure. Climb up the right side on good holds before moving back left to a position broadly above the last belay at about 25m (depending where protection was placed). A belay point can be created here on using threads and natural protection. If climbing all the way to the summit plateau, head up on good holds, heading for a large pillar above. Move left behind the smaller block (in front of the large pillar) then right up a short chimney to reach the summit plateau which is protected by a bolted anchor.
268	1	25	III+	UIAA	\N	: Starting just left of the plaque, take a left leaning line up reasonably good holds following a couple bits of fixed gear to a good ledge. Head up and left to belay at the large slung block.
268	2	40	\N	UIAA	\N	: Follow the scree covered path left (facing the climb) and up, to create a belay at the official start of the climb.
262	1	50	\N	\N	\N	Start 10m right of the main break and a meter or two left from the outcropping bulge at the base of the wall. Climb up the slabs as far as the rope and any rope drag will allow, until you reach a suitable belay.
262	2	50	\N	\N	\N	Continue up the slab heading to the obvious pinnacle not too far from the top of the wall.
262	3	30	\N	\N	\N	There are a few options to get though the steeper overlap at the top. Take the easier line directly above the pinnacle to create the belay at the top of the wall.
263	1	25	3b	\N	\N	Follow the broken right leading crack up to the ledge below the little overhang. From here head left up the easy slab to belay on one of the ledges.
263	2	40	3c	\N	\N	There are a few options for getting to the so-called party time belay. The route takes the left side of the pillar and moves around to finish on the large ledge system. However, the climber could take the crack on the right side of the pillar in two pitches to follow Pink Lady graded VS 4c. Alternatively the vegetated corner further right sill, follows the Real Men Wear Pink route, also VS. An additional option is to take the clean slab between these two VS lines for some exceptional climbing, with some decent gear options (not graded but also feels like VS).
263	3	30	\N	\N	\N	Follow the right side of the broken slab above the party time belay ledge until reaching a steeper slab covered in black moss, usually in the shadow of the headwall. Build a traditional belay here.
263	4	25	3c	\N	\N	Head up and slightly left on the black mossy slab. There are lots of options for climbing this wall. When approaching the top, look for one of the vertical blocks. Belays can be built around one of the blocks using slings and other gear.
263	5	25	\N	\N	\N	Walk left along the ledge. The climber can follow the low-level crack higher up on the wall, or walk on a lower section. It’s possible to make this into a longer pitch. The 3 pitches (this pitch and the following 2 pitches) can be linked into 2 longer ones if required or if the climbers are short of time.
263	6	25	3c	\N	\N	Follow the steeper right, shady side of the next face. A belay can be created below the next headwall, or if linking pitches, aim to go all the way to the belay ledge below the now obvious, large pinnacle.
263	7	30	\N	\N	\N	Move left towards the short ledges below the large pinnacle. Create an anchor here. Depending on the approach to the next pitch, create the belay further left or right if possible.
263	8	30	3c	\N	\N	The Oxford Alpine guide suggests taking the route left and around the pinnacle, from the top of which the climber can scramble higher to build a final belay. The Morocco Rock guide suggests the climber should take the right grove around the right side of the pinnacle to reach the broken scramble above. A third option is to tackle the pinnacle directly for a much harder but much more impressive finish. The rock looks loose and very steep from below, but upon attacking the pinnacle directly the climber will be surprised to find the rock is solid and there are a number of good stances from which protection can be placed. The Donkey Direct finish is not listed in the guides but is likely not harder than VS and will offer the best possible end to the route if the climber is feeling unchallenged by the climbing up to that point. After building a belay on the ledges above to bring up the last of the party, then the climbers can scramble up to the summit paths without difficulty.
260	1	20	\N	\N	\N	Climb up the stepped slabs. With a good rack, a belay can be build on the 3rd or 4th ledge. Alternatively, moving all the way to the top ledge i.e. the end of ptch two, which is at the base of the crack on the east wall is a good option.
260	2	20	\N	\N	\N	If you haven’t linked this pitch, continue up the blocky slabs, taking the steeper right side of the final block, until you reach a belay at the base of the hand crack on the east wall.
260	3	20	4a	\N	\N	Here the route takes a significant jump in technical difficulty with a short jamming crack. At the top of the crack you gain a ledge, from there take the right hand (east) corner of the large block. This gives way to another ledge where a belay can be made under the significant steepening wall.
260	4	30	3c	\N	\N	Move left along the ledge to an obvious gully. Climb the block in the centre of the gully to the end. The last, steeper block can be climbed a number of ways either directly or via the wide crack on the right-hand side as recommended in the guidebook. A belay can be created on the large ledge.
260	5	15	4a	\N	\N	In the North East corner of the ledge there is a large wide crack system running diagonally left (North-West) to another large ledge. This offers a short and enjoyable pitch.
260	6	20	4b	\N	\N	From the final giant ledge, the sixth pitch takes the right side of the wall up to a small ledge. From here the climber moves into an obvious grove. The grove narrows and the climb steepens until a large and somewhat hollow sounding flake of rock is used to gain the summit in a suitably epic finish to this interesting climb. A belay can be made amongst the blocks behind. A variant to this pitch, graded VS 4b is to take the wide crack directly from the belay ledge before gaining the obvious grove.
261	1	30	5a	\N	\N	Climb the block right the right corner to gain a left sloping ramp. Walk along this ramp to the first bolt. Make the aforementioned hard moves, relying on small holds for both hands and feet. After a couple of tricky moves onto the block the second bolt can be clipped. From here the route moves up and right to increasingly better holds, with some options for gear placements at the top of the slab. From there move onto the right block then left to the bolted anchor. Alternatively, the climber can move past the bolted anchor onto the ledge and create a quick traditional anchor in the start of the second pitch using the crack system and nearby wedged blocks.
261	2	30	4b	\N	\N	Climb the exceptional sloping crack using mostly undercuts all the way around the corner to a traditional gear belay in the corner before the rising flake of the 3rd pitch. Large cams are particularly helpful for protecting this pitch.
261	3	45	4a	\N	\N	Some delicate friction-based climbing on the low angle slab takes the climber to a bolt. Moving up from here a large flake can be used to comfortably move up the slab. Slings on the granite spikes on the top an edge of the flake can offer some additional protection as the climber moves up. The are also some options for gear higher in the giant flake. As the flake moves right the climber can pull up and slightly left onto the flake where there is a single bolt. From here the climber moves up to a crack then a bolted anchor.
261	4	15	4b	\N	\N	From the previous anchor move onto the large plateau. There will be a large boulder with 2 additional smaller boulders on it, one of which has the summit boulder on top. Climb the large wall of the main boulder using the 3 bolts for protection. From here there is easier climbing to the summit boulder and its 2 anchor bolts with an abseil malion. Reaching this is a little runout. From the summit the climbers can abseil back to the plateau and walk off. Whilst there should be a malion on the summit anchor, carrying a spare one would be prudent.
280	1	28	4c	BAS	\N	Follow the corner (dihedral), before moving out right towards the right hand edge (arête) under a short bulge / roof. The rusted peg is now gone. Pass through the gap in the bulge with difficulty (crux) using the main vertical crack. From here proceed up the delicate slab, to exit via steeper rock, onto the large grassy belay ledge.
280	2	18	4b	BAS	\N	Another fantastic pitch with incredible views (although suffers seepage after rain). Climb the gradually widening corner crack to finish on a large block belay at the top on the left wall.
280	3	10	4a	BAS	\N	A short corner wall, offers a few interesting moves to reach the grass ledges and easier ground at the top.Protection Notes: The peg below the crux, on pitch 1, was well rusted in 2026 and disintegrated on touch, like something you would see in a cartoon leaving just a rusty smear there now. Otherwise the gear is good. At least one large cam (big silver DMM number 6 or bigger), may be helpful for the start of the second pitch.
276	1	10	4a	\N	\N	: From the starting ledge climb up to a crack to reach a large triangular block. Climb directly over this to create a belay just behind.
276	2	20	4c	\N	\N	: Climb directly above the belay to a good ledge under a slightly bulging rock / overhang. Pass under this to the left, then move diagonally up and left before eventually mantling onto a decent long ledge. A belay can be made on the far left side (wedged wire at the time of writing).
276	3	30	4b	\N	\N	:  An exposed pitch with less strenuous, but still technical climbing. The pitch has little gear in the middle. The route goes up from the belay to the break (gear placement), before traversing right on small ledges with good footholds and acceptable handholds but no gear. The route then moves up the ledge system, back to the corner above and onto the grassy ledge. Move up this and belay below the corner of the final pitch.
276	4	30	4c	\N	\N	:Climb directly up this corner. Pass the first small block staying in the corner and keep moving up. Move onto the ledge to the left and under the large overhanging block / nose. Another ledge then takes climbers to the end of the technical difficulty where a long low crack line leads left. Follow this and move around it back right to belay above the corner (see topo).
266	1	35	3b	BAS	\N	Climb the white granite slab all the way up to the edge on the right for around 35m. Making sure to not stop short. A belay can be created at the small ledge.
266	2	45	3b	BAS	\N	Move up and slightly left to reach a small overlap. Cross this in the middle.  From there move directly up towards the where the wall steepens. A belay can be created below what looks like some giant left facing steps.
266	3	25	3c	BAS	\N	What looked like some giant steps in the steep wall below represents a significant step up in technical difficulty and a clear crux for the route. Good and somewhat hidden handholds on the right can help the climber get up onto the first large and downward sloping ledge. From here good holds can be used to pass the steep section. If the second is not a strong VDiff / Severe grade climber, then leaving a cam with a long sling to help the second (or third) aid this section might be a sensible move. A Metolius number 1 ultralight TCU works a treat. Creating a belay just above the steep section is an option if desired, otherwise carry on up to a good belay ledge.
266	4	20	3b	BAS	\N	For the finish described in the photo topo, head up and right performing a delicate traverse on good footholds to a decent sized ledge below the bottom right of the n shaped steep headwall.
266	5	25	3c	BAS	\N	The finish described here offers good climbing on slightly brittle and quite steep granite. Whist not perfect, it does offer nice moves in the 3b to 3c range and ends with a wonderful finish on a prominent ridge.
216	1	35	IV+	UIAA	\N	The first pitch moves up to some trees on the ledge then left onto the ridge and directly up the centre of the slab spire to the belay.
216	2	40	V	UIAA	\N	Climb up the spire to some harder moves not long after the belay. These are well protected by bolts and pitons. This pitch then eases off near the top to a belay behind the next spire.
216	3	25	V+	UIAA	\N	Climb the steep face using the big pockets which make for jug sized hand holds. Follow the bolts up onto the summit of this little spire and find the anchor in the gap between the next spire. This pitch is a quite different in style to the others, so although the crux on paper it may feel easy to someone comfortable with bouldering, or particularly tough if you normally stick to slabs.
216	4	50	V	UIAA	\N	A long, exposed climb up the largest spire. Harder moves early on that change into a lower angled slab with no bolts and limited protection options.  The anchor is to the right near where this spire joins the next. Don’t climb to the top of this spire.
216	5	25	IV	UIAA	\N	The is a single bolt on this pitch and no clear path to the next anchor. Moving up to a ledge and wall offers good hand holds and some pockets for protection, before a traverse right to the anchor.
216	6	30	IV+	UIAA	\N	Move straight up following the crack system. There is no fixed protection but a number of placements can be found. Move over a small ledge to the summit. This is a sustained pitch of UIAA grave IV or IV+ all the way. There are no bolts at the top so you will need to sling a bush or two and make sure you are not belaying more weight up than can be comfortably held. If climbing as a 3, it would be safer to belay the 2nd and 3rd climber separately on this pitch.
248	1	15	Grade III	UIAA	\N	Climb up to a large ledge with a bolted anchor below and a little left of the first corner.
248	2	40	GradeV+	UIAA	\N	A contender for the routes’ crux, the pitch starts with a delicate traverse across the sloping ledge, before reaching the corner. From here a long, steep and sustained climb is made to the next anchor on a ledge below the chimney.
248	3	25	Grade V+	UIAA	\N	Some tricky moves are made off the belay up and rightwards to reach the corner, this is climbed to the next belay. The newer Spanish guidebook "Escaladas en Alacant" suggests the start of this pitch is the crux of the climb at 6b but other good guides leave it at V+. The bolts relive some of the pressure from the moves.
248	4	25	Grade V+	UIAA	\N	Move up from the belay for another pitch of corner climbing.
248	5	30	Grade V	UIAA	\N	Some delicate moves are made first going right from the belay a little, then back left into the chimney system. This is climbed to a cave with two bolts. From here ascend up onto the ledge above, moving left and up, around the block, to reach a belay on a wedged block with a broad slab behind.
248	6	30	Grade V+	UIAA	\N	Another contender for the route's crux. The pitch requires some harder moves onto the wall above the anchor bolts. After this the route moves up this wall on smaller but positive holds trending right. The pitch has two options. Some (sport 6a) moves, ascend more directly and a slightly easier path (UIAA V) moves right into a corner (using a small pocket) before ascending to the ledge of the cave and walking back left. 2 bolts and 2 abseil rings are positioned on the bottom left hand side of the large cave.
248	7	8	Abseil	UIAA	\N	Abseil ~8m diagonally down and left (when facing the anchor) with difficulty to reach some bolts. There are two sets. Don't move to the further set straight away because pulling the rope around the corner will be more difficult.
248	8	40	Grade V	UIAA	\N	This pitch makes a delicate exposed traverse all the way into the corner before moving up the corner crack and then slightly left at the large foliage to reach a pair of bolts for a half hanging anchor (there is a good ledge for at least one foot).
248	9	45	Grade V+	UIAA	\N	Another contender for the route's crux. The pitch traverses back right to the corner, moving up the ever steepening corner until the overhanging notch has to be tackled directly to form a dramatic finale and gain freedom from Diedro U.B.S.A.. From here a belay can be made on the bolts to the right or an additional ~30 meters of easy scrambling can be made to reach some bolts by the summit path.
273	1	30	Grade IV	UIAA	\N	Climb up the initial grove on the right hand side. Moving up and slightly left onto a block. Use both walls to gain the good handholds on the steep right hand wall and climb this until it eases and reaches a bolted belay.
273	2	48	Grade III+	UIAA	\N	Initially a long and easy scramble sticking to the rock while passing through vegetation. The pitch approaches another bigger gully on the left and a steeper wall in-front/to the right. A belay can be made below the steep wall or this can be climbed directly (probably more like IV) to reach a large ledge with a pair of bolts for the belay.
273	3	25	Grade IV+	UIAA	\N	A dog leg shaped pitch. Starting with easier moves up into a niche. This is passed with much harder moves to the right before moving up and doing a delicate traverse left to belay under the steeper overhang below the gully / chimney section.
273	4	25	Grade IV+	UIAA	\N	Probably the crux of the route, this pitch is sometimes given the higher grade of V. It climbs the chimney directly before moving onto the steep right wall and then onto a good ledge along to the belay.
273	6	30	Grade IV+	UIAA	\N	Climb a wonderful slab above the belay to a crack system. Pass a bolt at around 7m. Pass an orange bulge on the right and move up and left to belay on a pair of bolts.
253	1	35	IV+	UIAA	\N	The first pitch described here may differ from the original, (due to not having a description of the original) but it went at around grade IV+. Climb up the right side of the triangular pinnacle that attaches to cathedral rock on the east face. The route stays roughly in the middle of the face between the corner on the right and the arête/ edge on the left. Climb up to a small niche in the rock between the left arête and now wider corner / gully on the right. From the niche, move right towards the gully, and climb the back of the pinnacle to emerge on top of it. Climb over the high point to create a belay between the pinnacle and the main wall which has a large single bolt.
253	2	45	IV+	UIAA	\N	Make an exposed traverse across to a bolt and then carry on to the large block (bolt below & behind) and pass this onto easier ground. From here move rightwards, to eventually tackle a somewhat tricky bulge in the rock (not the vegetated one on the very far right). From this move up and right to create an anchor below the right most of the two deeper grooves.
253	3	35	V+	UIAA	\N	A beautiful crux pitch. Climbing directly through the offwidth crack / gull, generally using good, but sometimes hard to find hand holds. The rock for footholds on the right wall appears friable / crumbly in places so care should be taken. At the end of the gully / crack, move up to the small finger width crack and step out onto the right wall (Likely the crux if you don't use the little friable footholds), climb the right wall to a large flat fin / spike of rock. Move past this and back left to the anchor on the top.
279	1	38	IV	UIAA	\N	Start where Arest is painted on the rock in red and climb up through the notch, moving up and right then back left to a good ledge with thread belays on a grey slab. The ring bolt protecting the crux of the climb can be seen in the orange left leaning crack 10m above this first belay.
279	2	50	V	UIAA	\N	Move up to the ledge above and tackle the crux crack (orange limestone, left leaning) protected by the chunky ring bolt, following it as the difficulty of the pitch eases and trends right to reach a ledge with 2 options and arrows scratched / rubbed into the wall: MS (for Vincent M. Sellés) pointing up and A (for Aristotles) pointing right.
279	3	18	IV	UIAA	\N	Traverse right to a wire thread (in 2026) and then up and slightly left to a thread on a small awkward stance where a belay can be made. It's possible/recommended to link the next pitch depending on rope drag. By over protecting the surprisingly easy traverse the awkward belay was the best option on our ascent.
279	4	28	IV+	UIAA	\N	Go onto the block and move right into a small niche, then climb up the rounded rib, trending a little left then a little right to reach a two bolt stance.
279	5	45	III+	UIAA	\N	Climb straight up on increasing easy terrain until reaching the large ledge (optional belay). Move to the back of this while trending right and create a belay on the back wall a couple of meters left of an obvious easy gully with trees above it.
279	6	40	IV+	UIAA	\N	Move up the gully briefly 5 or so meters, before moving onto the steeper left wall. Climb this aiming to be above the previous belay on the ledge. There is an optional interim belay here, otherwise carry on trending up and left to a stance below a grey slab with a pair of bolts below-and-left from the slab under a small overhang. The letter A with an arrow pointing to the slab, should be prominently scratched at the stance.Routefinding Note: If you you go too far up the gully and make a stance at a ledge on the left wall,  it might be tempting to climb up to the obvious slings and hardware on a grey pinnacle attached on the left side to the orange wall. Don't. It's isolated and you will need to lower or abseil back down this.
279	7	25	V	UIAA	\N	It’s possible to link pitches 7 & 8 here. 7 is a lovely pitch. Climb onto the slab (gear options) then up to the piton. The pitch goes up trending slightly right (2 pitons) to avoid the overlap which is passed on the right. After this the route moves back left to a belay or carry on into the next pitch.
279	8	35	IV	UIAA	\N	Climb up and left to a piton. Traverse left from here onto the arete. Climb up the rib with great moves and great views to a thread belay or higher bolted belay. A more direct line up the middle may be IV+ or V with the easier route weaving right around a slab before the bolt.
279	9	55	IV	UIAA	\N	Move straight up the rib to the top where easier moves lead to the belay to bolts with rings, one backed up by a thread and an old abseil bolt with maillons (as of 2026) on the far side of the peak. This pitch can easily be divided into two if desired by creating a belay at a ledge along the way.
269	3	30	IV	UIAA	\N	: Climb the corner protected by a peg, continuing up easier ground after this. The new Rockfax guide grades this III, others places grade it as V. A belay can be created on the ledge with trees.
269	6	20	IV	UIAA	\N	: Climb up the face of the ridge to a ledge. There is a belay on pegs just up and right from a tree.
269	7	45	IV	UIAA	\N	: Follow the ridge to a good ledge.
269	10	30	IV+	UIAA	\N	: Climb leftwards a little to the flared groove. Climb up this crack and groove to a ledge with bolt belay set back a bit.
269	11	50	IV+	UIAA	\N	: Move back over broken ground for about 10m. Where the wall steepens there is a small pinnacle left of the blank wall.  The left and right of this are climbable but the left is probably easier and less hollow sounding than the right side. After this continue up the ridge to a stance with bolt belays.
269	12	30	IV	UIAA	\N	:  Climb directly up the steep ridge on good but not always obvious hand holds. There is a zig-zag crack and the final belay is on a large flat ledge with a pair of bolts left of the deep crack / groove.
269	13	40	IV	UIAA	\N	: Climb the deep groove right of the bolts. As it eases the climber is looking for a faded white arrow pointing right of some large red paint dots off to the right. A traditional anchor can be made using a tree and / or cracked rocks on the easy ground.
271	1	20	Diff	\N	\N	Starting just right of the base, climb up a short steep wall on good but polished holds. A belay can be created on the small ledge or the next pitch can be done as well in a link up, this would lead to a bigger belay ledge.
271	2	10	Diff	\N	\N	Climb up a short gully, sometimes generously referred to as a chimney, to a larger belay ledge/area. Whilst the slab to the left of the gully is easier, the goal when climbing the Cneifion Arete should be to find harder moves and sections, not easier ones. It's possible to keep going after this short pitch to find a belay higher on the ridge.
278	1	35	4a	\N	\N	: Climb the polished corner, trending left at the top of corner, then move up the main rib on easier ground and belay before the next rib, on the left, just below a large pillar.
278	2	30	4a	\N	\N	: Move slightly left into the grove and climb up this using the right hand arete / edge. At a small edge about half way, step left and make a long reach (cruxy - especially so if shorter) upwards from polished footholds. Then carry on to belay below a small overhang.
278	3	20	\N	\N	\N	: Pass the overhang on the right and continue easily up to make a stance at the start of the terraces and ledges.
278	6	25	4a	\N	\N	: Another contener for the crux, climb up the groove making tricky moves on polished footholds to exit it leftwards. Continue trending leftwards and upwards to the large (not that flat) ledge called the Haven. A belay can be made at the block at the top of this.
278	7	20	4a	\N	\N	: The Kinghts slab pitch moves up a crack then rightwards across the slab the around the corner to a little niche where a belay can be made.
278	8	20	4a	\N	\N	: Quite a burley and steep pitch on juggy holds. Move up and right into a steep corner. Climb this to a ledge with some large blocks. It’s possible to scramble off from here.
278	9	20	4a	\N	\N	: Another pitch with a good mix of different moves needed to ascend. Starting on the Quartz topped block, climb up to the top.
265	1	18	3c	BAS	\N	The first pitch follows a crack surrounded by good holds. Upon reaching the bulge before the ledge, this can be tackled  directly using good handholds or the climber can pass it on the right. An anchor can be built in the wall at the back of the large ledge.
265	2	16	3a	BAS	\N	Step out from the ledge to the south east ridge, where a grove will take the climber up the arête (edge) to another large ledge. The climber can build an anchor here which offers more protection, or continue up pitch 3 to the next ledge.
265	3	13	3a	BAS	\N	A short pitch on its own, that once again takes the arête (edge / ridge) up to the next ledge. The climbing is easy and the views and are incredible. An anchor can be made before the final steep pitch. Alternatively pitch 3 & 4 can be linked.
265	4	24	3c	BAS	\N	The final pitch offers a short steep wall before giving way to much easier climbing up the ledges to the summit of Great Tor. An anchor can be built on the top with creative use of various protection and slinging one of the larger summit blocks.
282	1	45	\N	\N	\N	Follow the obvious crack to a wedged block and either belay there or on a better ledge above.
282	2	45	\N	\N	\N	After the belay, take the left hand grove working up and left slightly before following a long rightwards leaning line of weakness up to some ledges where another belay can be made.
282	3	25	\N	\N	\N	Follow the crack up towards a ledge, the route becomes much less clear here with multiple options for creating an anchor. Ideally take the easiest climbing.
282	4	25	\N	\N	\N	The final official pitch goes left for about 8m then up and right towards a much larger ledge system. A shorter, slightly harder and more direct line can be taken. After this there is a reasonable amount of scrambling left and then up to get to the downclimb or abseil. Instead of the scramble, climbers can continue up on the harder continuation wall. This will add more length to this route at a higher grade. Lazarus to the far right is the easiest and arguably best way up if you want to continue with harder climbing.
220	1	25	3c	\N	\N	The first pitch goes up to the heather shelf from the base. Follow a steep curving groove to the right hand side of the shelf. If you are worried about timing you can scramble up the side and essentially skip this pitch.
220	2	30	3c	\N	\N	Not an obvious line and one it’s easy to get lost on. The key is to move diagonally right below a heather bush and over 2 ribs of rock, then climb up just under 5m to belay left of a spike. Moving over only one rib will lead you up a steeper gully with some harder moves. You can climb out of this at the top and back down into the correct path if you do get lost.
220	3	15	3c	\N	\N	Climb up a short pitch to belay on a ledge just left of a quartz band running though some rock to your right.
220	4	25	3c	\N	\N	Climb up and diagonally right via the quartz band to get over the buldge. Climb the right hand side of the rib to a spike belay.
220	5	35	3c	\N	\N	A straightforward pitch that goes broadly straight up to a ledge that marks the end of climbing for the route Avalance. You can belay on a reasonably square spike or move further right to a slightly higher ledge to belay from cracks in the wall.
220	6	32	\N	\N	\N	Walk / Scramble up and right keeping reasonably close to the main wall, until you get to the redwall with RW etched into it in big letters. You can create a belay here before taking on the magical redwall pitch. Alternatively, there is an escape option leftwards to the terminal arete which will be easier climbing / scrambling to the top (so guidebooks say).
220	7	25	4a	\N	\N	To lead the redwall you take a beautiful rising traverse on delicate holds. Cams and some nuts can be used to protect the moves in a few places. The exposed moves take you onto a rib which you can move up though to some ledges and eventually a belay in a groove leaning towards the terminal arete (up and left).
220	8	30	4a	\N	\N	Continue up passing a pinnacle on the right. From the ledge you want to use a short wall to climb on to the grassy ledge called the Green Gallery. There are some belay options either on the left or on the centre of this ledge.
220	9	10	\N	\N	\N	Walk towards the edge of the ledge at the right. You can either create a new belay here or link this into the next pitch as one. If you are linking these up then make sure you use a long runner and ideally a carabineer with a wheel like the DMM Revolver. If in doubt don’t run them together or the rope drag will take the fun out of the climb and you risk a ground / ledge fall.
220	10	25	3c	\N	\N	If you end up climbing an awkward but enjoyable chimney, chances are you left the ledge in the wrong place and may find the route slightly more difficult. The route is supposed to climb the left arete off of the right side of the Green Gallery, heading up and leftwards to some ledges and a slab. Move up past a broken block and create a belay in a pocket further up.
220	11	30	3c	\N	\N	Move up and rightwards directly towards the final slab of Longlands continuation. You should see or at least hear walkers on the summit by this point. A belay can be created on the ledge directly below the final slab. The multi-pitch climb is coming to an end but the hardest pitch remains.
220	12	30	4b	\N	\N	The final pitch moves up and trends slightly left in before going straight to the summit of Lliwedd’s Eastern Buttress. The gear is good if you take the time to find it and delicate footwork will help see you thought. The rock is clean and generally solid. There are a number of belay options on the summit.
\.


--
-- Data for Name: protection_grade; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.protection_grade (code, meaning, sort_order) FROM stdin;
G	Solid, plentiful protection.	0
PG	Good protection, generally safe.	1
PG-13	Mostly good; some runouts or marginal placements.	2
R	Serious — runout; a fall risks injury.	3
X	Extreme — ground-fall / death potential.	4
runout	A stretch with no protection below you (OpenBeta SafetyEnum).	\N
terrain	Danger from the terrain itself, not fall distance.	\N
UNSPECIFIED	Protection not yet assessed — the honest default.	\N
\.


--
-- Data for Name: provenance; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.provenance (id, route_id, field, source_id, source_url, span, confidence, created_at) FROM stdin;
\.


--
-- Data for Name: rock_type; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.rock_type (code, friction_dry, seeps, fragile_when_wet, notes) FROM stdin;
granite	\N	f	f	Dries fast; low seepage; good friction when cool. Poorly-cemented grades shed grains.
limestone	0.64	t	f	Seeps for days; overhangs stay wet; slick when humid.
dolerite	\N	f	f	Fair Head — grippy, dries reasonably; sea-cliff exposure.
rhyolite	\N	f	f	Welsh mountain rock; lichenous, slow to dry high up.
sandstone	0.74	f	t	Fragile when wet — do not climb wet (holds break). Highest dry friction.
gritstone	\N	f	t	Coarse UK sandstone — superb friction, rounded breaks; dries fast, greasy in humidity; avoid when wet.
gabbro	\N	f	f	Extremely grippy (Skye); rough.
quartzite	\N	f	f	Hard, can be polished; variable drying.
volcanic	\N	f	f	Lake District; broken, mountain drainage.
dolomite	\N	f	f	Alpine; afternoon convection risk.
slate	\N	f	f	Non-porous — drains instantly but slick when wet; positive edges; quarried faces.
gneiss	\N	f	f	Banded metamorphic (Alps, Norway); generally solid, good friction.
schist	\N	f	f	Layered; can be friable and ledgy; holds moisture in breaks.
basalt	\N	f	f	Columnar jointing gives parallel crack systems; moderate drying.
conglomerate	\N	f	f	Cobbles in matrix (Montserrat, Meteora, Riglos); pockety; protection often spaced.
andesite	\N	f	f	Volcanic; blocky, variable quality.
chalk	\N	t	t	Soft marine limestone (Dover, Beachy Head) — friable, specialist trad; never climb wet; protection unreliable.
phonolite	\N	f	f	Sound, fine-grained volcanic (Canaries/Teide); climbs like fine rhyolite; dries fast.
\.


--
-- Data for Name: route; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.route (id, area_id, name, status, geom, timezone, left_right_index, length_m, pitches_count, rock_code, incline_code, aspect, grade_system_code, original_grade, trad_grade, tech_grade, data_grade, protection_code, protection_style, belays, commitment_code, escapable, approach_time_min, approach_difficulty, rack, rope, bolts_count, descent_method, descent_abseils, descent_notes, elevation_m, sun_window_code, wind_exposed, best_season, stars, intro_html, approach_html, pitch_info_html, tile_image, topo, map_img, last_update, tagged_by, tag_prov, curation_notes, needs_field_check, curated_at) FROM stdin;
15	26	Cake Walk	draft	\N	\N	\N	54	2	\N	\N	\N	BAS	E3 5c	E3	5c	\N	G	gear	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.163915+00	source	\N	\N	f	\N
13	26	Doldrum	draft	\N	\N	\N	70	1	\N	\N	\N	BAS	E2 5c	E2	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.163915+00	source	\N	\N	f	\N
14	26	Hurricane	draft	\N	\N	\N	61	2	\N	\N	\N	BAS	E2 5b	E2	5b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.163915+00	source	\N	\N	f	\N
16	26	Jolly Roger	draft	\N	\N	\N	55	2	\N	\N	\N	BAS	E3 6a	E3	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.163915+00	source	\N	\N	f	\N
17	26	Learning to Fly	draft	\N	\N	\N	55	2	\N	\N	\N	BAS	E5 6a	E5	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.163915+00	source	\N	\N	f	\N
11	26	Poor Relation	draft	\N	\N	\N	45	2	\N	Slab	\N	BAS	E1 5b	E1	5b	7	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.163915+00	source	\N	\N	f	\N
12	26	Raglan Road	draft	\N	\N	\N	72	2	\N	\N	\N	BAS	E3 6a	E3	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.163915+00	source	\N	\N	f	\N
45	55	Blackout	draft	\N	\N	\N	95	3	\N	\N	\N	BAS	E5 6a	E5	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.249417+00	source	\N	\N	f	\N
40	55	November	draft	\N	\N	\N	78	2	\N	\N	\N	BAS	HVS 5a	HVS	5a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.249417+00	source	\N	\N	f	\N
43	55	Raven	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E2 5b	E2	5b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.249417+00	source	\N	\N	f	\N
42	55	Rumours	draft	\N	\N	\N	80	3	\N	\N	\N	BAS	E5 6a	E5	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.249417+00	source	\N	\N	f	\N
46	55	Scorpion	draft	\N	\N	\N	77	3	\N	\N	\N	BAS	E3 5c	E3	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.249417+00	source	\N	\N	f	\N
41	55	Waiting Game	draft	\N	\N	\N	90	3	\N	\N	\N	BAS	E4 6a	E4	6a	\N	G	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.249417+00	source	\N	\N	f	\N
21	34	Cu Uladh	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	HVS 5a	HVS	5a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.44884+00	source	\N	\N	f	\N
24	34	Doss In Choss	draft	\N	\N	\N	\N	2	\N	\N	\N	BAS	\N	None	\N	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.44884+00	source	\N	\N	f	\N
18	26	Twisted relations	draft	\N	\N	\N	45	2	\N	Overhanging	\N	BAS	E2 5c	E2	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.163915+00	source	\N	\N	f	\N
19	34	Night Rider	draft	\N	\N	\N	81	3	\N	Overhanging	\N	BAS	E5 6a	E5	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.44884+00	source	\N	\N	f	\N
20	34	Njold's Saga	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E2 5c	E2	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.44884+00	source	\N	\N	f	\N
59	72	Absolute Zero	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E5 6b	E5	6b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.922425+00	source	\N	\N	f	\N
54	62	An Bealach Rúnda	draft	\N	\N	\N	110	3	\N	\N	\N	BAS	E1 5b	E1	5b	7	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:04.886241+00	source	\N	\N	f	\N
23	34	Soylent Green	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E1 5b	E1	5b	7	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.44884+00	source	\N	\N	f	\N
22	34	The Grey Man	draft	\N	\N	\N	75	3	\N	\N	\N	BAS	E4 5c	E4	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.44884+00	source	\N	\N	f	\N
27	40	Abyssinia	draft	\N	\N	\N	80	2	\N	\N	\N	BAS	E3 5c	E3	5c	\N	PG	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.502022+00	source	\N	\N	f	\N
26	40	Burn Up	draft	\N	\N	\N	\N	2	\N	\N	\N	BAS	E1 5a	E1	5a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.502022+00	source	\N	\N	f	\N
31	40	Cat's Malacky	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E2 5c	E2	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.502022+00	source	\N	\N	f	\N
29	40	Creeper	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E1 5b	E1	5b	7	G	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.502022+00	source	\N	\N	f	\N
30	40	Kraken	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E2 5b	E2	5b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.502022+00	source	\N	\N	f	\N
36	49	Crusader	draft	\N	\N	\N	80	2	\N	\N	\N	BAS	E4 6a	E4	6a	\N	PG	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.286893+00	source	\N	\N	f	\N
7	22	Voie Boell	publish	0101000020E61000007F6ABC7493181940BA490C022B774640	\N	\N	350	10	\N	Vertical	\N	ALP	D	\N	\N	4	PG	mixed	bolted	\N	\N	120	3	\N	\N	\N	\N	\N	\N	3130	all-day	\N	{7,8,9}	3	\N	\N	\N	\N	\N	\N	2026-07-06 21:10:06.059979+00	human	\N	\N	f	\N
32	40	Saladin	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E5 6b	E5	6b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.502022+00	source	\N	\N	f	\N
28	40	The Famished Road	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	HVS 5a	HVS	5a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.502022+00	source	\N	\N	f	\N
33	40	Thran	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E2 5c	E2	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.502022+00	source	\N	\N	f	\N
25	40	Zulu	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	HVS 5a	HVS	5a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.502022+00	source	\N	\N	f	\N
61	72	Dark Forces	draft	\N	\N	\N	85	3	\N	\N	\N	BAS	E3 6a	E3	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.922425+00	source	\N	\N	f	\N
57	72	Flashdance	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E2 5b	E2	5b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.922425+00	source	\N	\N	f	\N
60	72	Give Up	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E4 6b	E4	6b	\N	R	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.922425+00	source	\N	\N	f	\N
58	72	Peacadh Marfach	draft	\N	\N	\N	\N	4	\N	\N	\N	BAS	E2 5b	E2	5b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.922425+00	source	\N	\N	f	\N
10	24	Nobody Get Hurt	draft	\N	\N	\N	\N	17	\N	\N	\N	BAS	E4 6b	E4	6b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.040713+00	source	\N	\N	f	\N
63	77	Iseult	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E4 6a	E4	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.075+00	source	\N	\N	f	\N
62	77	Tristan	draft	\N	\N	\N	110	3	\N	\N	\N	BAS	E3 5c	E3	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.075+00	source	\N	\N	f	\N
35	49	Born to Run	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E4 6a	E4	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.286893+00	source	\N	\N	f	\N
34	49	Infidel	draft	\N	\N	\N	64	2	\N	\N	\N	BAS	E5 6b	E5	6b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.286893+00	source	\N	\N	f	\N
39	49	Lúnasa	draft	\N	\N	\N	92	3	\N	\N	\N	BAS	E4 6a	E4	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.286893+00	source	\N	\N	f	\N
37	49	Streets of Fire	draft	\N	\N	\N	75	2	\N	\N	\N	BAS	E3 6a	E3	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.286893+00	source	\N	\N	f	\N
38	49	White Lightning	draft	\N	\N	\N	\N	2	\N	\N	\N	BAS	E3 5c	E3	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.286893+00	source	\N	\N	f	\N
52	62	Horizon Tides	draft	\N	\N	\N	90	4	\N	\N	\N	BAS	E3 6a	E3	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:04.886241+00	source	\N	\N	f	\N
55	62	Northern Exposure	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E5 6b	E5	6b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:04.886241+00	source	\N	\N	f	\N
47	62	Something Horrible	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E3 6a	E3	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:04.886241+00	source	\N	\N	f	\N
51	62	The Navvy	draft	\N	\N	\N	95	2	\N	\N	\N	BAS	E2 5c	E2	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:04.886241+00	source	\N	\N	f	\N
53	62	The X-Men	draft	\N	\N	\N	90	3	\N	\N	\N	BAS	E3 6a	E3	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:04.886241+00	source	\N	\N	f	\N
49	62	Un Jour, Peut-Etre	draft	\N	\N	\N	110	4	\N	\N	\N	BAS	E6 6b	E6	6b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:04.886241+00	source	\N	\N	f	\N
48	62	Walk on the Wild Side	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E1 5b	E1	5b	7	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:04.886241+00	source	\N	\N	f	\N
50	62	Where the Wild Things Are	draft	\N	\N	\N	110	4	\N	\N	\N	BAS	E5 6b	E5	6b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:04.886241+00	source	\N	\N	f	\N
130	130	Abyssinia	draft	\N	\N	\N	80	2	\N	\N	\N	BAS	E3 5c	E3	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.331901+00	source	\N	\N	f	\N
129	130	Burn Up	draft	\N	\N	\N	\N	2	\N	\N	\N	BAS	E1 5a	E1	5a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.331901+00	source	\N	\N	f	\N
132	130	Creeper	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E1 5b	E1	5b	7	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.331901+00	source	\N	\N	f	\N
224	235	Doorpost	publish	0101000020E61000003080F0A1447B16C07D94111780164940	Europe/London	\N	67	3	granite	Vertical	W	BAS	HS 4b	HS	4b	4	G	\N	\N	\N	\N	10	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Doorpost is a classic climb on the justifiably popular Bow Wall area of Bosigran. It has an easy approach and accessible grade. The climbing is interesting and varied but easy to protect. The route is on a part of the cliff surrounded by both harder and easier climbs. Check out the incredible Ledge Climb if you want easier or Little Brown Jug if you want to go harder. That said the crux of Ledge climb is arguably as hard as the crux of Doorpost. The granite here is solid and happily takes cams throughout the route. The route dries quickly after rain but the first pitch suffers some minor seepage.	<strong>Approach</strong>: Park in the National Trust Carpark by Carn Galver ruined tin mine building. This is a free car park with a donation box to support the national trust. Follow the path out towards the sea for less than 10 minutes. As you reach the first part of the top of Bosigran cliff you will be able to find a steep but good path down. Take this to the base of the crag then walk along another good path to the Bow Wall area. The black “coal face” wall makes an obvious feature to find the route. From the top you can follow a path back to parking.	Doorpost is a classic Bosigran route and one of the best Hard Severe multi-pitch climbs in the south of England. It’s easy to approach and offers interesting but easy to protect climbing on solid granite. Although it dries quickly after rain, part of the first pitch suffers some seepage in the middle. All things considered it’s one of the best climbs in it’s category. \r\n<br>\r\n<strong class="pitch-title">Pitch 1 –<span class="length">27m</span> <span class="pitchGrade brit">4a</span></strong><br>\r\nThe first pitch starts with easy holds up into a corner before following the striking crack line across and up. There is some delicate footwork required but the hand holds are good and the crack will happily take one to two finger width cams. As the crack ends the climber can climb good holds to a ledge with an option for a sitting belay on the left hand side of the ledge (back to the sea) or you can move further right (back to the sea) for a standing  belay that is shared with the first pitch of the popular little brown jug.\r\n<br>\r\n<strong class="pitch-title">Pitch 2 –<span class="length">15m</span> <span class="pitchGrade brit">4b</span></strong><br>\r\nThis is a short and interesting pitch. The goal is to climb the twin cracks to a ledge above. The pitch starts with moves out to the left crack. This is climbed up to the crux of the route which sits at the point where the climber has to move from the left crack, to the right crack. Once in the right crack move up to a good ledge with a belay in the corner.\r\n<br>\r\n<strong class="pitch-title">Pitch 3 –<span class="length">25m</span> <span class="pitchGrade brit">4a</span></strong><br>\r\nA glorious and easy part of the climb with good protection and incredible exposure as the climb moves onto one of the highest points of the cliff at Bosigran. Follow a reasonably obvious path up good holds to the top, where a belay can be made by slinging a boulder and backed up by large gear if desired.	{"alt": "Bosigran's Sea Cliffs offer accessible rock climbing", "url": "img/tiles/bosigran-small.jpg"}	{"alt": "Bosigran's Doorpost Multipitch Route Topo", "url": "img/topos/bosigran/bosigran-doorpost-climb-cornwall.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "Our own image"}	{"alt": "Bosigran's Location in Cornwall", "url": "img/topos/bosigran/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
124	130	Cu Uladh	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	HVS 5a	HVS	5a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.331901+00	source	\N	\N	f	\N
127	130	Doss In Choss	draft	\N	\N	\N	\N	2	\N	\N	\N	BAS	\N	\N	\N	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.331901+00	source	\N	\N	f	\N
133	130	Kraken	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E2 5b	E2	5b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.331901+00	source	\N	\N	f	\N
122	130	Night Rider	draft	\N	\N	\N	81	3	\N	\N	\N	BAS	E5 6a	E5	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.331901+00	source	\N	\N	f	\N
105	117	Aoife	draft	\N	\N	\N	66	2	\N	\N	\N	BAS	E2 5b	E2	5b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.032138+00	source	\N	\N	f	\N
108	122	Dearg Doom	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	VS 4c	VS	4c	5	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.073343+00	source	\N	\N	f	\N
107	122	Odyssey	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	VS 4c	VS	4c	5	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.073343+00	source	\N	\N	f	\N
115	129	Blade Runner	draft	\N	\N	\N	90	2	\N	\N	\N	BAS	E3 5c	E3	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.092755+00	source	\N	\N	f	\N
120	129	Cake Walk	draft	\N	\N	\N	54	2	\N	\N	\N	BAS	E3 5c	E3	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.092755+00	source	\N	\N	f	\N
119	129	Doldrum	draft	\N	\N	\N	70	\N	\N	\N	\N	BAS	E2 5c	E2	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.092755+00	source	\N	\N	f	\N
84	91	Flying Lizards	draft	\N	\N	\N	80	2	\N	\N	\N	BAS	E3 6a	E3	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.735127+00	source	\N	\N	f	\N
73	77	Bates's Motel	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E3 5c	E3	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.075+00	source	\N	\N	f	\N
75	77	Clontarf	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E3 5c	E3	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.075+00	source	\N	\N	f	\N
113	129	Hurricane	draft	\N	\N	\N	61	2	\N	\N	\N	BAS	E2 5b	E2	5b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.092755+00	source	\N	\N	f	\N
123	130	Njold's Saga	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E2 5c	E2	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.331901+00	source	\N	\N	f	\N
86	91	Full of Energy, Ready 2 Party	draft	\N	\N	\N	68	3	\N	\N	\N	BAS	E5 6a	E5	6a	\N	PG-13	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.735127+00	source	\N	\N	f	\N
90	91	Heaven Can Wait	draft	\N	\N	\N	70	2	\N	\N	\N	BAS	E4 6a	E4	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.735127+00	source	\N	\N	f	\N
121	129	Learning to Fly	draft	\N	\N	\N	55	2	\N	\N	\N	BAS	E5 6a	E5	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.092755+00	source	\N	\N	f	\N
88	91	Judgement Day	draft	\N	\N	\N	75	2	\N	Slab	\N	BAS	E7 6b	E7	6b	\N	R	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.735127+00	source	\N	\N	f	\N
82	91	Licence to Kill	draft	\N	\N	\N	65	2	\N	\N	\N	BAS	E4 5c	E4	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.735127+00	source	\N	\N	f	\N
109	124	Tangled Traverse	draft	\N	\N	\N	\N	2	\N	\N	\N	BAS	E2 5c	E2	5c	\N	G	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.966876+00	source	\N	\N	f	\N
9	24	Nobody Move	draft	\N	\N	\N	\N	15	\N	\N	\N	BAS	E4 6a	E4	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.040713+00	source	\N	\N	f	\N
71	77	Aifric	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E2 5c	E2	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.075+00	source	\N	\N	f	\N
66	77	Avarice	draft	\N	\N	\N	97	\N	\N	\N	\N	BAS	E4 6a	E4	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.075+00	source	\N	\N	f	\N
72	77	Easy Rider	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E2 5b	E2	5b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.075+00	source	\N	\N	f	\N
67	77	Heart and Soul	draft	\N	\N	\N	90	2	\N	\N	\N	BAS	E4 6a	E4	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.075+00	source	\N	\N	f	\N
70	77	Herbivore	draft	\N	\N	\N	\N	5	\N	\N	\N	BAS	HVS	HVS	\N	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.075+00	source	\N	\N	f	\N
74	77	Solid Mandala	draft	\N	\N	\N	\N	4	\N	\N	\N	BAS	E3 6a	E3	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.075+00	source	\N	\N	f	\N
69	77	The Big Big Movie	draft	\N	\N	\N	91	3	\N	\N	\N	BAS	E3 5c	E3	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.075+00	source	\N	\N	f	\N
64	77	Uisce faoi Thalamh	draft	\N	\N	\N	110	3	\N	\N	\N	BAS	E2 5c	E2	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.075+00	source	\N	\N	f	\N
97	111	Below and Behold	draft	\N	\N	\N	65	1	\N	\N	\N	BAS	E7 6c	E7	6c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.233199+00	source	\N	\N	f	\N
100	111	Phil	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E5 6b	E5	6b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.233199+00	source	\N	\N	f	\N
101	111	Styx	draft	\N	\N	\N	60	1	\N	\N	\N	BAS	E7 6c	E7	6c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.233199+00	source	\N	\N	f	\N
98	111	The Wall of Prey	draft	\N	\N	\N	75	2	\N	\N	\N	BAS	E5 6b	E5	6b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.233199+00	source	\N	\N	f	\N
125	130	The Grey Man	draft	\N	\N	\N	75	3	\N	\N	\N	BAS	E4 5c	E4	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.331901+00	source	\N	\N	f	\N
110	125	Kashubia	draft	\N	\N	\N	42	2	\N	\N	\N	BAS	HVS 5a	HVS	5a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.320006+00	source	\N	\N	f	\N
93	91	Blind Pew	draft	\N	\N	\N	60	2	\N	\N	\N	BAS	E2 5b	E2	5b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.735127+00	source	\N	\N	f	\N
83	91	Cool Hand Luke	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E2 5c	E2	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.735127+00	source	\N	\N	f	\N
78	91	Cúchulainn	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E2 5c	E2	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.735127+00	source	\N	\N	f	\N
77	91	Faerie Stories	draft	\N	\N	\N	90	2	\N	\N	\N	BAS	E6 6b	E6	6b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.735127+00	source	\N	\N	f	\N
96	111	The Rathlin Effect	draft	\N	\N	\N	70	1	\N	\N	\N	BAS	E9 6c	E9	6c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.233199+00	source	\N	\N	f	\N
1	16	Original Route	publish	0101000020E61000000EF3E505D88715C0EF1B5F7B66214D40	Europe/London	\N	67	5	sandstone	Vertical	SE	BAS	VS 5a	VS	5a	5	PG	gear	gear	\N	\N	50	3	\N	\N	\N	\N	\N	\N	60	morning	\N	{5,6,7,8,9}	3	Arguably one of the best sea stacks in \nthe United Kingdom, The Old Man of Stoer (Stake), makes for an \nadventurous day out and an all round exceptional climb. The rock is \nTorridonian sandstone, meaning it was formed before any significant life\n on earth existed. The approach is either some wet rock hopping 100m \nnorth of the stack at the lowest tide or the more classic Tyrolean \ntraverse which may need to be set up by swimming the 8 meter channel if \nthere is not one left in place when you arrive. The route itself, \nOriginal Route, meanders the landward face, following cracks and ledges \nto the top. Larger cams can be helpful. Be wary of nesting sea birds <span><span data-dobid="hdw">whose </span></span>first line of defence is usually to attack by projecting the last meal they ate at nearby unsuspecting climbers.	<strong>Approach</strong>: Park at the car park near the Stoer Light house (58.237948, -5.400902). From there take the coastal path heading 3Km northwards to the sea stack, going over the hill of Sidhean Mor. It will take roughly an hour to reach the Old Man of Stoer. Standing on the mainland at the first point you reach across from the stack, there is a small steep path down, requiring some scramble that can be damp from run-off in places. There is usually a Tyrolean traverse in situ that can be used to get to the stack (in July 2022 it was tied around a boulder on the mainland with a 4-point traditional anchor on the stack). Swimming the channel (and setting up a rope traverse) is the alternative if there is no rope in place. It is possible to rock hop and wade across, around 100m north of the stack if there is a very low tide.<br><br><strong>Descent</strong>: Make a single abseil off using a pair of 60m \nropes. The intermediate belay station at 40m is hard to reach due to the\n overhang and very poorly equipped (rusting / rotting in July 2022), so \nnot recommended.	The Original Route on the Old Man of Stoer is one of a handful of so called 4 star climbs (4 stars out of 3). The route certainly has variety, exposure, a beautiful setting and an incredible abseil finish. In terms of protection, medium, large and even very large cams can be helpful for protecting parts of the route. Route finding on pitches 3 and 4 can be tricky and these are arguably the hardest parts of the climb despite the traverse on pitch one getting the hardest technical grade in guidebooks. <br><strong class="pitch-title">Pitch 1 –<span class="length">15m</span> <span class="pitchGrade brit">5a</span></strong><br>Climb up a couple of moves and then traverse left around the base of the stack using one small horizontal break for feet and a bigger horizontal break for hands. Reach a comfortable ledge just out of sight of the start of the route, a belay can be set up here at the base of the slab. <br><strong class="pitch-title">Pitch 2 –<span class="length">12m</span> <span class="pitchGrade brit">4a</span></strong><br>Climb up the slab, trending right at the top to create a belay on the next large ledge. <br><strong class="pitch-title">Pitch 3 –<span class="length">15m</span> <span class="pitchGrade brit">4b</span></strong><br> Make bold moves up steep ground either directly above the belay point or using the right trending grove, then moving left again at the break. After this move up and left to another ledge. This is the belay point for the Diamond Face Route. From here there is a wedged boulder above, pass this on the right side to make a belay in the cave on top of the wedged boulder. <br><strong class="pitch-title">Pitch 4 –<span class="length">10m</span> <span class="pitchGrade brit">4c</span></strong><br> Start the pitch traversing easily right around the corner before trending up and right. From a small ledge make some hard moves to gain a bigger ledge / niche where the final belay can be made. Guidebooks seem to suggest traversing further right to create a belay on a smaller ledge. This would mean the final pitch climbs the chimney directly above the small belay ledge.  <br><strong class="pitch-title">Pitch 5 –<span class="length">15m</span> <span class="pitchGrade brit">3c</span></strong><br> Move up and diagonally right to one large edge, then up onto another. From here take the left slanting slab to the summit plateau.	{"alt": "The Sea Stack Know as The Old Man of Stoer", "url": "img/tiles/old-man-of-stoer-small.jpg", "atributionURL": null, "attributionText": null}	{"alt": "Topo for The Old Man of Stoer Original Route", "url": "img/topos/stoer/old-man-of-stoer-original-route-climb.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "Our own image"}	{"alt": "The Old Man of Stoer's Location in Scotland", "url": "img/topos/stoer/maps/"}	2022-11-10 12:56:24.871+00	human	\N	\N	f	\N
185	135	Flying Lizards	draft	\N	\N	\N	80	2	\N	\N	\N	BAS	E3 6a	E3	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
187	135	Full of Energy, Ready 2 Party	draft	\N	\N	\N	68	3	\N	\N	\N	BAS	E5 6a	E5	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
190	135	Heaven Can Wait	draft	\N	\N	\N	70	2	\N	\N	\N	BAS	E4 6a	E4	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
189	135	Judgement Day	draft	\N	\N	\N	75	2	\N	\N	\N	BAS	E7 6b	E7	6b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
200	124	Balooba	draft	\N	\N	\N	33	2	\N	\N	\N	BAS	VS 4c	VS	4c	5	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.966876+00	source	\N	\N	f	\N
183	135	Licence to Kill	draft	\N	\N	\N	65	2	\N	\N	\N	BAS	E4 5c	E4	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
181	135	Lochlannach	draft	\N	\N	\N	70	3	\N	\N	\N	BAS	E3 6a	E3	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
201	124	Contortions 	draft	\N	\N	\N	38	2	\N	\N	\N	BAS	VS 4c	VS	4c	5	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.966876+00	source	\N	\N	f	\N
202	124	Contractions 	draft	\N	\N	\N	36	2	\N	\N	\N	BAS	VS 5a	VS	5a	5	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.966876+00	source	\N	\N	f	\N
196	124	Five Gears in Reverse	draft	\N	\N	\N	60	3	\N	\N	\N	BAS	E1 5b	E1	5b	7	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.966876+00	source	\N	\N	f	\N
203	124	Good Morning Judge	draft	\N	\N	\N	24	2	\N	\N	\N	BAS	HVS 5a	HVS	5a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.966876+00	source	\N	\N	f	\N
175	135	Mizen Star	draft	\N	\N	\N	60	2	\N	\N	\N	BAS	E2 5b	E2	5b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
44	55	Back to the Future 8	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E4 6a	E4	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.249417+00	source	\N	\N	f	\N
134	130	Cat's Malacky	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E2 5c	E2	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.331901+00	source	\N	\N	f	\N
157	62	Dark Forces	draft	\N	\N	\N	85	3	\N	\N	\N	BAS	E3 6a	E3	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:04.886241+00	source	\N	\N	f	\N
135	130	Saladin	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E5 6b	E5	6b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.331901+00	source	\N	\N	f	\N
153	62	Flashdance	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E2 5b	E2	5b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:04.886241+00	source	\N	\N	f	\N
156	62	Give Up	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E4 6b	E4	6b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:04.886241+00	source	\N	\N	f	\N
154	62	Peacadh Marfach	draft	\N	\N	\N	\N	4	\N	\N	\N	BAS	E2 5b	E2	5b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:04.886241+00	source	\N	\N	f	\N
126	130	Soylent Green	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E1 5b	E1	5b	7	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.331901+00	source	\N	\N	f	\N
56	62	Waiting for the Sun	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E4 6a	E4	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:04.886241+00	source	\N	\N	f	\N
136	130	Thran	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E2 5c	E2	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.331901+00	source	\N	\N	f	\N
192	135	Blind Pew	draft	\N	\N	\N	60	2	\N	\N	\N	BAS	E2 5b	E2	5b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
174	135	Conchubair	draft	\N	\N	\N	70	\N	\N	\N	\N	BAS	E2 5c	E2	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
184	135	Cool Hand Luke	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E2 5c	E2	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
172	135	Cúchulainn	draft	\N	\N	\N	70	3	\N	\N	\N	BAS	E2 5c	E2	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
173	135	Equinox	draft	\N	\N	\N	70	2	\N	\N	\N	BAS	E2 5b	E2	5b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
179	135	Faerie Stories	draft	\N	\N	\N	90	2	\N	\N	\N	BAS	E6 6b	E6	6b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
191	135	Promised Land	draft	\N	\N	\N	60	2	\N	\N	\N	BAS	E4 6a	E4	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
178	135	Roaring Meg	draft	\N	\N	\N	100	3	\N	\N	\N	BAS	VS 5a	VS	5a	5	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
180	135	Viking	draft	\N	\N	\N	73	3	\N	\N	\N	BAS	HVS	HVS	\N	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
197	124	Jubilee	draft	\N	\N	\N	64	2	\N	\N	\N	BAS	E1 5b	E1	5b	7	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.966876+00	source	\N	\N	f	\N
204	124	Jungle Rock 	draft	\N	\N	\N	39	2	\N	\N	\N	BAS	VS 5a	VS	5a	5	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.966876+00	source	\N	\N	f	\N
198	124	Pyrrhic Victory	draft	\N	\N	\N	56	2	\N	\N	\N	BAS	E2 5b	E2	5b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.966876+00	source	\N	\N	f	\N
199	124	Thunder Road	draft	\N	\N	\N	58	2	\N	\N	\N	BAS	E3 5c	E3	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.966876+00	source	\N	\N	f	\N
68	77	Blockbuster	draft	\N	\N	\N	91	3	\N	\N	\N	BAS	E2 5c	E2	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.075+00	source	\N	\N	f	\N
99	111	The Wall of Prey (Direct Start)	draft	\N	\N	\N	75	2	\N	\N	\N	BAS	E5 6b	E5	6b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.233199+00	source	\N	\N	f	\N
2	17	Tennis Shoe	publish	0101000020E610000004560E2DB21D10C03BDF4F8D978E4A40	\N	\N	140	5	\N	Slab	\N	BAS	HS 4a	HS	4a	4	PG	gear	gear	\N	\N	20	1	\N	\N	\N	\N	\N	\N	450	morning	\N	{4,5,6,7,8,9}	3	\N	\N	\N	\N	\N	\N	2026-07-06 21:10:06.059979+00	human	\N	\N	f	\N
3	18	Scavenger	publish	0101000020E61000008B6CE7FBA97110C0295C8FC2F5C84940	\N	\N	40	1	\N	Vertical	\N	BAS	VS 4c	VS	4c	5	G	gear	gear	\N	\N	15	2	\N	\N	\N	\N	\N	\N	20	all-day	\N	{3,4,5,6,7,8,9,10}	2	\N	\N	\N	\N	\N	\N	2026-07-06 21:10:06.059979+00	human	\N	\N	f	\N
4	19	Ash Tree Slabs	publish	0101000020E61000004C37894160E508C0F0A7C64B37394B40	\N	\N	70	2	\N	Slab & Vertical	\N	BAS	VD 3c	VD	3c	2	G	gear	gear	\N	\N	60	2	\N	\N	\N	\N	\N	\N	520	afternoon	\N	{5,6,7,8,9}	2	\N	\N	\N	\N	\N	\N	2026-07-06 21:10:06.059979+00	human	\N	\N	f	\N
5	20	Girona	publish	0101000020E610000039B4C876BE9F18C023DBF97E6A9C4B40	\N	\N	60	1	\N	Vertical	\N	BAS	VS 4c	VS	4c	5	G	gear	gear	\N	\N	25	2	\N	\N	\N	\N	\N	\N	100	shade	\N	{5,6,7,8,9}	2	\N	\N	\N	\N	\N	\N	2026-07-06 21:10:06.059979+00	human	\N	\N	f	\N
6	21	Sur Clásica (Punta Margarita)	publish	0101000020E61000001904560E2DB214C0E17A14AE47214440	\N	\N	200	6	\N	Vertical	\N	UIAA	V+	\N	\N	5	PG	gear	mixed	\N	\N	90	2	\N	\N	\N	\N	\N	\N	2200	afternoon	\N	{6,7,8,9}	3	\N	\N	\N	\N	\N	\N	2026-07-06 21:10:06.059979+00	human	\N	\N	f	\N
215	243	South Ridge	publish	0101000020E6100000DBA2CC0699E414C0077E54C37ED14B40	Europe/London	\N	330	11	granite	Slab	S	BAS	VS 5a	VS	5a	5	UNSPECIFIED	\N	\N	\N	\N	140	2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The South Ridge of Cir Mhor on the isle of Arran just off the coast of Scotland offers an interesting mix of climbing across a long route with a few challenging pitches which give it the VS 5a grade. The approach is long but this remains a reasonably popular route.	The approach is long. The two main options are from the Glen Rosa Campsite or from Sannox Bay. See the Scottish Rock Volume 1 for more info.	\N	{"alt": "The South Ridge Direct Route on Cir Mhor", "url": "img/tiles/cir-mhor-ridge-arran.jpg", "atributionURL": "https://www.geograph.org.uk/profile/24401", "attributionText": "Raibeart MacAoidh"}	{"alt": "The South Ridge Direct Route on Cir Mhor", "url": "img/topos/cir-mhor/south-ridge-direct-topo-maybe.jpg", "dataFile": null, "atributionURL": "http://beantinblog.blogspot.com/2016/08/south-ridge-direct-cir-mhor-arran.html", "attributionText": "Louis at Beantin"}	{"alt": "Cir Mhor Ridge location", "url": "img/topos/cir-mhor/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
225	296	Poetic Justice	publish	0101000020E610000043CA4FAA7DCA17C0F44E05DCF3164B40	Europe/London	\N	80	4	granite	\N	SW	BAS	VS 4b	VS	4b	5	PG	\N	\N	\N	\N	90	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Referred to as PJ, it is a classic Mourne Mountain “expedition” and a must climb, thanks to sustained interest, exposure and great belays assuming you reach the 1<sup>st</sup> belay before the rope drag gets too much. It can be done in 3 or 4 pitches. Pitch one can and should be broken up unless you have a high tolerance for rope drag or you do a very good job extending runners. Whilst listed as 90m climb here there is a 10m scramble over, what is often a heavily vegetated ledge. If it wasn’t for the vegetation here you could make a case this was one of the best VS graded climbs in the British Isles. Start the route left of the gully on the right-hand end of the Main Face. The first pitch takes a crack line up the crest of the lower buttress (two pitches if you create a belay before the grass ledge). True crack climbing skills are not essential. However, any climber not able to do a layback might have a bad time on the last pitch.	<strong>Approach from Newcastle:</strong> Approaching from the Slieve Donard Car park in the town of Newcastle in Norther Ireland is probably easiest. From the car park follow the beautiful Glen river track all the way up into the mountains as if climbing Slieve Donard. Eventually the path reaches the obvious Mourne wall. Cross the wall and keep heading forwards and slightly right. You will soon be able to see Slieve Beg in the distance. The path forks right and drops down under the Castles outcrop. Side note: The Castles Outcrop offers very short, but clean trad rock climbing on the Mournes granite. Follow this clearly marked path and either, cut across country directly towards Slieve Beg after the stream, or alternatively, another option is to walk around the back to the summit of Slieve Beg and then scramble down the Devils Coach road to the base of the climb to avoid boggy ground.<br><br><strong>Approach from Carrick Little:</strong> <br>Park in the Carrick Little top car park (£3 in 2025). There is a small free car park on the corner as you turn onto the gravel road about half a mile before the paid one, this will add 12 mins walk each way. From the top car park, take the path North into the Mourne Mountains. Follow the path past the Annalong woods on the right. shortly after the woods take the right fork in the path and pass Lamagan on the left, followed by lower cove on the left (great trad climbing up to 2 pitches in places), then Slieve Beg should be visible ahead. This route is a little longer but less steep than the Newcastle approach. <p></p><p> <strong>Descent:</strong> The best option is to continue back off the mountain to reach the summit of Slieve Beg. Then follow the path back around to the track that runs under the Castles and back to the Mourne wall, reversing the rest of the approach.</p>	Coarse Granite with a series of cracks and ledges make this an interesting but sustained climb with a number of British 4b graded moves. The route is reasonably easy to protect with the exception of the grass ledge at the end of pitch one. Cams, tri-cams as well as offset nuts seemed to work very well. The last short pitch is able to consume a significant number of 1-3 finger width cams. <br> <strong class='pitch-title'>Pitch 1 –<span class='length'>45m</span> <span class='pitchGrade brit'>4b</span></strong><br> Starting 3m left of the right hand edge of the main face, climb up and left moving towards a corner with good holds. Climb up over the corner and onto the thin slab with a significant crack running up the middle. Keep climbing more or less straight up, and at one point around the halfway mark you veer a little right to a good ledge that’s very exposed. The route then continues up and over the broken ledge covered in grass, bilberry bushes and heather. This section is both awkward to climb and hard to protect. After the ledge, you can make a move up onto a ledge in the corner to build an anchor. This will be at more or less a full 50m rope length. The rope drag can be significant over the grass which is exactly where you don’t want it. Therefore, it’s recommended to break up pitch one at one of the reasonable ledges in the middle of the first pitch. <br> <strong class='pitch-title'>Pitch 2 –<span class='length'>25m</span> <span class='pitchGrade brit'>4b</span></strong><br> A beautiful pitch which takes a reasonable obvious line from ledge to ledge following the corners. The protection is good but some of the moves and mantles onto the small ledges can be a little challenging. Near the end of the pitch there are two similar sized blocks in a corner, the left is loose. A Belay can be made on significant ledge below the final steep corner cracks. <br> <strong class='pitch-title'>Pitch 3 –<span class='length'>12m</span> <span class='pitchGrade brit'>4b</span></strong><br> A short steep pitch that requires a mix of bridging and lay-backs or jamming on what are, for the most part very good holds, all the way up to the summit. An anchor can be built from the rocks just back from the crag edge.	{"alt": "slieve beg crag in the mournes", "url": "img/tiles/slieve-beg-crag-in-the-mourne-mountains.jpg"}	{"alt": "Poetic Justice on Slieve Beg in the mournes", "url": "img/topos/mournes/poetic-justice-climb-on-slieve-beg-in-the-mournes.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "our own image"}	{"alt": "Slieve Beg in the Mourne Mountains", "url": "img/topos/mournes/maps/"}	2024-11-09 13:26:01.356+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
250	22	Visite Obligatoire	publish	0101000020E6100000399D64ABCBF9184038143E5B077B4640	Europe/Paris	\N	350	13	granite	Slab & Vertical	S	ALP	TD (f6a+)	E1	5c	7	PG	\N	\N	\N	\N	190	2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The picturesque peak of Aiguille Dibona was re-named (formerly: Pain de Sucre du Soreiller) after Italian mountaineer Angelo Dibona after the first accent in 1913 with Guido Mayer. The route Visite Obligatoire or Obligatory Visit in English wasn’t climbed until 1988. This is a long, sustained route that is reasonably well bolted but will require a trad rack of nuts and cams to supplement. The peak finishes at an altitude just over 3,000m. Although the bottom half contains the technically hardest moves, the route doesn’t let up much. Its graded f6a+ with an alpine grade of TD (très difficile) . Escape is much harder after the 8th pitch so make sure you consider this before pressing on.	<strong>Approach</strong>: Allow a few hours for the approach which can be made from Les Etages. There is mountain hut at the base of the mountain, Ref du Soreiller.</p><p>\r\n<strong>Descent</strong>: This is done via a couple of assails off the back followed by a climbers path off the back of the mountain that weaves around to the front bringing climbers back to the hut.	\N	{"alt": "Aiguille Dibona in the Haute-Alps", "url": "img/tiles/aiguille-debona.jpg", "atributionURL": "https://www.camptocamp.org/images/304934/fr/aiguille-dibona", "attributionText": "RémiB"}	{"alt": "The Obligatory Climb on Aiguille Dibona", "url": "img/topos/aiguille-dibona/aiguille-debona-visite-obligatoire.jpg", "dataFile": null, "atributionURL": "https://www.camptocamp.org/images/304934/fr/aiguille-dibona", "attributionText": "original: RémiB"}	{"alt": "Aiguille Dibona location in the Haute-Alps", "url": "img/topos/aiguille-dibona/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
8	23	Mosoraški	publish	0101000020E6100000AE47E17A14EE2E404A0C022B87264640	\N	\N	350	11	\N	Vertical	\N	UIAA	V+	\N	\N	5	PG	mixed	bolted	\N	\N	45	2	\N	\N	\N	\N	\N	\N	350	shade	\N	{4,5,6,9,10}	3	\N	\N	\N	\N	\N	\N	2026-07-13 21:40:05.393592+00	human	\N	\N	f	\N
223	278	Joy	publish	0101000020E61000009146054EB6CA5CC0EE27637C98514940	America/Edmonton	\N	300	10	limestone	Slab	\N	YDS	5.7	S	4a	3	G	\N	\N	\N	\N	40	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Joy follows the striking right facing dihedral corner up the Mt. Indefatigable slab offering around 300m of climbing. There is little to no fixed protection but plenty of opportunity for placements all the way. Belays can be made at various positions allowing pitches to be the full length of the rope. Carrying extra gear and bringing longer ropes could speed up the climb but it’s certainly not essential. The rock is generally very solid with excellent friction but like all large mountain slabs there will be some loose rock in places. \r\n\r\nThe new guidebook Canadian Rock: Select Climbs of the West, grades the route 5.8. but if needed it’s possible to avoid any challenging bits by traversing into the slab. This drops the grade a little. It’s often considered 5.6 on the YDS scale which is somewhere around Severe or Hard Severe.	Hike across the dam and follow the main hikers trail that parallels he lake. Do not go up past the bear closure sign on the summit trail. The approach trail is pretty flat all the way to the scree slope when the route becomes very apparent. Don't follow any smaller offshoot trails that head downhill to the lakeshore, just follow the signs with hiker symbols on them. It's pretty straightforward. 25 minutes to scree slope from car. Head up the scree to the base of the route.	\N	{"alt": "Mount Indefatigable in Canada", "url": "img/tiles/mount-indefatigable.jpg", "atributionURL": "https://www.summitpost.org/mount-indefatigable/482859/c-154593", "attributionText": "Dow Williams"}	{"alt": "Mount Indefatigable topo for Joy route in Canada", "url": "img/topos/indefatigable/joy-climb-mount-indefatigable-topo.jpg", "dataFile": 5, "atributionURL": "https://en.wikipedia.org/wiki/Mount_Indefatigable", "attributionText": "original: wikipedia"}	{"alt": "Location of Indefatigable in Canada", "url": "img/topos/indefatigable/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
264	228	Bulgaria 1300	publish	0101000020E61000003997E2AAB287374062A1D634EF984540	Europe/Sofia	\N	400	11	limestone	Vertical	S	UIAA	VI+	E1	5c	7	UNSPECIFIED	\N	\N	\N	\N	40	2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The climb Bulgaria 1300 was named after Bulgaria's first artificial satellite, which in turn was named after the 1300th anniversary of the foundation of the Bulgarian state. The route takes one of the easier lines up the main face of Vratsa, however with around 400 meters of limestone the route is challenging in places with a number of pitches grade UIAA VI+ which is at least E1 5c in UK grades. The route also calls for some basic aid in sections. That said its one of the easier lines up the main face of Vratsa. The route has some pitons and bolts in sections but will require a full rack of nuts and cams.	Approach via P8 (path 8) and leave via P19 (path 19)	\N	{"alt": "The Amazing Limestone Cliffs of Vratsa", "url": "img/tiles/vratsa-bulgaria-climbing.jpg", "atributionURL": "https://www.sawthisdidthat.ca/2016/08/day-hike-from-vratsa-bulgaria.html", "attributionText": "Saw this, did that"}	{"alt": "multi-pitch rock climbing on vratsa's main face via Bulgaria 1300", "url": "img/topos/vratsa/multi-pitch-rock-climbing-on-vratsas-main-face.jpg", "dataFile": 5, "atributionURL": "https://climbing-bulgaria.com/2017/09/13/vratsa-region/", "attributionText": "Original: climbing-bulgaria.com"}	{"alt": "Location of multi-pitch climbing in Vratsa, Bulgaria", "url": "img/topos/vratsa/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
252	307	Piaz Arete Delagokante	publish	0101000020E6100000CDC98B4CC03F27408C683BA6EE3A4740	Europe/Rome	\N	156	5	dolomite	Slab & Vertical	SW	UIAA	IV+	HS	4a	4	PG	\N	\N	\N	\N	160	3	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The left hand edge or arête on the Delago Tower is a true classic, often said to be the best climb at its grade in the Dolomites. The route is consistent in grade and offers some incredible exposure, with huge drops both sides of the arête. Although steep in places the holds are typically good. The route is also well protected with bolted stances and pitons on many pitches. A light rack is still needed to fill gaps and protect the last pitch. The quality of the route makes it popular despite the lengthy and involved walk in. Its popularity has led to polish on most of the pitches. Descent requires between 2 and 5 abseils depending on rope length. It's common for climbers to stay at one of the local mountain lodges (Rifugios) as part of the trip due to the lengthy journey to and from the Vejolet Towers. Rifugio Re Alberto is the closest just 10mins walk from the towers. There are other rifugio options on the peak to the west and in the valley to the south. <br>	<strong>Approach:</strong> There are multiple options for getting to the Vajolet Towers. Much of the advice is often mixed.<br><br><strong>Chairlift and Hike:</strong> From Pera, take the Vajolet 1 chairlift then the Vajolet 2 chair lift. As of June 2023 the chairlifts start at 8:15am and parking is free. From the end of the Vajolet 2 chairlift there is a hike of around 2 and half to 3 hours depending on speed. The Chairlift ticket office will provide maps but in short, the hike follows the path up and right into the forest towards Rufugio Gardenccia. From there the routes leaves the forest and hikes uphill towards Rufugio Vajolet and Rufugio Preuss. From there the hike goes steeply up and left through the notch / saddle of the mountains towards Rufugio Alberto. This section requires some easy scrambling and crossing some small sections of snow early in the season depending on weather. From Rufugio Alberto, the towers can be approached directly. The path follows right around the smaller tower of Piz Piaz to the base of the base of the Delago and Stabeler Tower in the gully. From here climbers can scramble up and left a short way to a bolted stance on the right of the Delago Tower, then lead an easy (UIAA grade II) pitch to left, to reach another bolted stance a few meters right of the towers edge, this is where the route starts properly. Alternatively climbers can scramble directly to the start of the route (around UIAA grade II), to avoid the easy traverse pitch.<br><br><strong>Shuttle Bus:</strong> There is said to be a shuttle bus that runs between Pera in the Val di Fassa and Rufugio Gardenccia (The service departs from the large carpark by the Ciampedie chairlift in Pera). From here follow the above hiking instructions.<br><br><strong>Higher parking:</strong> There is a carpark just before Rufugio Gardenccia. Permission needs to be sought from the council to park there and the requirements for gaining permission are unclear. This would however be a quick option saving a portion of the hike. From the car park follow the directions above.<br><br><strong>Pian Peccei Chairlift extension:</strong> Vejolet 2 chairlift finishes at 1800m of elevation and Rufugio Alberto sits at 2600, so there is 800m of elevation gain on the Chairlift and hike option. The Pian Peccei chairlift goes up another 200m slightly the wrong way. Paying for this chair lift will make for a slightly longer hike in distance, but save some uphill. It typically wont be quicker, but some climbers may prefer it.<br><br><strong>Abseil Descent:</strong> From the east edge of Delago, there are a number of options for abseiling. Depending on rope length it can be done in as few as 2 abseils or as many as 5. Rufugio Alberto has <a href="/img/topos/vejolet/abseil-options.jpg" onclick="openLightBox('/img/topos/vejolet/abseil-options.jpg', 'A good map of abseil points');return false;" target="blank">a good map of abseil options here</a>. With a pair of 60m or more ropes, climbers can abseil to a large ledge then from there make an additional abseil to a point were scrambling off should be possible. Alternately on a pair of 50m ropes it's possible to make a 40m abseil to a notch between the two larger towers (Stabeler and Delago). Make another 40 then 45m to the base of the gully between the towers to the ledge the route started on. From here you can hike back.<br>	The sign at Rifugio Alberto describes the route as "Arial climbing... one of the most celebrated routes in the Alps" and it's easy to see why. Although the hike in is arduous, there can't be many rock climbing routes in the world that provide the same sense of exposure and atmosphere at such an amenable grade. <br><br><em>The description below omits the initial grade II traverse some guides include. See approch info above for further information.</em> The scramble to the start of the first proper pitch is similar in difficulty compared to the scramble to the start of the traverse/walk pitch. As always, climbers should used their own judgement and make their own decisions. <br><strong class="pitch-title">Pitch 1 –<span class="length">30m</span> <span class="pitchGrade uiaa">IV</span></strong><br>For the first proper pitch, climb more or less directly up to the next obvious ledge with a bolted belay point. Modern guidebooks suggest this pitch is the technical crux at grade IV+, but older guides grade it the same as later pitches, at grade IV.<br><strong class="pitch-title">Pitch 2 –2<span class="length">5m</span> <span class="pitchGrade uiaa">IV</span></strong><br>The second pitch has what is probably the most extreme exposure of the route. The cliff falls away over half a kilometre, almost vertically, from the northern side of the tower (left of the edge). The line starts by climbing out onto the left side of the arête, with aforementioned exposure, then moving up, keeping on the left side of the ridge, with pitons and gear options for a few meters, before moving back onto the ridge and following a line up to the next ledge with another bolted belay point.<br><strong class="pitch-title">Pitch 3 –2<span class="length">5m</span> <span class="pitchGrade uiaa">IV</span></strong><br>The third pitch moves up the right side of the arête with a few steep initial moves, before slightly easier climbing up to the next belay  point which is again bolted.<br><strong class="pitch-title">Pitch 4 –2<span class="length">5m</span> <span class="pitchGrade uiaa">IV</span></strong><br>The penultimate pitch is broken up with some ledges. Initially it moves up and right to reach a pale grey flake / pinnacle, at which point the route cuts back left towards the edge and a bolted belay on a good ledge.<br><strong class="pitch-title">Pitch 5 –2<span class="length">5m</span> <span class="pitchGrade uiaa">III</span></strong><br>The final dramatic pitch has the climber move up just left of the anchor before cutting back to the right climbing a short crack before moving onto the summit ridge. The ridge is traversed to the abseil stations on the opposite side, across from the Sabler Tower. There are a lot of options for descent (see above) but it can be done in two or more abseils.	{"alt": "The Vejolet Towers rock climbing", "url": "img/tiles/vejolet-towers-rock-climbing-dolomites.jpg", "atributionURL": "https://commons.wikimedia.org/wiki/File:Vajolett%C3%BCrme_1.jpg", "attributionText": "X-Weinzar"}	{"alt": "The Vejolet Towers topo for Piaz Arete", "url": "img/topos/vejolet/vejolet-towers-piaz-arete-delagokante-topo.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "Our own image"}	{"alt": "Location of the Vejolet Towers", "url": "img/topos/vejolet/maps/"}	2023-06-26 13:35:51.764+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
193	135	The Fame Game	draft	\N	\N	\N	60	2	\N	\N	\N	BAS	E4 6b	E4	6b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
106	117	Girona	draft	\N	\N	\N	\N	2	\N	\N	\N	BAS	VS 5a	VS	5a	5	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.032138+00	source	\N	\N	f	\N
102	117	Hell's Kitchen	draft	\N	\N	\N	66	2	\N	\N	\N	BAS	HVS 5a	HVS	5a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.032138+00	source	\N	\N	f	\N
103	117	Manannán	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E1	E1	\N	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.032138+00	source	\N	\N	f	\N
104	117	Ocean Boulevard	draft	\N	\N	\N	66	2	\N	\N	\N	BAS	E3 5c	E3	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.032138+00	source	\N	\N	f	\N
117	129	Poor Relation	draft	\N	\N	\N	45	2	\N	\N	\N	BAS	E1 5b	E1	5b	7	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.092755+00	source	\N	\N	f	\N
118	129	Raglan Road	draft	\N	\N	\N	72	2	\N	\N	\N	BAS	E3 6a	E3	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.092755+00	source	\N	\N	f	\N
114	129	Toby Jug	draft	\N	\N	\N	90	2	\N	\N	\N	BAS	E1 5b	E1	5b	7	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.092755+00	source	\N	\N	f	\N
128	130	Zulu	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	HVS 5a	HVS	5a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.331901+00	source	\N	\N	f	\N
177	135	Salango	draft	\N	\N	\N	60	2	\N	\N	\N	BAS	E3 5c	E3	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
186	135	Smashing Pumpkins	draft	\N	\N	\N	85	2	\N	\N	\N	BAS	E6 6a	E6	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
188	135	The Stoat	draft	\N	\N	\N	66	2	\N	\N	\N	BAS	E2 5c	E2	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
176	135	Titanic	draft	\N	\N	\N	60	2	\N	\N	\N	BAS	E2 5c	E2	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
182	135	Waist Deep in Alligators	draft	\N	\N	\N	100	3	\N	\N	\N	BAS	E4 6a	E4	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.580008+00	source	\N	\N	f	\N
80	91	Lochlannach	draft	\N	\N	\N	70	3	\N	\N	\N	BAS	E3 6a	E3	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.735127+00	source	\N	\N	f	\N
94	91	Mizen Star	draft	\N	\N	\N	60	2	\N	\N	\N	BAS	E2 5b	E2	5b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.735127+00	source	\N	\N	f	\N
91	91	Promised Land	draft	\N	\N	\N	60	2	\N	\N	\N	BAS	E4 6a	E4	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.735127+00	source	\N	\N	f	\N
92	91	Resurrection	draft	\N	\N	\N	70	1	\N	\N	\N	BAS	E8 6b	E8	6b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.735127+00	source	\N	\N	f	\N
85	91	Smashing Pumpkins	draft	\N	\N	\N	85	2	\N	\N	\N	BAS	E6 6a	E6	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.735127+00	source	\N	\N	f	\N
89	91	Terminator	draft	\N	\N	\N	70	1	\N	\N	\N	BAS	E8 6c	E8	6c	\N	R	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.735127+00	source	\N	\N	f	\N
95	91	The Fame Game	draft	\N	\N	\N	60	2	\N	\N	\N	BAS	E4 6b	E4	6b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.735127+00	source	\N	\N	f	\N
87	91	The Stoat	draft	\N	\N	\N	66	2	\N	\N	\N	BAS	E2 5c	E2	5c	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.735127+00	source	\N	\N	f	\N
79	91	Viking	draft	\N	\N	\N	73	3	\N	\N	\N	BAS	HVS	HVS	\N	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.735127+00	source	\N	\N	f	\N
81	91	Waist Deep in Alligators	draft	\N	\N	\N	100	3	\N	\N	\N	BAS	E4 6a	E4	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.735127+00	source	\N	\N	f	\N
249	262	Traumpfeiler	publish	0101000020E6100000A85489B2B7A035409BE271512DDC4340	Europe/Athens	\N	250	9	conglomerate	Slab & Vertical	E	UIAA	V+	VS	5a	5	PG-13	\N	\N	\N	\N	21	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The Traumpfeiler route, or Pillar of Dreams in English, is one of the best routes in the area and is justifiably very popular. It sits on the Heiliger Geist cliff, or Holy Ghost in English. The route is a mixed sport trad with plenty of bolts but still worth of a standard rack of wires and cams. Expect to have to follow other parties if you don’t start very early. With a 60m rope and some extended quickdraws the route can be reduced to 5 pitches if you are so inclined. Clearly a classic of the area the route also offers stunning views and reasonably serious climbing.	Descent: Walk south along the top of the Heiliger Geist until you get to the southern end. Look for a single eyebolt to the left (east) that is in an obvious water runoff. Rappel down this water chute to the ground. Once on the ground head left (east) past a blue door that goes into a room in the rock and follow the obvious trail to town.	\N	{"alt": "Meteor crag in Greece - Holy Ghost Rock", "url": "img/tiles/meteor-holy-ghost-cliff.jpg", "atributionURL": "https://upload.wikimedia.org/wikipedia/commons/b/b0/Meteore.jpg", "attributionText": "image source"}	{"alt": "Holy-ghost-crag-pillar-of-dreams.jpg", "url": "img/topos/meteor/holy-ghost-crag-pillar-of-dreams-topo.jpg", "dataFile": null, "atributionURL": "https://upload.wikimedia.org/wikipedia/commons/b/b0/Meteore.jpg", "attributionText": "original img"}	{"alt": "Location of Meteor climbing in Greece", "url": "img/topos/meteor/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
261	263	High Sierra	publish	0101000020E61000004F0647C9ABF321C0352905DD5EB23D40	Africa/Casablanca	\N	120	4	granite	Slab	S	BAS	VS 5a	VS	5a	5	PG	\N	\N	\N	\N	15	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	High Sierra is situated on one of Tafraout’s granite domes, not far from the locally famous Napoleons Hat rock. Tafraout granite was formed from slow cooling lava and as a result, it has a very coarse crystalline structure. The rock is also surprisingly brittle in places where it looks solid. This makes an interesting change from the nearby quartzite rock, which looks loose but is generally very solid. Although not a pure trad line thanks to a bolted start and bolted finish, the crack system in the middle two pitches offers exceptional traditional climbing. This popular route is a great option if there is bad weather on the Jebel el Kest mountains. As a south facing route, it’s possible to literally watch the granite dry over a 30miniute period after heavy rain. The start is disproportionately harder than the rest of the route.	<strong>Approach</strong>: The approach to the High Sierra Dome is a straightforward walk from the &quot;car park&quot;. Drive into and through the village of Aguerd Oudad, under Napoleon’s Hat. Follow a dirt path out of the back of the village until you see the High Sierra Dome on the right. The climb can be approached directly with a scramble on the boulders to gain the base of the climb. \r\n</p><p>\r\n<strong>Descent</strong>: Upon reaching the summit boulder, abseil back to the main plateau. Whilst it’s possible to lower off of the malion, the climber’s rope will undoubtably have picked up a lot of fine granite dust and sand along the route, meaning that running the weighted rope though the malion when lowering off, will wear through the metal (and damage your rope) faster. This will mean both need replacing more frequently. When abseiling, the rope sits statically on the malion reducing wear. From the plateau, walk east and behind the summit boulder. i.e. from the end of the abseil, turn to face the 3rd pitch anchor and walk forwards and left around the summit boulder. From here the climber walks past an incredible boulder shaped like the letter n. The climber carries onto the back of the plateau and walks of to the left (West) side to scramble down and back around.	The route is described as esoteric in some guides for good reason. The first few moves of the climb require friction stepping, on steep rock with very few and very small handholds. It can seem outrageously hard for the technical grade of 5a. These first moves are unlikely to get easier as the route weathers years of climber’s feet, that said the sticky rubber of climbing shoes adheres to the granite in a way that defies sense. The first pitch can be avoided by approaching from further left or aided using the two starting bolts. After this the climb then offers a wonderful undercut pitch that is reminiscent of <a href="/climbs/doorpost-on-bosigran/">Doorpost’s first pitch at Bosigran</a>, only bigger and longer. The third pitch offers some initial friction climbing that leads to an incredible and rather unique waist height flake. The final pitch is a short climb onto the nearby summit boulders. \r\n<br/>\r\n<strong class="pitch-title">Pitch 1 –<span class="length">30m</span> <span class="pitchGrade brit">5a</span></strong><br />Climb the block right the right corner to gain a left sloping ramp. Walk along this ramp to the first bolt. Make the aforementioned hard moves, relying on small holds for both hands and feet. After a couple of tricky moves onto the block the second bolt can be clipped. From here the route moves up and right to increasingly better holds, with some options for gear placements at the top of the slab. From there move onto the right block then left to the bolted anchor. Alternatively, the climber can move past the bolted anchor onto the ledge and create a quick traditional anchor in the start of the second pitch using the crack system and nearby wedged blocks. \r\n<br/>\r\n<strong class="pitch-title">Pitch 2 –<span class="length">30m</span> <span class="pitchGrade brit">4b</span></strong><br />Climb the exceptional sloping crack using mostly undercuts all the way around the corner to a traditional gear belay in the corner before the rising flake of the 3rd pitch. Large cams are particularly helpful for protecting this pitch. \r\n<br/>\r\n<strong class="pitch-title">Pitch 3 –<span class="length">45m</span> <span class="pitchGrade brit">4a</span></strong><br />Some delicate friction-based climbing on the low angle slab takes the climber to a bolt. Moving up from here a large flake can be used to comfortably move up the slab. Slings on the granite spikes on the top an edge of the flake can offer some additional protection as the climber moves up. The are also some options for gear higher in the giant flake. As the flake moves right the climber can pull up and slightly left onto the flake where there is a single bolt. From here the climber moves up to a crack then a bolted anchor. \r\n<br/>\r\n<strong class="pitch-title">Pitch 4 –<span class="length">15m</span> <span class="pitchGrade brit">4b</span></strong><br />From the previous anchor move onto the large plateau. There will be a large boulder with 2 additional smaller boulders on it, one of which has the summit boulder on top. Climb the large wall of the main boulder using the 3 bolts for protection. From here there is easier climbing to the summit boulder and its 2 anchor bolts with an abseil malion. Reaching this is a little runout. From the summit the climbers can abseil back to the plateau and walk off. Whilst there should be a malion on the summit anchor, carrying a spare one would be prudent.	{"alt": "The climb High Sierra on the granite dome near Tafraoute", "url": "img/tiles/high-sierra-dome-climb-in-tafraoute.jpg"}	{"alt": "The climb High Sierra on the granite dome near Tafraoute", "url": "img/topos/high-sierra/high-sierra-topo-on-a-tafraouts-granite-dome.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "our own image"}	{"alt": "The location of the route High Sierra in Tafraoute", "url": "img/topos/high-sierra/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
280	253	Sammy Higgins	publish	0101000020E6100000B8E68EFE975B18C0FCA6B05241114B40	Europe/London	\N	56	3	granite	Slab	NE	BAS	VS 4C	VS	4c	5	PG	\N	\N	\N	\N	70	2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Some brilliant climbing over 3 pitches, set high on eagle mountain, this old 1964 route is undeservingly neglected. The route has delicate slabs, steep moves to pass bulges, incredible exposure, a great corner crack (off width in places), and mostly good protection (the second pitch needs a big cam early on). The route is graded VS, but from the 1960’s. It's probably more like HVS compared to other Mournes climbs. There are some caveats with the route which means it isn’t as accessible as other Mourne multi-pitch. The final part of the walk-in is very steep, and the terrain is tricky. The second and third pitches require a longer dry period (perhaps a week) or they will be wet (still climbable though).	<strong>Approach:</strong> Allow 70 mins. Park by the fence on the left before the ford at Sandy Brae farm. <a href="https://maps.app.goo.gl/JEtoYtqPjdoZ92Dc8" target="blank">54.118412, -6.068513</a>. Cross over the ford on the footbridge and follow the path for about 30 mins until the route is clearly visible on the left. Then try to pick the best path up towards the base of the climb. The grass leading up to the start of the route is very steep and there is only a small ledge to belay from. Climbers may prefer to rack up on the larger (but still small), ledge below the gully / chimney. The approach to the start of the climb is steep grass. It's possible to build a belay anchor a few meters before the grass ends and the granite of the route is underfoot. It may also be preferable to abseil in from above.<br /><br /><strong>Descent</strong>: It's possible to scramble up and hike back over the top of eagle mountain to the car, or abseil off one of the larger spiked blocks. The abseil can take the climbers back to the 'racking up' point. We left a sling and maillon to do this in May 2026.	<strong class="pitch-title">Pitch 1 –<span class="length">28m</span> <span class="pitchGrade BAS">4c</span></strong> Follow the corner (dihedral), before moving out right towards the right hand edge (arête) under a short bulge / roof. The rusted peg is now gone. Pass through the gap in the bulge with difficulty (crux) using the main vertical crack. From here proceed up the delicate slab, to exit via steeper rock, onto the large grassy belay ledge.<br><strong class="pitch-title">Pitch 2 –<span class="length">18m</span> <span class="pitchGrade BAS">4b</span></strong> Another fantastic pitch with incredible views (although suffers seepage after rain). Climb the gradually widening corner crack to finish on a large block belay at the top on the left wall. <br><strong class="pitch-title">Pitch 3 –<span class="length">10m</span> <span class="pitchGrade BAS">4a</span></strong> A short corner wall, offers a few interesting moves to reach the grass ledges and easier ground at the top.</p><p><strong>Protection Notes:</strong> The peg below the crux, on pitch 1, was well rusted in 2026 and disintegrated on touch, like something you would see in a cartoon leaving just a rusty smear there now. Otherwise the gear is good. At least one large cam (big silver DMM number 6 or bigger), may be helpful for the start of the second pitch.	{"alt": "Sammy Higgins Climb on Eagle Mountain", "url": "img/tiles/eagle-mountains-mourne-mountains.jpg"}	{"alt": "Route topo of Sammy Higgins climb on Eagle Mountain in Mournes", "url": "img/topos/eagle/sammy-higgins-climb-topo-eagle-mountain.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "our own image"}	{"alt": "Map of Eagle Mountain in the Mournes, NI", "url": "img/topos/eagle/maps/"}	2026-05-24 13:26:01.356+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
251	236	Direkte Plattenwand	publish	0101000020E6100000CC5F217365F82140395FECBDF88E4740	Europe/Zurich	\N	230	8	limestone	Slab	S	FS	f5a	VS	4c	5	runout	\N	\N	\N	\N	70	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Direkte Plattenwand, is one of the easier, more popular routes up the middle of Bruggler crag. The route is bolted but requires a small trad rack to ease some of the run out sections. There are many routes on this face, some can be climbed clean. Although it’s a big face with lots of options, expect some crowds. Be wary of rockfall from other parties of climbers and be careful not to dislodge rocks from the pitted limestone route.	<strong>Approach</strong>: The route is best approached from Stattboden.<br><br>\n<strong>Descent</strong>: Carefully move along the summit to the cross  on the left after the final pitch. From there a path can be followed to walk off the cliff.	\N	{"alt": "Bruggler offers great Rock Climbing", "url": "img/tiles/bruggler-crag-switzerland.jpg", "atributionURL": "https://www.camptocamp.org/waypoints/42475/fr/brueggler", "attributionText": "img: Camp To Crag"}	{"alt": "The Direct Route up Bruggler", "url": "img/topos/bruggler/bruggler-direct-route-topo.jpg", "dataFile": null, "atributionURL": "http://blog.buschnick.net/2013/06/climbing-bruggler-hiking-speer-1950m.html", "attributionText": "Original: Soren"}	{"alt": "Briggler is a great climbing location", "url": "img/topos/bruggler/maps/"}	2021-10-15 01:01:44.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
262	232	Pinnacle Slab	publish	0101000020E610000023F3C81F0C0C22C072F90FE9B7D73D40	Africa/Casablanca	\N	130	3	quartzite	Slab	S	BAS	D 3b	D	3b	1	PG	\N	\N	\N	\N	5	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The Pinnacle Slab on the Amzkhssan Wall offers around 130m of enjoyable climbing with little technical difficulty. The Amzkhssan Wall could be climbed hundreds of times without ever using the same holds. Although this particular route is only graded <abbr title="Difficult">Diff</abbr>, it should not be underestimated. Finding gear in the quartzite rock can be difficult and the leader can easily be enticed off the route in pursuit of placements, leading to serious rope drag quite quickly. In addition, route finding is more or less impossible to follow once on the wall. That said the climbing doesn’t go above V. Diff / Severe anywhere on the right side of the rock face. A confident leader with a mixed rack, particularly smaller gear, will be rewarded with enjoyable and easy climbing, an ideal option for a short warm up climb, especially given its easy approach and nearby parking.	<strong>Approach</strong>: Parking can be found on the higher side of the nearest hairpin bend. There is space for 2 cars. From here it’s a short walk around the corner to the base of the Amzkhssan Wall.\r\n<br />\r\n<strong>Descent</strong>: From the summit move over the back and trend North West (left with your back to the climb). This will allow the climbers an easy scramble down to a path that moves around the west side of the wall bringing climbers back towards the road.	The Pinnacle Slab starts about 10m right of the Amzkhssan Rib climb (graded V. Diff itself) which follows most obvious break up the middle of the wall. The goal is climb up to a small black overhang split by a crack, the climber passes this and heads up the wall to create a second anchor at the pinnacle, with the final pitch taking the easiest line through the steep overlap to the top. \r\n<br/>\r\n<strong class="pitch-title">Pitch 1 –<span class="length">50m</span> <span class="pitchGrade brit"></span></strong><br />Start 10m right of the main break and a meter or two left from the outcropping bulge at the base of the wall. Climb up the slabs as far as the rope and any rope drag will allow, until you reach a suitable belay. \r\n<br/>\r\n<strong class="pitch-title">Pitch 2 –<span class="length">50m</span> <span class="pitchGrade brit"></span></strong><br />Continue up the slab heading to the obvious pinnacle not too far from the top of the wall. \r\n<br/>\r\n<strong class="pitch-title">Pitch 3 –<span class="length">30m</span> <span class="pitchGrade brit"></span></strong><br />There are a few options to get though the steeper overlap at the top. Take the easier line directly above the pinnacle to create the belay at the top of the wall.	{"alt": "Amzkhassan Wall Climbing in Morocco Jebel El Kest", "url": "img/tiles/amzkhassan-wall-climb-in-morocco.jpg"}	{"alt": "The Amzkhssan Wall's Pinnacle Slab climb in Morocco", "url": "img/topos/amzkhssan/amzkhssan-wall-pinnacle-slab-climb-morocco.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "our own image"}	{"alt": "The location of the Amzkhssan Wall in the Jebel El Kest Mountains", "url": "img/topos/amzkhssan/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
259	280	Original Route	publish	0101000020E6100000C2548E249C710BC05C44CA051D714D40	Europe/London	\N	137	5	sandstone	\N	E	BAS	E1 5b	E1	5b	7	UNSPECIFIED	\N	\N	\N	\N	45	2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The Original Route up The Old Man of Hoy is a classic climb amongst classic climbs. Originally climbed in 1966 by Rusty Baillie, Chris Bonington and Tom Patey, this iconic multi-pitch has been the centre of some of the most focused media attention around climbing in the late 1990’s. The route climbs the east landward face, of this northern Scottish sandstone stack. It’s technically not a sea stack (because it’s attached to the mainland), but is usually referred to as such. The route requires a mix of technical climbing, including a short down climb, a traverse, as well as crack climbing and bridging skills. The route is made harder by nesting Fulmars who don’t like climbers around their nests. Descent from the top requires abseiling back down the route. The Original Route is listed in Ken Wilsons Hard Rock book, sitting alongside other UK classics in the <abbr title="Very Severe">HVS</abbr> to <abbr title="Extremely Severe">E1</abbr> range. The route has seen some incredible accents over the years, including being climbed by Red Szell as the first blind man to climb up The Old Man of Hoy. In more recent years Jesse Dufton, also blind, went one step further and climbed it on lead. Chris Bonington also made recent repeat of this stack while in his 80’s, over 50 years after his first accent, he climbed the stack with Leo Holding. The climb was originally graded HVS, but most recent guidebooks list it as E1. Although some pitches are straightforward, it would be easy to underestimate the complexity of getting up and back down safely. The exposure is incredible.	<strong>Approach</strong>: Head up the hill behind Rackwick Hostel until reaching the cottage at the top from which a well-constructed path will lead to the viewing promontory across from the Old Man of Hoy. Head North 120m from here and take the small well-worn path down to the rubble scramble to the stack at the base. \r\n</p><p>\r\n<strong>Descent</strong>: There are two options for descent. The first is to abseil each pitch. Typically, there will be slings left behind to rap from at each anchor point. The climber should come prepared to replace them if they are not in a suitable condition. There is also sometimes a rope in situ to help with the pitch two traverse. If the party is not using 60m ropes, and there is not a rope in situ on pitch two, then climbers should be prepared to leave a spare rope behind on ascent, in order to facilitate the descent here. Alternatively, if the party is using a pair of 60m ropes, these can be used to rappel to the end of pitch 3. Then a short rappel to the end of pitch two. Then a longer rappel, free hanging, should take the climbers to the base of the stack. It should go without saying, but climbers should have a pair of prusik cords during the abseil. One to back up the abseil, the other in case the climber needs to ascend the rope for some reason.	\N	{"alt": "The Old Man of Hoy Rock Climbing Stack", "url": "img/tiles/old-man-of-hoy-climb.jpg", "atributionURL": "https://www.flickr.com/photos/p300njb/43950216932", "attributionText": "Rab Lawrence"}	{"alt": "The Old Man of Hoy Rock Climbing Stack", "url": "img/topos/hoy/the-original-route-on-the-old-man-of-hoy-stack.jpg", "dataFile": 4, "atributionURL": "https://www.flickr.com/photos/paul_stephenson/5927357279", "attributionText": "originl: Paul Stephenson"}	{"alt": "Old man of Hoy Located on the Isle of Hoy", "url": "img/topos/hoy/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
265	260	East Ridge	publish	0101000020E61000001BD65416857D10C0D829560DC2C84940	Europe/London	\N	71	4	limestone	Slab & Vertical	SE	BAS	S 3c	S	3c	3	PG	\N	\N	\N	\N	25	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The East Ridge of Great Tor offers easy climbing right above the beach of Three Cliffs Bay. The route is non-tidal, but approaching from the beach is only possible at low tide. A not so straightforward scramble down or abseil from a nearby block are alternative options for reaching the base of the climb. The route is broken up by 3 significant ledges. Although it’s set as 4 pitches, linking pitch 2 and 3 or even 3 and 4 makes the pitches a bit more significant. There are also some variations that up the difficulty to Very Severe, although the variations avoids the dramatic south east edge overlooking the beaches and sea. Although Great Tor is the most significant multi-pitch climb in the area, the nearby 3 cliffs bay has a multitude of shorter trad climbs.	<strong>Approach</strong>:<br />\r\nFrom the National Trust Car Park at Penmaen (postcode: SA3 2HH), head back to the main road, turn right up the hill, then cross over to the smaller parking area and bus stop. Through the gate, follow the path towards Three Cliffs Bay. <br />\r\n<strong>Option A – Abseil & Scramble Down</strong>:<br />\r\nTake the first right at the fork in the path, then at the next fork take the left. Follow the path west along the coast until it heads out towards Great Tor. Before scrambling up onto the Tor proper (tor = rocky peak), there is a large block, that at the time of writing, was suitable for a gearless & retrievable abseil. This may be the most appropriate option if the grass is wet and the tide is in. 50m of abseil reaches the rocky ledges. From there, it’s possible to scramble across to the base of the climb.<br />\r\n<strong>Option B –  Low Tide Beach Approach</strong>:<br />\r\nTake the left at the first fork in the path and head down, all the way down to Three Cliffs Bay beach.  Keep to the right side of the beach, following it all the way to the base of Great Tor and scramble up to the non-tidal start of the route. <em>The tide has to be at it's lowest for this option.</em><br />\r\n<strong>Option C –  Scramble Down</strong>:<br />\r\nFollow the instructions of option A, but carry on over the first outcrop until the gully between the two peaks. From here it’s possible to scramble down carefully to the base of the climb. Not recommended un-roped in wet conditions. <br />\r\n<br /><strong>Descent</strong>:<br />\r\nScramble off the Tor to the North, following the worn path down into the gully then back up and out, onto the foot path. Take care on the polished limestone.	Great Tor is a limestone tower that divides Three Cliffs Bay to the East from Oxwich Bay to the West. The Tor rises out of the sand between these beaches and can be climbed on all faces. While steep in places, the holds are usually plentiful and solid. Protection is also mostly easy to come by. \r\n<br />\r\n<strong class="pitch-title">Pitch 1 –<span class="length">18m</span> <span class="pitchGrade bas">3c</span></strong><br />\r\nThe first pitch follows a crack surrounded by good holds. Upon reaching the bulge before the ledge, this can be tackled  directly using good handholds or the climber can pass it on the right. An anchor can be built in the wall at the back of the large ledge. \r\n<br /><strong class="pitch-title">Pitch 2 –<span class="length">16m</span> <span class="pitchGrade bas">3a</span></strong><br />\r\nStep out from the ledge to the south east ridge, where a grove will take the climber up the arête (edge) to another large ledge. The climber can build an anchor here which offers more protection, or continue up pitch 3 to the next ledge.\r\n<br /><strong class="pitch-title">Pitch 3 –<span class="length">13m</span> <span class="pitchGrade bas">3a</span></strong><br />\r\nA short pitch on its own, that once again takes the arête (edge / ridge) up to the next ledge. The climbing is easy and the views and are incredible. An anchor can be made before the final steep pitch. Alternatively pitch 3 & 4 can be linked. \r\n<br /><strong class="pitch-title">Pitch 4 –<span class="length">24m</span> <span class="pitchGrade bas">3c</span></strong><br />\r\nThe final pitch offers a short steep wall before giving way to much easier climbing up the ledges to the summit of Great Tor. An anchor can be built on the top with creative use of various protection and slinging one of the larger summit blocks.	{"alt": "Great Tor climb on the beach in Gower South Wales", "url": "img/tiles/great-tor-in-gower-south-wales.jpg", "atributionURL": "https://www.flickr.com/photos/swansealocalboy/14697940249/", "attributionText": "Gareth Lovering"}	{"alt": "East Buttress Climb on Great Tor in Gower.", "url": "img/topos/gower/east-buttress-climb-on-high-tor-gower.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "our own image"}	{"alt": "Great Tor location on Three Cliffs Bay", "url": "img/topos/gower/maps/"}	2021-10-20 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
268	293	Via Steger	publish	0101000020E610000012D04546358C2740110F4C612A414740	Europe/Rome	\N	175	8	dolomite	Vertical	SW	UIAA	IV+	HS	4a	4	G	\N	\N	\N	\N	10	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The Sella Towers are some of the most popular climbs in dolomites. The Towers offer great quality and variety of routes, as well as a short and simple approach. Via Steger is one the popular classic routes. Going at a grade of IV+ and around 175m of climbing with pleanty of extensions and variations possible, the climb won't disappoint. The crux is at the end of the route and is at least IV+, but well protected by pitons. Although the approach is short, the decent is considerably longer. The popularity has led to some polished rock in places, especially the top two pitches.	<strong>Approach & Descent</strong><br />The approach is simple. Park in the Sella Pass near the giftshop and hotel Mariaflora, were there are a number of free roadside bays. Likely very busy at peak times. Heading East along the road past the hotel, take the path on the left up the grass hill before the Sella Towers. To climb the bottom extension, take the right fork down cutting across to the base of the first Sella tower. For the original start, stay high on the hill heading for the path past the first rocky outcrop called the locomotive (it looks a bit like a train from below).There are two descent options.<br /><strong>Option 1, Abseil:</strong><br/>The route and adjacent routes can be abseiled using the large cemented rings. Given the route is often busy, this is not recommended.<br /><strong>Options 2, 'walk' off:</strong><br/>This route requires a short abseil or short steep down climb and will take around an hour. From the summit, head East and follow the path to the col (the point the two peaks join) between the first and second Sella tower. Cross over to the path behind the second tower and follow this until a fork marked by a Carin (pile of stones). Take the right south facing fork and scramble and down climb the rough path. When the path reaches a bolted abseil, take this down to the path below. This can be followed back to the path from by the hotel.	The route described here includes a bottom extension of 2 pitches (one good and one a simple scramble) that can be easily avoided if needed. For the climbers that value length the extension adds 25m of good climbing plus a scramble on a scree path. The Val de Guardia guide doesn't show the extension. The rockfax guide shows the extension in the photo topo but describes only the core route in the text description. This is a poor oversight that may cause confusion to anyone trying to use the rockfax guide. <br /><strong class="pitch-title">Pitch 1 –<span class="length">25m</span> <span class="pitchGrade UIAA">III+</span></strong>:<br /> Starting just left of the plaque, take a left leaning line up reasonably good holds following a couple bits of fixed gear to a good ledge. Head up and left to belay at the large slung block. <br /><strong class="pitch-title">Pitch 2 –<span class="length">40m</span> <span class="pitchGrade UIAA"></span></strong>:<br /> Follow the scree covered path left (facing the climb) and up, to create a belay at the official start of the climb. <br /><strong class="pitch-title">Pitch 3 (1 of Steger) –<span class="length">25m</span> <span class="pitchGrade UIAA">III+</span></strong>:<br /> Climb the left leaning crack up and over blocky ground to belay on a good ledge. <br /><strong class="pitch-title">Pitch 4 (2 of Steger) –<span class="length">20m</span> <span class="pitchGrade UIAA"></span></strong>:<br /> Traverse right and up to belay at a large ledge. An alternative variant is to keep to the left edge arete making harder and more interesting moves with good protection (traditional with some pitons) until a steep corner with good holds will take the climber to the large ledge. <br /><strong class="pitch-title">Pitch 5 (3 of Steger) –<span class="length">40m</span> <span class="pitchGrade UIAA">IV-</span></strong>:<br /> Following the original route, climb up the chimney and make a belay at the top on the left side. Following the variant, make some harder (maybe UIAA V) moves over a steep cracked bulge up and right, using good holds. <br /><strong class="pitch-title">Pitch 6 (4 of Steger) –<span class="length">15m</span> <span class="pitchGrade UIAA">IV-</span></strong>:<br /> Move left along the ledge until the obvious crack. A belay can be created at the base of the crack. Some questionable fix gear. <br /><strong class="pitch-title">Pitch 7 (5 of Steger) –<span class="length">40m</span> <span class="pitchGrade UIAA">IV</span></strong>:<br /> Follow the polished crack, making some moves (~IV) over steep ground to reach a belay platform with a cemented anchor. <br /><strong class="pitch-title">Pitch 8 (6 of Steger) –<span class="length">25m</span> <span class="pitchGrade UIAA">IV+</span></strong>:<br /> The crux pitch moves up over easy ground before making an exposed but we'll protected traverse around to the right. The climber then has to take the crack above which has some good but hidden holds and pitons protecting it. There is a fixed belay at the end of this pitch.<br /><strong class="pitch-title">Scramble to Summit</strong>:<br /> Scramble to the summit where the climbers can abseil back down (not ideal for parties coming up) or scramble off the back where some walking then down climbing and an abseil or two will take climbers to a path which leads back round to the parking in the Sella Pass.	{"alt": "The First & Second Sella Towers in the the Sella Pass in Italy", "url": "img/tiles/sella-towers-in-dolomites.jpg"}	{"alt": "Via Steger on the first Sella Tower in the Dolomites", "url": "img/topos/sella/via-steger-climb-on-the-first-sella-tower-dolomites.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "our own image"}	{"alt": "Via Steger Climb on the First Sella Tower in the Dolomites", "url": "img/topos/sella/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
216	288	Esparraguera	publish	0101000020E61000005436ACA92C0AFD3F54909F8D5CCB4440	Europe/Madrid	\N	190	6	conglomerate	\N	S	UIAA	V+ (f5c)	VS	5a	5	PG-13	\N	\N	\N	\N	35	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Esparraguera offers an exciting 190m VS (f5c) multi-pitch climb on the fantastic conglomerate rock of Montserrat in Spain. The route is sustained and consistent in grade. The hardest pitch is steep but has big holds and is well bolted, this may well feel like the easiest pitch if you are used to indoor climbing / bouldering. Whilst described as a clean trad route in many guidebooks, Esparraguera has a good amount bolts (17) and pitons (2) in sections in the middle pitches. Most of the harder moves are protected by old bolts. You will need a full trad rack of nuts and cams. Tri cams are particularly helpful for the pockets. The last pitch has no fixed protection. The route is given f5c in some guides or UIAA V+ in others, it is hard to convert to British grades but given the protection is good at the harder sections, the British grade of VS 5a (maybe HVS 5b) seems best. If anything feels hard, take some time and search for better holds, there will be some. The descent requires 3 abseils of 40m, 40m and just under 60m.	Park in the lower parking lot of Vinya Nova (41.585600, 1.816281). From there take the path north into the forest towards Torrent del Pont. Advance through the torrent and shortly after follow the path that goes to the right (milestones and white marks). Follow this uphill and arrive at a turnoff, head north. Pass by the foot of Pollegó de la Vinya Nova. Continue to the base of the Gray Rock.<br /><br />\r\nThe descent requires 3 abseils of 40m, 40m and just under 60m. To find the anchor to abseil you need to walk along the ridge for 80m. You go over a couple of small peaks. You may want to stay roped for this slinging the occasional bush as the ground can be loose. If you use a pair of 50m ropes you can either use a tree to break the last abseil into 2 or create a trad anchor on the way or even abseil carefully off the end of the rope and downclimb the last 10m. All these options have risk especially if you end up doing it in the dark.	This route is a stunning mixed protection multi-pitch rock climb. Because it’s an absolute classic it can be popular, even out of season. The climb is interesting and sustained, with a mixture of delicate slab work and a few big moves on a steep wall on the 3rd pitch. The views are incredible looking out over the valley and the exposure is immense in places.  Especially where the climb moves between the spires, up the middle of the 4th pitch and the travers across a ledge on the 5th pitch. The route could be climbed clean without use of the bolts if you have the confidence, time, patience and stamina to find protection on the slab sections which can be quite blank. It’s quicker and likely more enjoyable if you climb the route mixed, using the in-situ bolts with additional gear to protect the run out sections on the 1st, 4th and 5th pitches and protection for the <em>entire</em> 6th pitch. A set of cams, nuts and tri-cams should cover you. Larger pieces could be helpful on the last pitch. 50m ropes are enough to get to the top, but 60m ropes are needed for the decent to save down climbing the last abseil or using a tree / bush for the last part. The rock can be loose, especially on pitch 1. Loose rocks also tend to gather on the ledges, so make sure you wear helmet and try to avoid dislodging rock onto the path below which can be popular with hikers, who won’t have helmets! All the belay points have 3 expansion bolts which can be used for the anchors, except the top of the route where you will need to sling a bush or two and make sure you are not belaying more weight up than can be comfortably held. If climbing as a 3, it would be safer to belay the 2nd and 3rd climber separately on this pitch.\r\n<br />\r\n<strong class="pitch-title">Pitch 1 –<span class="length">35m</span> <span class="pitchGrade uiaa">IV+</span></strong><br />\r\nThe first pitch moves up to some trees on the ledge then left onto the ridge and directly up the centre of the slab spire to the belay. \r\n<br />\r\n<strong class="pitch-title">Pitch 2 –<span class="length">40m</span> <span class="pitchGrade uiaa">V</span></strong><br />\r\nClimb up the spire to some harder moves not long after the belay. These are well protected by bolts and pitons. This pitch then eases off near the top to a belay behind the next spire.\r\n<br />\r\n<strong class="pitch-title">Pitch 3 –<span class="length">25m</span> <span class="pitchGrade uiaa">V+</span></strong><br />\r\nClimb the steep face using the big pockets which make for jug sized hand holds. Follow the bolts up onto the summit of this little spire and find the anchor in the gap between the next spire. This pitch is a quite different in style to the others, so although the crux on paper it may feel easy to someone comfortable with bouldering, or particularly tough if you normally stick to slabs.\r\n<br />\r\n<strong class="pitch-title">Pitch 4 –<span class="length">50m</span> <span class="pitchGrade uiaa">V</span></strong><br />\r\nA long, exposed climb up the largest spire. Harder moves early on that change into a lower angled slab with no bolts and limited protection options.  The anchor is to the right near where this spire joins the next. Don’t climb to the top of this spire. \r\n<br />\r\n<strong class="pitch-title">Pitch 5 –<span class="length">25m</span> <span class="pitchGrade uiaa">IV</span></strong><br />\r\nThe is a single bolt on this pitch and no clear path to the next anchor. Moving up to a ledge and wall offers good hand holds and some pockets for protection, before a traverse right to the anchor. \r\n<br />\r\n<strong class="pitch-title">Pitch 6 –<span class="length">30m</span> <span class="pitchGrade uiaa">IV+</span></strong><br />\r\nMove straight up following the crack system. There is no fixed protection but a number of placements can be found. Move over a small ledge to the summit. This is a sustained pitch of UIAA grave IV or IV+ all the way. There are no bolts at the top so you will need to sling a bush or two and make sure you are not belaying more weight up than can be comfortably held. If climbing as a 3, it would be safer to belay the 2nd and 3rd climber separately on this pitch.	{"alt": "Grey Rock at Montserrat", "url": "img/tiles/grey-rock-at-montserrat-new.jpg", "atributionURL": "http://joanasin.blogspot.com/2012/01/roca-gris-via-esparraguera.html", "attributionText": "original image"}	{"alt": "Topo for Esparreguera climb in Montserrat Spain", "url": "img/topos/montserrat/roca-gris-esparreguera-topo.jpg", "dataFile": 5, "atributionURL": "https://www.multi-pitch.com/about/", "attributionText": "our own image"}	{"alt": "Grey Rock climb location at Montserrat", "url": "img/topos/montserrat/maps/"}	2021-10-15 01:01:32.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
266	297	FM	publish	0101000020E6100000FC34EECD6FD817C04B917C2590144B40	Europe/London	\N	160	6	granite	Slab	SE	BAS	VDiff	VDiff	3c	2	runout	\N	\N	\N	\N	70	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Slieve Lamagan offers a great range of multi-pitch climbs that are typically lower difficulty. Route finding is not that easy once on the slab. Fortunately, there are many options for variation on or around the same grade, therefore getting lost isn’t a disaster. The Route FM takes a reasonably direct line up the slabs and exits the steeper n shaped headwall on the east side (right). The granite is mostly immaculate and solid, although run out in places, especially off route. It will dry quickly thanks to its exposure to sun and wind. Variations take a slightly harder exit out of the final steep headwall. The crux of the route is one hard move on the first steep section around half way up.	<strong>Approach</strong>: Park in the Carrick Little car park. Take the path into the Mourne Mountains. On approach the Annalong woods will be on the right and Slieve Lamagan will be clearly visible, more or less directly ahead. Keep following the path over a run off stream then a more significant stream / river. Take the right fork  after the river and follow the path until it weaves around close to the slabs. This will be the second right after the Annalong woods end. Once close to the slabs, leave the path and head directly up the heathery slopes to the start of the continuous granite slabs of Slieve Lamagan. <br><br><strong>Descent</strong>: The decent should not be underestimated. It’s long and the ground is steep. <a href="https://amzn.to/3jtfR83" target="blank">A Mourne Mountain Map</a> will help show the mountain contours and the least steep path off which is round to the West. After climbing FM, scrambling up north-west then contouring around to the west should bring the party to a steep path that leads down towards the dam. This may take the best part of an hour. There is a chance the path is overgrown. There is also an optional additional 100+m VDiff climb called Upper FM. This sits 60m north east of the finish of FM and will bring the party closer to the summit. After this the party can contour west until the steep decent path is reached.	Slieve Lamagan slabs offer over 150m, variations and extensions can take this up to 300m of quality granite climbing at mostly easy grades. <br><strong class="pitch-title">Pitch 1 –<span class="length">35m</span> <span class="pitchGrade bas">3b</span></strong><br>Climb the white granite slab all the way up to the edge on the right for around 35m. Making sure to not stop short. A belay can be created at the small ledge. <br><strong class="pitch-title">Pitch 2 –<span class="length">45m</span> <span class="pitchGrade bas">3b</span></strong><br> Move up and slightly left to reach a small overlap. Cross this in the middle.  From there move directly up towards the where the wall steepens. A belay can be created below what looks like some giant left facing steps.  <br><strong class="pitch-title">Pitch 3 –<span class="length">25m</span> <span class="pitchGrade bas">3c</span></strong><br>What looked like some giant steps in the steep wall below represents a significant step up in technical difficulty and a clear crux for the route. Good and somewhat hidden handholds on the right can help the climber get up onto the first large and downward sloping ledge. From here good holds can be used to pass the steep section. If the second is not a strong VDiff / Severe grade climber, then leaving a cam with a long sling to help the second (or third) aid this section might be a sensible move. A Metolius number 1 ultralight TCU works a treat. Creating a belay just above the steep section is an option if desired, otherwise carry on up to a good belay ledge.<br><strong class="pitch-title">Pitch 4 –<span class="length">20m</span> <span class="pitchGrade bas">3b</span></strong><br>For the finish described in the photo topo, head up and right performing a delicate traverse on good footholds to a decent sized ledge below the bottom right of the n shaped steep headwall. <br><strong class="pitch-title">Pitch 5 –<span class="length">25m</span> <span class="pitchGrade bas">3c</span></strong><br> The finish described here offers good climbing on slightly brittle and quite steep granite. Whist not perfect, it does offer nice moves in the 3b to 3c range and ends with a wonderful finish on a prominent ridge.<br><strong class="pitch-title">Original Finish <span class="length">45m</span> <span class="pitchGrade bas">3b</span></strong><br>From the end of the 3<sup>rd</sup> belay the original finish takes 2 pitches, first moving diagonally up and right over the slab to below the broken section of the headwall. Then a final pitch up the broken rock to a jug handled crack. <br><strong class="pitch-title">Variation Finish <span class="length">35m</span> <span class="pitchGrade bas">4a</span></strong><br>A high quality but harder, Severe graded finish, takes a route up and slightly left on the final slab to the headwall. Then a final pitch moves up the steep corner on good holds.	{"alt": "Slieve Lamagan", "url": "img/tiles/slieve-lamagan-mountain.jpg"}	{"alt": "Slieve Lamagan climb FM in the mournes", "url": "img/topos/lamagan/slieve-lamagan-fm-climb-in-the-mournes.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "our own image"}	{"alt": "Slieve Lamagan In the Mourne Mountains", "url": "img/topos/lamagan/maps/"}	2026-05-09 14:26:03.356+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
270	250	Australia West Face	publish	0101000020E6100000A4FAD347306610C05E967922FD8F4A40	Europe/London	\N	113	6	slate	Slab	SE	BAS	E1 5b	E1	5b	7	PG	\N	\N	\N	\N	15	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The west face of the Garret Pit, in Dinorwic Quarry is more multiple pitches than true multi-pitch rock climbing. Nevertheless, it makes for an exceptional adventure offering over 100 meters of climbing on immaculate slate with a variety of grades to choose from. The trad climbs in the quarry are skewed towards the mid to higher end of the traditional climbing scale, with HVS & E1 needed to get the most out of the routes. The sequence described here links up a number of popular high-quality routes, starting with Looning the Tube and finishing with Act Naturally on the Skyline Buttress. The Garret area is commonly misnamed Australia by climbers. In terms of climbing style, there is some technical variety in the routes, but small edges, crimps and precise footwork are a regular theme on most of the terraces. There are two good sport routes included in the link up. The trad lines are all easy to protect with the exception of the M.I.L. Arete on pitch 4, which is short but very bold. Parking is good and offers easy and quick access making this a viable option to do in less than half a day.	<strong>Approach:</strong><br>The approach is simple and takes around 15 to 20mins. Free roadside parking is plentiful before and around the bus stop turning circle at <a href="https://www.google.com/maps/place/53.12830201,-4.10817526" target="blank">53.12830201, -4.10817526</a> but it may be busy during the peak of summer. The footpath starts at the turning circle. From here it’s a short walk into the quarry. Cross a locked gate into the quarry proper and walk uphill and through a tall rock arch to the Looning the Tube area.  <br><br><strong>Descent:</strong><br> From the top of the skyline buttress, an additional climb (Goblin Party) can be completed at the Alice Springs level to the East or climbers can descend to the West either by the main quarry path (recommended) or a more direct route down the slate scree slopes.	There are some rough gear recommendations for the various pitches below, but in general a light rack should cover the climbs here. <br><strong class="pitch-title">1. Looning the Tube –<span class="length">20m</span> <span class="pitchGrade BAS">E1 5b</span></strong>:<br> The belayer can anchor to the large rusted hooks on the left side of the slab. The leader starts with a rising traverse out to the right above the rusted tube to the first bolt. The leader continues on to the rusted chain, again clipping this before moving into the left leaning crack. The crack is followed to the top. Using a medium two finger width cam can protect the crack before the final bolt where there crux is. <br><strong class="pitch-title">2. Steps of Glory –<span class="length">15m</span> <span class="pitchGrade FS">f5b</span></strong>:<br> A simple but enjoyable sport climb that takes an obvious line on the left side of the largest slab. Making an anchor on the ledge above is tricky for this pitch but the large precarious block could be used. Access the risks and if in doubt use the lower-off or walk around. This is graded f5c in other guidebooks. <br><strong class="pitch-title">3. Sodor –<span class="length">11m</span> <span class="pitchGrade FS">f5c</span></strong>:<br> Graded f6a in some guides, this short sport route starts at the obvious graffiti face and climbs the hair line crack to the top. An anchor can be made using the low bolts in the wall behind. There are other alternative routes on this slab at similar grades.<br><strong class="pitch-title">4. M.I.L. Arete –<span class="length">11m</span> <span class="pitchGrade BAS">E1 5b</span></strong>:<br> The climbing on this pitch is no harder than earlier sections but the protection is very poor. To find the line, look for a rusted metal bar, roughly the length of a person’s forearm, that hangs downwards, on the left side of the short slab. The slab can be climbed on the left to the obvious break. There are a couple of small slots for protection up to and on the break. From the break, climb to the bar, sling this with difficulty. - knowing the correct knots and how they hold is important because the bar slopes down. The route then climbs past this bar to the top with the crux on the upper half of the wall. An anchor can be made using the boulder above the climb. <br><strong class="pitch-title">5. Razorback –<span class="length">13m</span> <span class="pitchGrade BAS">HVS 5a</span></strong>:<br> Razorback follows the obvious left leaning line not far back from the top of the last pitch. The protection is much better than it looks, taking small wires early, with better gear higher up. The crack offers very enjoyable HVS climbing. Once again, an anchor can be made using a boulder at the top of the pitch. <br><strong class="pitch-title">6. Act Naturally –<span class="length">43m</span> <span class="pitchGrade BAS">VS 4b</span></strong>:<br>  This pitch climbs the obvious natural line up the tallest part of the skyline buttress for a comparatively easy last pitch. Follow the grove and ledge system up to a single bolt, move right then climb up the crack and groves to the top where an anchor can be built using a pair of bolts.	{"alt": "The West face of Dinorwic Slate Quarry gives a grand day of climbing", "url": "img/tiles/dinorwic-slate-quarry-west-face-climbs.jpg"}	{"alt": "Rock Climbs on Dinorwic Slate Quarries West Face", "url": "img/topos/dinorwic-quarry/dinorwic-quarry.jpg", "dataFile": 0, "atributionURL": "https://creativecommons.org/licenses/by/4.0/", "attributionText": "our own image"}	{"alt": "Dinorwic Slate Quarry Location in Llanberis, Wales", "url": "img/topos/dinorwic-quarry/maps/"}	2022-11-13 21:27:45.59+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
217	289	Roaring Forties	publish	0101000020E6100000E6797077D65E21C06AA510C825504B40	Europe/London	\N	81	3	quartzite	Slab & Vertical	\N	BAS	VS 4c	VS	4c	5	G	\N	\N	\N	\N	20	2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The route takes a line up the lefthand side of the slab finishing in a steep but well protected final pitch.	Follow the signs posts for Slieve League view point from Killybegs through Carrick and Teelin villages to the road end car park for Slieve League. On foot now, walk the 2KM until you are looking over to the solitary watchtower. Descend towards the sea down a deepening gully, keeping the tower on your right. This will take you to a view point looking across at Sail Rock. Descent to the base is by abseil either down the face or down the ridge across the zawn from Sail Rock main face.	\N	{"alt": "Sail Rock in County Donegal offers great climbing", "url": "img/topos/sail-rock/sail-rock-donegal-crag-s.jpg", "atributionURL": "http://donegalclimbing.ie/about/", "attributionText": "Bren Whelan"}	{"alt": "Climb topo for sail rock Ireland", "url": "img/topos/sail-rock/sail-rock-topo-ireland-donegal.jpg", "dataFile": null, "atributionURL": "https://uniqueascent.ie/sail_rock_guide", "attributionText": "Iain Miller"}	{"alt": "Sail Rock location in Co. Donegal", "url": "img/topos/sail-rock/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
221	300	Sydpillaren	publish	0101000020E610000032CB9E04369730400D350A49660A5140	Europe/Oslo	\N	575	13	granite	Slab & Vertical	\N	N	N6-	E1	5b	7	UNSPECIFIED	\N	\N	\N	\N	90	2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Stetind is a huge granite pillar rising 1329 m out of Tysfjord. Voted Norways national Mountain it’s an iconic sight. The South Pilar route or Sydpillaren, offers some challenging climbing, especially towards the top with a couple of N6- graded pitches which roughly equate to HVS/E1. In total it’s a 14 pitch climb that is described as one of Norway’s finest climbs and it’s a classic alpine test piece. Getting down actually requires reversing the Original Route (graded n4),  it will require ropework in sections.	Follow the good path from the parking area up the left side of the stream (initially marked with red paint). This leads through birch forest and eventually out into open country. Ascend through boulders following a discontinuous path - fill  water bottles up here - to a level area on top of the moraine about a 100m above an iceberg filled lake. There is a big flat ‘gearing up’boulder at the saddle.	\N	{"alt": "Stetind Mountain offers incredible multi-pitch", "url": "img/tiles/stetind-mountain.jpg", "atributionURL": "http://www.stetind.nu", "attributionText": "image source"}	{"alt": "The Classic South Pillar climb on Stetind Mountain", "url": "img/topos/stetind/stetind-south-pillar-route-topo.jpg", "dataFile": null, "atributionURL": "http://northernalpine.blogspot.com/2010/08/stetind-sydpillaren-guiding-south.html", "attributionText": "Seth Harry"}	{"alt": "Location of Stetind in Norway", "url": "img/topos/stetind/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
271	246	Cneifion Arete	publish	0101000020E61000006BFE4E498C1410C04AF8BA19E98D4A40	Europe/London	\N	120	4	rhyolite	Slab	SW	BAS	Diff 3a	Diff	3a	\N	G	\N	\N	\N	\N	50	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The Cneifion Arete is an imposing looking ridge sat high on mountainside of Cwm Cneifion, overlooking the lake of Lynn Idwal. Despite its looks, this route is actually at the intersection between scrambling and rock climbing, a sort of gateway into the world of multi-pitch mountaineering. With a few proper climbing moves to get off the ground, a long and easy climb / grade 3 scramble follows. The route takes the right side of the arete (edge) for around 120 meters to the top. From the ground it looks like challenging terrain, but once past the first 20 or so meters, the ridge itself offers big holds and a gentle angle with the ability to rest at more or less any point. That said the exposure is fantastic and the route offers enjoyable moves along the way. Protection is also plentiful and the route happily takes large slings and nuts throughout. The only downside is the routes popularity, which can leave climbing parties queuing and has led to significant polish in places.	<strong>Approach</strong>: Whilst the route can be approached directly as described here, it is common to link onto another multi-pitch climb. Either starting with the original route on the Sub Cneifion Rib or a route on the <a href='/climbs/ordinary-route-on-cwm-idwal/'>Idwal Slabs</a>.<br><br><strong>Direct Approach</strong>: There is free parking in the lay-bys next to Lynn Ogwen (Lake Ogwen). From these bays, walk to Ogwen cottage (which has limited paid parking available). From here, follow the path to the left side of visitor buildings and cafe. Take a right fork towards Lynn Idwal (Lake Idwal). After passing a gate in dry stone wall, the path folks into 3. The left path follows the wall and the right most follows the lake towards the Idwal Slabs. The middle path moves up towards the Sub Cneifion Rib. Either climb a route on the rib (the original is the easiest) and then take the path right at the top, or move around this crag on the right side to join a path right (south) at the top. The path will go to a point below the now clearly visible Cneifion Arete, with a short scramble up some scree needed to reach the base of the climb.<br><br><strong>Sub Cneifion Rib</strong>: This is a logical link up, more or less on the way to the Cneifion Arete. It is described as a 125-meter, 3-star route, graded VDiff. Arguably the route is neither 125m nor worthy of 3 stars. Pitch one is solid climbing, probably at the upper end of what is quite a variable grade. Pitch two has little in the way of climbing. Pitch 3 is walking along a path. Thankfully the final pitch is enjoyable, well protected, VDiff climb up the Arete with a fun move around the corner to reach the arete. There is a photo <a href='/img/topos/cneifion/sub-cenifion-rib-topo.png' target='blank'>topo of the Sub Cneifion Rib here</a>. The <a href='/climbs/ordinary-route-on-cwm-idwal/'>Idwal Slabs</a> therefore, offer a much more enjoyable, if more circuitous, set of climbs to get to the Cneifion arete. <br><br><strong>Descent</strong>: From the top of the route, a path leading north offers wonderful views, with Glyder Fatch and Tryfan to the right (east) and Cwm Idwal and Y Garin to the left (west). Follow this path on flat at first before descending for a while to where there is a rough T junction. The left offers a path then scree slope back down to the approach path which can be reversed to reach Ogwen cottage. The right fork at the T junction offers an alternative path down to Lynn Bochlwyd (the lake on the right). At the north of this lake (its outflow) is a major path back to Ogwen cottage. In both scenarios the decent is longer than the approach.	First climbed in 1905, the Cneifion Arete is sometimes described a grade 3 scramble and sometimes a Diff graded climb. Either way, it is popular, polished, pretty easy to protect and full of character and exposure.<br>\n<strong class="pitch-title">Pitch 1 –<span class="length">20m</span> <span class="pitchGrade brit">Diff</span></strong><br> Starting just right of the base, climb up a short steep wall on good but polished holds. A belay can be created on the small ledge or the next pitch can be done as well in a link up, this would lead to a bigger belay ledge. <br><strong class="pitch-title">Pitch 2 –<span class="length">10m</span> <span class="pitchGrade brit">Diff</span></strong><br>Climb up a short gully, sometimes generously referred to as a chimney, to a larger belay ledge/area. Whilst the slab to the left of the gully is easier, the goal when climbing the Cneifion Arete should be to find harder moves and sections, not easier ones. It's possible to keep going after this short pitch to find a belay higher on the ridge.  <br><strong class="pitch-title">Pitch 3 & 4 (and maybe 5) –<span class="length">100m</span> <span class="pitchGrade brit"></span></strong><br> Follow the ridge to the top, with multiple options for belay as needed. The right side offers more dramatic positions and exposure. The climbing is easy and long slings make the spikes easy to protect. There are some loose parts, but it's not usually a major concern.	{"alt": "The Cneifion Arete is a a classic climb with a dramatic ridge", "url": "img/tiles/cneifion-arete-in-wales.jpg"}	{"alt": "The Cneifion Arete route shown in this topo offers easy multi-picth climbing.", "url": "img/topos/cneifion/cneifion-arete-climb-north-wales.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "Our own image"}	{"alt": "The Cneifion Arete Location in Llanberis, Wales", "url": "img/topos/cneifion/maps/"}	2024-11-17 21:28:45.59+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
248	283	Diedro UBSA	publish	0101000020E6100000CBF78C446804B33F59880E8123514340	Europe/Madrid	\N	250	9	limestone	Slab & Vertical	S	UIAA	V+	HVS	5b	6	PG	\N	\N	\N	\N	20	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	A true classic, Diedro U.B.S.A. is a sustained 250m grade V+ climb or roughly HVS 5b in British grades. As the name suggests the route climbs the corner (dihedral or Diedro in Spanish) all the way up to the big cave high in the cliff, before a short but awkward diagonal abseil to a ledge which is traversed back into another corner, all the way up to a dramatic move out of the higher notch, onto easier ground to the summit of Peñón de Ifach sometimes also spelled Penyal D’Ifac. The route has a bit of everything including overhangs with good holds, delicate slabs with edges, tiny and large pockets, an exposed traverse and of course lots of corner crack climbing with more than one chimney section. Although popular, polished and loose in places this is a classic and memorable climb. All stances are equipped with new bolts (often 4 or 5) and there are a number of bolts on most pitches. A small rack is needed to achieve a proper level of protection on all pitches. The route faces South with sun on it much of the day so don’t forget to bring water and sun cream.	<strong>Approach:</strong><br>Walk right to the end of the pedestrian path on the right side of Peñón de Ifach, passing the helipad marked in yellow. At the end, step over the wall and move right very briefly before the path cuts back left and moves under the cliff all the way to the start of the climb.<br><br><strong>Descent:</strong><br>Follow the circuitous tourist path marked with large red dots. The path is very polished and slippery, so wearing good approach footwear is recommended. The red dots and path are next to the final belay, these dots are followed all the way back through the cave to the tourist center and back into Calpe for a well deserved drink and probably some after sun.	<strong class="pitch-title">Pitch 1 – <span class="length">15m</span> <span class="pitchGrade uiaa">Grade III</span></strong><br>  Climb up to a large ledge with a bolted anchor below and a little left of the first corner. <br> <strong class="pitch-title">Pitch 2 – <span class="length">40m</span> <span class="pitchGrade uiaa">GradeV+</span></strong><br>  A contender for the routes’ crux, the pitch starts with a delicate traverse across the sloping ledge, before reaching the corner. From here a long, steep and sustained climb is made to the next anchor on a ledge below the chimney. <br> <strong class="pitch-title">Pitch 3 – <span class="length">25m</span> <span class="pitchGrade uiaa">Grade V+</span></strong><br>  Some tricky moves are made off the belay up and rightwards to reach the corner, this is climbed to the next belay. The newer Spanish guidebook "Escaladas en Alacant" suggests the start of this pitch is the crux of the climb at 6b but other good guides leave it at V+. The bolts relive some of the pressure from the moves. <br> <strong class="pitch-title">Pitch 4 – <span class="length">25m</span> <span class="pitchGrade uiaa">Grade V+</span></strong><br>  Move up from the belay for another pitch of corner climbing.  <br> <strong class="pitch-title">Pitch 5 – <span class="length">30m</span> <span class="pitchGrade uiaa">Grade V</span></strong><br> Some delicate moves are made first going right from the belay a little, then back left into the chimney system. This is climbed to a cave with two bolts. From here ascend up onto the ledge above, moving left and up, around the block, to reach a belay on a wedged block with a broad slab behind.  <br> <strong class="pitch-title">Pitch 6 – <span class="length">30m</span> <span class="pitchGrade uiaa">Grade V+</span></strong><br> Another contender for the route's crux. The pitch requires some harder moves onto the wall above the anchor bolts. After this the route moves up this wall on smaller but positive holds trending right. The pitch has two options. Some (sport 6a) moves, ascend more directly and a slightly easier path (UIAA V) moves right into a corner (using a small pocket) before ascending to the ledge of the cave and walking back left. 2 bolts and 2 abseil rings are positioned on the bottom left hand side of the large cave.  <br> <strong class="pitch-title">Pitch 7 – <span class="length">8m</span> <span class="pitchGrade uiaa">Abseil</span></strong><br>  Abseil ~8m diagonally down and left (when facing the anchor) with difficulty to reach some bolts. There are two sets. Don't move to the further set straight away because pulling the rope around the corner will be more difficult.  <br> <strong class="pitch-title">Pitch 8 – <span class="length">40m</span> <span class="pitchGrade uiaa">Grade V</span></strong><br> This pitch makes a delicate exposed traverse all the way into the corner before moving up the corner crack and then slightly left at the large foliage to reach a pair of bolts for a half hanging anchor (there is a good ledge for at least one foot).  <br> <strong class="pitch-title">Pitch 9 – <span class="length">45m</span> <span class="pitchGrade uiaa">Grade V+</span></strong><br> Another contender for the route's crux. The pitch traverses back right to the corner, moving up the ever steepening corner until the overhanging notch has to be tackled directly to form a dramatic finale and gain freedom from Diedro U.B.S.A.. From here a belay can be made on the bolts to the right or an additional ~30 meters of easy scrambling can be made to reach some bolts by the summit path.	{"alt": "Peñón de Ifach rising out of the costline of Costa Blanca offers great climbing", "url": "img/tiles/penon-costa-blanca.jpg", "atributionURL": "https://commons.wikimedia.org/wiki/File:Pe%C3%B1%C3%B3n_de_Ifach,_Calpe,_Espa%C3%B1a,_2014-07-01,_DD_13.JPG", "attributionText": "img source"}	{"alt": "Diedro UBSA topo on the south face of Penon Ifach, Calpe", "url": "img/topos/penon/diedro-ubsa-topos-hvs-climb-on-penon-ifach-calpe.jpg", "dataFile": null, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "Our own image"}	{"alt": "Costa Blanca climbing location", "url": "img/topos/penon/maps/"}	2025-02-15 13:33:05.952+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
272	282	Dos Hermanos	publish	0101000020E61000000A2CF1CEFF52C7BFD50A91DB48514340	Europe/Madrid	\N	205	7	limestone	Slab & Vertical	NE	BAS	V	VS	5a	5	PG	\N	\N	\N	\N	45	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	A unique mountain adventure that can be described as both incredible and, in places harrowing. Set deep in the mountains of Costa Blanca around the cliffs of Pen y Roc, the Two Brothers climb or Dos Hermanos offer solitude and isolation away from the busy classic routes on Penon Ifatch and Puig Campania. There are breathtaking views over stunning mountain scenery, looking out to the sea, with varied and interesting climbing. The route itself climbs two isolated towers, with the option of adding a wild tyrolean traverse and an additional 100m of scrambling up a ridge to the summit of la Capella. The full link up was first climbed by Roland Edwards in 2003. Edwards has put up numerous first accents in the area. The description states: 'This route must rate as one of the best, at its grade, in the area for mountain rock climbing.' It has all the hallmarks of an amazing adventure, but  it's let down by the first tower being a bit overgrown (in 2025) and the second tower having considerable loose rock. Negatives aside the route offers some fantastic moves with many pitches at or close to VS in grade. There are slabs, aretes, cracks and even some steep climbing on good handholds. For an experienced party it offers an adventure in a wonderful isolated setting.	<strong>Approach:</strong><br />There are two main ways to approach this.<br /><em>Option 1</em>: A long walk can be made from climbing area in the Echo Valley. The original guide (linked below) describes this.<br /><em>Option 2</em>. This has less walking and drives around a single track pass (gravel only in places) at the back of the mountains. Parking can be found near the notch between the mountains at <a href='https://maps.app.goo.gl/zxACqepphBtLR1KG7' target='blank'>38.64120185, -0.18481217192</a>. From the parking walk down to reach the hiking trail around <a href='https://maps.app.goo.gl/1zugRBXBKMPx2GEd9' target='blank'>38.646661705, -0.1857902219</a>. If driving from the north it may be better to park lower down and walk up. From the hiking trail a ~30 min walk can be made to the climb. The hiking path is followed until a large open junction is found. The obvious right path is taken until underneath the cliffs with the climb clearly visible. From here, cut off the path and follow the scree to the base of the first tower where the route starts behind a large boulder. The first tower could be skipped (the second has better climbing). Stick to the scree and rock as the local flora is positively hostile.<br /><br /><strong>Decent:</strong><br />From the top of the second tower make a 35m abseil back to the ground (see note below regarding quality Abseil points), scramble back down the gully on the scree to the hiking path.	Consider carefully before attempting this route. <em>Do not use any information in this site to plan, attempt, or climb a particular route unless you are willing to assume personal responsibility for all risks associated</em>. <br /><br /><strong>Abseil points:</strong><br />The abseil on the first tower is a large single ring showing its age in Feb 2025. It could likely be backed up by bringing (and leaving) a meter or so of cord and a maillon on a nearby spike. (Or a new bolt added for those with the skill). The second tower abseil has one good bolt, attached via old cord to an old rusted bolt (and what looks like a home made aluminium hanger) with a partially rusted maillon. Replacing the old rope cord and abseiling off a new maillon on the newer bolt might be a better option. The state of the tyrolean traverse spike can't be accessed in any detail from the other tower. <a href="/img/topos/penya-roc/abseil-station-on-second-tower-two-brothers-climb.jpg" onclick="openLightBox('/img/topos/penya-roc/abseil-station-on-second-tower-two-brothers-climb.jpg','The summit of second tower showing views and in-situ gear.');return false">Photo from the summit of second tower showing views and in-situ gear.</a><br /><br /><strong>Protection:</strong><br />Consider this a full trad route. The natural protection is mostly very good with a full rack.<br /><br /><strong>Loose rock:</strong><br />The second tower has a lot of loose rock, more so than 'normal' loose mountain routes. Especially true if slightly off route. The smaller of the rocks hurt when they hit you. It's fair to assume larger loose rocks, of which there are plenty, would be life threatening, to the point it would be worth leaving at least a couple of pitches gap in the unlikely event there was a party climbing above. Helmets are a must.<br /><br /><strong class="pitch-title">Pitch 1, Tower 1 – <span class="length">20m</span> <span class="pitchGrade uiaa">Grade V</span></strong><br />Climb the slab into a niche with a piton & ring. From here make hard moves (possibly easier without vegetation) through the bulge before trending right to a single bolt, where a belay can be built.<br /><strong class="pitch-title">Pitch 2, Tower 1 – <span class="length">20m</span> <span class="pitchGrade uiaa">Grade V</span></strong><br />Climb to the next ledge (thread), then tackle the obvious groove before moving right to the arete and up to a good ledge with a bolt, where a belay can be made.<br /><strong class="pitch-title">Pitch 3, Tower 1 – <span class="length">30m</span> <span class="pitchGrade uiaa">Grade IV</span></strong><br />Move up onto a block to the left of the belay, traverse left a little before climbing a steep wall up to a ledge with a lot of vegetation (small trees as of 2025). Pass the trees on the right side, to reach the start of the pinnacle. The pinnacle is passed on the right side to reach a large single bolt with an abseil ring (see note above).<br /><br /><strong>Abseil:</strong> around 30m back to ground level.<br /><br />Scramble up to the next tower. The scree path on the right offers easy access to the base of the tower, where a path left leads to the start of the arete of the first pitch up the second tower.<br /><strong class="pitch-title">Pitch 4, Tower 2 P1. – <span class="length">35m</span> <span class="pitchGrade uiaa">Grade IV</span></strong><br />This pitch climbs the ridge/arete proper up to a good ledge. The  easier looking holds right of the arete are loose. From the ledge move to the left a few meters before climbing the steep wall just around the corner using good hand holds (jugs). Build a belay around the old peg.<br /><strong class="pitch-title">Pitch 5, Tower 2 P2. – <span class="length">40m</span> <span class="pitchGrade uiaa">Grade IV+</span></strong><br />Arguably the best pitch on the climb, it tackles 4 short walls each offering magnificent moves. The first is steep but with good holds and the last is a more delicate affair, but on a slightly less steep wall. A belay can be made at the base of the obvious pinnacle.<br /><strong class="pitch-title">Pitch6, Tower 2 P3. – <span class="length">20m</span> <span class="pitchGrade uiaa">Grade II</span></strong><br />Scramble along the ridge to the base of the next tower.<br /><strong class="pitch-title">Pitch 7, Tower 2 P4. – <span class="length">40m</span> <span class="pitchGrade uiaa">Grade V-</span></strong><br />Climb onto the sloping ledge and then either: a) tackle the steep (and loose) blocks above the belay, or b) make a long and awkward reach around the corner left before moving up a narrow slab. After either of these options, the pitch eases and ascends via groves and ledges to the abseil point.<br /> <br />From here an abseil of 35m can be made back to ground level. The more adventurous original guide (linked below) suggests throwing a rope to lasso the spike on the opposite tower, and creating a tyrolean traverse. After which a 25m abseil to the left can be made and a 100m grade III scramble can be done up to the summit of La Capella. Given the state of much of the fixed gear in Feb 2025, skipping this seems the safer option.	{"alt": "The Two Brothers Climb or Dos Hermanos in Costa Blanca", "url": "img/tiles/two-brothers-climb-dos-hermanos-costa-blanca.jpg"}	{"alt": "Topo for Two Brothers Climb, Dos Hermanos near Penya Roc", "url": "img/topos/penya-roc/two-brothers-climb-dos-hermanos-topo-penya-roc.jpg", "atributionURL": "https://creativecommons.org/licenses/by/4.0/", "attributionText": "our own image"}	{"alt": "Costa Blanca Two Brothers Climb location", "url": "img/topos/penya-roc/maps/"}	2025-02-11 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
274	237	The Sheugh	publish	0101000020E61000008C9BFF96E0EA17C03A1753A413144B40	Europe/London	\N	71	3	granite	Vertical	SE	BAS	Severe	S	3c	3	PG	\N	\N	\N	\N	75	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The Sheugh, pronounced shuck, is the only climb in the Mourne Mountains guidebook to be given 4 stars. The route has a fearsome reputation, described in  the guidebook as being on the humorous side of character building. It was first climbed in 1954, and is full of old school climbing moves including quite a lot of whole body chimney jamming. It offers a unique adventure, with quality climbing almost all the way, with just a few caveats. Firstly it needs an extended dry period, no easy ask in the Mournes, or the route will be wet and considerably harder. Protection is mostly okay with a full rack, but you will need a head torch to help find placements. The rock is also mossy and slightly crumbly in places. It’s fair to assume the 4th star acts as a kind of Siren call, to draw in unsuspecting climbers, who may well end up stuck on the rocks. It is nevertheless a very worthwhile route when in condition, offering a truly unique adventure in an amazing atmosphere that would be hard to find anywhere else. The Sheugh is a memorable climb though the central chimney of Buzzards Roost. Sheugh means a furrow, but can be colloquially used (as it is here) to mean the space between the buttocks. Buzzards Roost is named after the shape of the rock formation as seen in the image below.	<strong>Approach</strong>: Park in the Carrick Little top car park (£3 in 2025). There is a small free car park on the corner as you turn onto the gravel road about half a mile before the paid one, this will add 12 mins walk each way.  From the top car park, take the path North into the Mourne Mountains. Follow the path past the Annalong woods on the right, then past the small lake called Blue lough on the right and Buzzards Roost should be visible on the hillside to the left. At an appropriate point cross directly towards Buzzards Roost and hike up to the crag. The ground is boggy when off the path. It's best to leave the bags a little further back from the crag to save some time on the descent. <br><br><strong>Descent</strong>: To descend from the crag, walk South towards Sleive Binnian before scrambling down the steep gully (grass and rock etc) until you reach your bags, likely in front of Buzzards Roost. From here reverse the approach by walking to and following the path back to the carpark. 	This is a unique adventure climbing though the dark, often dank, depths of Buzzards Roost crag in the Mourne Mountains. The climber's back will get almost as much use as the hands on the first pitch, so removing rucksacks and gear from the back of the harness will make life easier. A head torch will help find holds and in particular gear placements on pitch 1 and 2. <br><br> <strong class='pitch-title'>Pitch 1 –<span class='length'>28m</span> <span class='pitchGrade bas'>3c</span></strong>:<br>Move into the chimney and onto the first obvious chockstone (wedged block). From this, move up and deeper onto the next chockstone, with some difficulty. From here the route moves up and slightly left, before moving back towards the entrance; up and right, onto another group of wedged blocks (some loose). The belay is above these on an obvious large slanting wedged block. See <a href='/img/topos/buzzards/the-shuck-belay-position.jpg' onclick="openLightBox('/img/topos/buzzards/the-shuck-belay-position.jpg','Belay Position at the end of pitch one.');return false">picture of first belay ledge, taken from the second</a>.<br><br><strong>VS Variation</strong>: It's possible to climb up directly from the end of pitch one to the top of the crag at the harder grade of very severe. <br><br> <strong class='pitch-title'>Pitch 2 –<span class='length'>25m</span> <span class='pitchGrade bas'>3c</span></strong>:<br>Make an improbable looking traverse horizontally back into the depths of Buzzards Roost to the next ledge system. A head torch may make finding protection easier. There are cracks on both the left and right walls in places.<br><br> <strong class='pitch-title'>Pitch 3 –<span class='length'>18m</span> <span class='pitchGrade bas'>3c</span></strong>:<br> Move to the back of the ledge and climb a short grove on the right wall (when facing into the chimney) before traversing up and right across a mossy bulge. From here move up and then turn onto the other wall where a long reach to a jug will give access to a ledge followed by a grassy slope against the rock, which leads to the summit. Large boulders further back can be used to build the anchor.	{"alt": "Buzzards Roost Crag in the Mournes", "url": "img/tiles/buzzards-roost-crag-mournes.jpg"}	{"alt": "The Sheugh on Buzzards Roost in the mournes", "url": "img/topos/buzzards/the-sheugh-climb-on-buzzards-roost.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "our own image"}	{"alt": "Buzzards Roost in the Mourne Mountains", "url": "img/topos/buzzards/maps/"}	2025-05-30 13:26:01.356+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
218	242	Pegasus	publish	0101000020E61000009372F7393EBA16C09CA6CF0EB8044940	Europe/London	\N	70	3	granite	Slab & Vertical	SW	BAS	HS 4b	HS	4b	4	UNSPECIFIED	\N	\N	\N	\N	25	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Chair Ladder is an incredible sea cliff crag near the village of Porthgwarra in Cornwall. The local name in Cornish is <em>Toll Pedn Pennwydh</em> meaning the <em>holed head of Penwith</em>. The English name for the area is now Gwennap Head. The cliffs offer an exceptional range of climbing from the easier end of the scale, going up to E3 for those looking for more of a challenge. Pegasus is one of the longer lines and sits at the Bulging Wall end of the crag. The route uses the corner crack at the start to ascend to the first belay, then weaves right to a belay in the corner, before going back left to the top. However there are multiple options for variation. There are also a variety of other lines on the crag that are 50m+ and range from VDiff to E3. South Face Direct is highly recommended.	<strong>Approach</strong>: There is paid parking in Porthgwarra by the café and sea cove. From there a path that leads past the cottages to the coastguard lookout which is directly above the sea cliff. There is an option to abseil in on the east side of the crag. Alternatively or you can scramble down via the west side of Zwarn Rinny (Furthers side from the lookout). This scramble down is not for the faint of heart and can be tricky to find the best way from above. The scrabble approach should be avoided at high tide. In the event you try to go down the east side (closes to the lookout) you will come to a significant drop off that can’t / shouldn’t be down climbed. You can however set up an abseil around a block on this side to access the tidal ledge.	Pegasus on Chair Ladder takes an incredible line up the bulging wall end of the cliff. The first two pitches offer exceptional climbing on the granite and the last pitch starts with the crux which is an awkward move onto a small ledge, at which point the exceptional granite climbing resumes. \n<br>\n<strong class="pitch-title">Pitch 1 –<span class="length">32m</span> <span class="pitchGrade brit">4b</span></strong><br>\nClimb the wide and obvious crack to the top. The climber can choose their preferred style including layback, crack climbing or bridging. At the top of the crack move up and slightly right to reach a good ledge and belay. \n<br>\n\n<strong class="pitch-title">Pitch 2 –<span class="length">20m</span> <span class="pitchGrade brit">4a</span></strong><br>\nMove out right from the stance and then follow the corner and striking obvious swooping crack that leads up then right. Once the crack ends, follow the ledge all the way to the end. The climber can create a belay there or step over a small crevasse to create a belay on the opposite ledge which has different options for an anchor. <br>\n\n<strong class="pitch-title">Pitch 3 –<span class="length">18m</span> <span class="pitchGrade brit">4b</span></strong><br>\nMove back left, reversing the last few meters of pitch two. Then make some steep awkward moves up onto a small ledge. Move left on this and up to another ledge with a slab and a crack that sweeps up and right. This leads to large ledge where a belay can be created before the final walk off.	{"alt": "Chair Ladder Crag", "url": "img/tiles/chair-ladder-climbing.jpg", "atributionURL": "http://www.cornishcamping.co.uk/photographs/cornish-seascapes/", "attributionText": "img: Cornish Camping"}	{"alt": "Chair Ladder Climbing Route Topo for Pegasus", "url": "img/topos/chair/chair-ladder-climbing-topo-for-pegasus.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "Our own image"}	{"alt": "Chair Ladder Location in Cornwall", "url": "img/topos/chair/maps/"}	2021-10-15 01:01:45.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
275	304	Cnoc Na Mara	publish	0101000020E6100000FF058200196221C01A34F44F70614B40	Europe/London	\N	152	4	quartzite	Slab	E	BAS	VS 4b	VS	4b	5	R	\N	\N	\N	\N	90	3	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Whilst it might seem like an amenable grade and reasonable length, this is a serious adventure on rock that is loose in places with limited reliable protection in places. Expect a long day our for this adventure! The route takes the landward facing ridge to the summit. You will need a small boat or canoe to get to the base and ideally a very calm sea in order to make a reasonably safe crossing. Expect a complicated descent requiring some down climbing and abseiling.	Drive the 22 kilometre c class laneway from Ardara to the road end at An Port, the gateway to Irelands last great wilderness. Fom here on foot, follow the clifftop path for approx 2 kilometre to an outstanding viewpoint overlooking Glenlough Bay, Irelands largest raised shingle storm beach. From this viewpoint descend the very steep grass/scree slope for 200 or so metres and abseil from the two peg belay to the Entrance to Shambala storm beach. From the beach it is a 125 meter sea passage to the base of the stack.	\N	{"alt": "Cnoc Na Mara Sea Stack", "url": "img/tiles/cnoc-na-mara-donegal.jpg", "atributionURL": "https://uniqueascent.ie/cnoc_na_mara", "attributionText": null}	{"alt": "Cnoc Na Mara Route Topography", "url": "img/topos/cnoc/cnoc-na-mara-route-topo.jpg", "dataFile": null, "atributionURL": "https://uniqueascent.ie/cnoc_na_mara", "attributionText": "Credit Iain Miller"}	{"alt": "Map showing the location of the Tormore Sea Stacks", "url": "img/topos/cnoc/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
282	247	Ordinary Route	publish	0101000020E6100000D1798D5DA21A10C0359886E1238E4A40	Europe/London	\N	140	4	rhyolite	Slab	NW	BAS	D 3a	D	3a	1	UNSPECIFIED	\N	\N	\N	\N	30	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The Ordinary Route is the easiest route on Idwal Slabs or Rhiwiau Caws as is the propper Welsh name. This climb represents an ideal introduction to trad multi-pitch climbing, as such it's common to see groups of 3 people climbing, led by a guide. The descent can prove tricky, especially in or after wet conditions.The down climbing part of the descent is on a shaded corner of the mountain so typically won't dry as quickly as the slabs. Expect some polish on the route as well. The views are stunning and get better as the route progresses. The route is typically climbed over 4 pitches with more scrambling after the 4th pitch. Route finding higher on the slabs can be a little tricky. It's fair to say stamina is more important than any great technical climbing skill to get up the Ordinary Route.	<strong>Approach</strong>: Take the main path from Ogwen Cottage to Llyn Idwal and continue around the left-hand side of the lake towards the slabs which are straight ahead of you. Any attempt at a shortcut off the path will likely slow you down.<br><br><strong>Descent</strong>: Getting off the mountain can prove tricky. From the last pitch, scramble across the crag moving up and left, consider staying roped if with beginners. As the party moves back there is the option to down-climb or abseil off the back corner of the cliff. This section is steeper than the climbing on the route albeit with better holds and much shorter. Less confident parties may wish to abseil or get a belay from above while down climbing. Once the steep part has been navigated the scree path will take climbers back to the base of the Idwal Slabs. <br>	First climbed in 1897 the Ordinary Route is the easiest climb up the Idwal slabs. That said the route Hope is not much more challenging (and a better climb). The Ordinary Route offers a good introduction to multi-pitch climbing, and as such it's often a busy climb and used by guides quite a lot. Unless it’s raining the slabs at Cwm Idwal can be busy. Climbers can ascend this route in bad weather if they are brave.\n<br>\n<strong class="pitch-title">Pitch 1 –<span class="length">45m</span> <span class="pitchGrade brit"></span></strong><br>\nFollow the obvious crack to a wedged block and either belay there or on a better ledge above. \n<br>\n<strong class="pitch-title">Pitch 2 –<span class="length">45m</span> <span class="pitchGrade brit"></span></strong><br>\nAfter the belay, take the left hand grove working up and left slightly before following a long rightwards leaning line of weakness up to some ledges where another belay can be made. \n<br>\n<strong class="pitch-title">Pitch 3 –<span class="length">25m</span> <span class="pitchGrade brit"></span></strong><br>\nFollow the crack up towards a ledge, the route becomes much less clear here with multiple options for creating an anchor. Ideally take the easiest climbing.\n<br>\n<strong class="pitch-title">Pitch 4 –<span class="length">25m</span> <span class="pitchGrade brit"></span></strong><br>\nThe final official pitch goes left for about 8m then up and right towards a much larger ledge system. A shorter, slightly harder and more direct line can be taken. After this there is a reasonable amount of scrambling left and then up to get to the downclimb or abseil. Instead of the scramble, climbers can continue up on the harder continuation wall. This will add more length to this route at a higher grade. Lazarus to the far right is the easiest and arguably best way up if you want to continue with harder climbing.	{"alt": "The bowl of Cwm Idwal", "url": "img/tiles/cwm-idwal-slabs.jpg", "atributionURL": "https://climbmountains.wordpress.com/2010/06/10/new-ogwen-climbing-guidebook-out-now/", "attributionText": "Climb Mountains"}	{"alt": "Idwal Slabs offers easy multi-picth climbing. This is the route topo.", "url": "img/topos/idwal/idwal-slabs-multi-pitch-climbing-ordinary-route-topo.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "Our own image"}	{"alt": "Map showing Cwm Idwal in Wales", "url": "img/topos/idwal/maps/"}	2021-10-18 01:01:44.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
258	259	Normal Route	publish	0101000020E6100000C66E9F55668227406571FF91E94C4740	Europe/Rome	\N	720	19	dolomite	\N	S	UIAA	IV-	VD	3b	2	UNSPECIFIED	\N	\N	\N	\N	60	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Grande Fermeda via the original route is a very long climb but at an amenable grade. There is only one pitch (pitch 15) that is graded UIAA IV-. This means around 700 meters of grade II and grade III climbing. As such it’s common for parties to scramble while roped together, pitching only the harder sections. Techniques like simul climbing or scrambling allow parties to move much faster, reducing the risk of benightment, but increasing the type and impact of potential falls. Plan according to the parties strengths & weaknesses. The route was first climbed in 1887 by a party of climbers Bettega, Compton, Martin, Schulz. Parts of the climb are delicate, exposed and in places quite steep.	<strong>Approach</strong>: Approaches start in Val Gardena Many parties will go to the Fermeda Hütte or the nearby Rifugio Firenze in Cisles, which can be reached from the Col Raiser (chair-lift from St. Christina). From the huts follow the path to the Mittags-Scharte / Sass Rigais (marked) until you can reach the base of the Grosse/Gran Fermeda easily. From there it's a short walk to the beginning of the different routes.  <br />\r\nAn excellent approach for doing the climbs in one day is to take the Furnes - Seceda lift from St. Ulrich.\r\n</p><p>\r\n<strong>Descent A</strong>: The way down requires the climbers to revers the entire normal route, abseiling the harder sections. First climb down to the belay at the top of pitch 15, then make a short abseil past the 20m crux of the route. Keep descending to just below the short chimney of pitch 7, for here descend directly below the bolt to an anchor. Make a 25m abseil into the initial gully. Make a final 25m abseil down the gully then continue scrambling down the easier sections of the route to the base. <br /><br />\r\n<strong>Descent B</strong>: The alternative way down does more abseiling and less scrambling. Start by reversing the route to the saddle below the summit (~2 pitches), this is where the normal route joins the Southeast Ridge route. From this abseil station you can make 9 abseils of 20 to 25m each. Less if you have a 60m rope and skip stations. These go down the Northe East side of Grande Fermeda towards Odla de Cidles. From here decend the gully rightwards to a large chockstone, and make a 30m abseil (or a 10m and 20m abseil if using a single rope) move right and make one final 40m abseil (again 15m and 25m if using single ropes). This brings climbers to the base.	\N	{"alt": "multi-pitch rock climbing on Grende Fermeda in the Alps", "url": "img/tiles/multi-pitch-climbing-on-grende-fermeda-in-the-alpes.jpg", "atributionURL": "https://www.summitpost.org/alpe-di-cisles-walls-line-up/916260/c-781834", "attributionText": "Silvia Mazzani"}	{"alt": "grande fermeda via normal route in the Alps", "url": "img/topos/fermeda/grande-fermeda-via-normal-route-alpine-climbing.jpg", "dataFile": 5, "atributionURL": "https://commons.wikimedia.org/wiki/File:Fermeda.JPG", "attributionText": "original: Svíčková"}	{"alt": "Location of Grand Fermeda in the Alps", "url": "img/topos/fermeda/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
284	274	Queles	publish	0101000020E61000003C122F4FE77220C0433D7D04FEFC4440	Europe/Lisbon	\N	60	2	granite	Vertical	SE	UIAA	VI+ (f6b)	E1	5c	7	UNSPECIFIED	\N	\N	\N	\N	10	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Meadinha is a dome of granite in North Portugal which makes for some brilliant pitches if you can handle the high technical grade! The route Queles is on the left side an is half trad climbing and half sport route.  The line is only 60m long, but the crag has some routes up to 200m. The other routes are either pure sport line or have challenging sport or aid sections with a little easy trad in them. Check out meadinha.com for more information if you fancy your hand at some of the more challenging parts of the cliff.	Park in the nearby village of Peneda and Meadinha should be clearly visible a short walk up the hill.	\N	{"alt": "The Granite dome of Meadinha", "url": "img/tiles/meadinha-in-portugal.jpg", "atributionURL": "http://chinelodemeterodedo.com/escalada-classica-no-parque-nacional-da-peneda-geres-meadinha/", "attributionText": "img source"}	{"alt": "Topo for Queles on Meadinha in Portugal", "url": "img/topos/meadinha/meadina-topo-for-queles.jpg", "dataFile": null, "atributionURL": "https://www.allaboutportugal.pt/pt/arcos-de-valdevez/jardins/miradouro-do-penedo-da-meadinha", "attributionText": "all about Portugal"}	{"alt": "Location of Meadinha in North Portugal", "url": "img/topos/meadinha/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
253	241	Mendez and Guillermo	publish	0101000020E61000008F0FA0466DA230C0FC024BF937393C40	Atlantic/Canary	\N	115	3	basalt	\N	E	UIAA	V+	VS	4c	5	UNSPECIFIED	\N	\N	\N	\N	15	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	El Catedral, (the Cathedral in English) is a volcanic plug that stands in Teide National Park in the centre of Tenerife. It offers a variety of traditional multi-pitch climbs that tend to be around 3 or 4 pitches in length to reach that summit via just over 100 meters of climbing. Whilst Tenerife has a lot of incredible climbing the majority of it is single pitch sport routes. El Catedral offers some of the best traditional multi-pitch climbing on the island. The route Via Mendez & Guillermo is not the original route up the face but offers a high quality adventure at grade UIAA V+. Whilst a completely different grading system it sits around VS. There are easier and harder options to the summit if needed. The original route is graded UIAA IV or around Severe in British grades. The setting of this rock is near the middle of the the island in the national park across the road from where the cable car takes tourists to the summit of El Teide. El Teide is Spain's highest mountain. The area is popular with tourists who, understandably, visit to see the majestic scenery of the area. There are very occasionally access restrictions in the area for goat hunting. See references below to check the schedule.	<strong>Approach</strong>: There is limited parking at Parador del Teide which is a short walk away from this climb. Alternatively, there are coach services up to Parador del Teide in the national park. Cathedral rock, is southwest of the Roques de García. Follow the obvious path down to the rock and then move right around the base to the start of the climb or take the right fork in the path earlier and scramble up to the start. <br> <br>\n<strong>Descent</strong>: From the summit, abseil roughly 30m down to a pair of bolts with one ring (the end of pitch 3 on via normal). From here a scramble is made down to the large gravely plateau, before the lesser South West peak. Move down this plateau (towards the walk in) for around 10 or so meters. It should never be hard scrambling or very near the edge. Due to the loose rock, staying roped up is safest, it's easy to stay roped all the way to the final abseil station, where it's possible to pull the ropes from the previous anchor. The final abseil is from a pair of bolts with an abseil ring on the south face. This is after a few short ledges. From this point an abseil of around 40 meters can be made to the ground, not far from the start of the original normal route. See route topo above.	The route gets shade in the afternoon for most / all of the route. The Mendez and Guillermo route is harder than the original and reasonably consistent in grade, with a hard move out of the gully on pitch 3 near the end. <br><strong class="pitch-title">Pitch 1 –<span class="length">35m</span> <span class="pitchGrade uiaa">IV+</span></strong> The first pitch described here may differ from the original, (due to not having a description of the original) but it went at around grade IV+. Climb up the right side of the triangular pinnacle that attaches to cathedral rock on the east face. The route stays roughly in the middle of the face between the corner on the right and the arête/ edge on the left. Climb up to a small niche in the rock between the left arête and now wider corner / gully on the right. From the niche, move right towards the gully, and climb the back of the pinnacle to emerge on top of it. Climb over the high point to create a belay between the pinnacle and the main wall which has a large single bolt. <br><strong class="pitch-title">Pitch 2 –<span class="length">45m</span> <span class="pitchGrade uiaa">IV+</span></strong> Make an exposed traverse across to a bolt and then carry on to the large block (bolt below & behind) and pass this onto easier ground. From here move rightwards, to eventually tackle a somewhat tricky bulge in the rock (not the vegetated one on the very far right). From this move up and right to create an anchor below the right most of the two deeper grooves. <br><strong class="pitch-title">Pitch 3 –<span class="length">35m</span> <span class="pitchGrade uiaa">V+</span></strong> A beautiful crux pitch. Climbing directly through the offwidth crack / gull, generally using good, but sometimes hard to find hand holds. The rock for footholds on the right wall appears friable / crumbly in places so care should be taken. At the end of the gully / crack, move up to the small finger width crack and step out onto the right wall (Likely the crux if you don't use the little friable footholds), climb the right wall to a large flat fin / spike of rock. Move past this and back left to the anchor on the top.	{"alt": "Cathederal Rock in Tenerife offers great climbing", "url": "img/tiles/cathederal-rock-tenerife.jpg"}	{"alt": "Trad Climbing lines on Cathederal Rock in Tenerife", "url": "img/topos/tenerife/cathedral-rock-trad-multi-pitch-tenerife.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "Our own image"}	{"alt": "Catherderal Rock Climbing in the national park Tenerife", "geo": "28.22330240374,-16.63442617251", "url": "img/topos/tenerife/maps/"}	2025-07-10 01:01:59.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
276	285	Virgo	publish	0101000020E610000030F72E67594018C08C0511EB85124B40	Europe/London	\N	90	4	granite	Vertical	E	BAS	VS 4c	VS	4c	5	PG	\N	\N	\N	\N	15	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Virgo is a brilliant 3 star Mourne multi-pitch classic. It has a short walk in and offers varied but quite consistent climbing at around VS grade all the way. There are some technical moves early on and some steep climbing on the last pitch. It has decent belay ledges at all points. Protection is mostly very good, with a slightly runout rising traverse in the middle on Pitch 3 (as described below). Pigeon Rock is a popular destination by Moune standards, but the route doesn't get much traffic in absolute terms so can need cleaning. Descent is by crossing a fence and walking off steeply to the south / left side of the crag (when facing it from below). Overall a very worthwhile route.	<strong>Approach</strong>: Park in the Pigeon rock car park behind a farm gate (make sure to close it). Then walk up and left, skirting the left side of the boulder field. The route starts on a ledge at the base of an obvious vertical crack. <br /><br /><strong>Descent</strong>:Descent is by crossing a wire fence and walking off steeply to the south / left side of the crag (when facing it from below). This is particularly steep so care should be taken. An abseil descent is also possible but the abseil points (boulders / spikes with tat) likely need re-equipping. 	Virgo is a brilliant route and the line and pitches described here are how it is commonly ascended, but it would be possible to connect pitch one and two here as per the Mourne mountain guidebook, but this can lead to rope drag.<br><strong class="pitch-title">Pitch 1 –<span class="length">10m</span> <span class="pitchGrade brit">4a</span></strong>: From the starting ledge climb up to a crack to reach a large triangular block. Climb directly over this to create a belay just behind.<br><strong class="pitch-title">Pitch 2 –<span class="length">20m</span> <span class="pitchGrade brit">4c</span></strong>: Climb directly above the belay to a good ledge under a slightly bulging rock / overhang. Pass under this to the left, then move diagonally up and left before eventually mantling onto a decent long ledge. A belay can be made on the far left side (wedged wire at the time of writing). <br><strong class="pitch-title">Pitch 3 –<span class="length">30m</span> <span class="pitchGrade brit">4b</span></strong>:  An exposed pitch with less strenuous, but still technical climbing. The pitch has little gear in the middle. The route goes up from the belay to the break (gear placement), before traversing right on small ledges with good footholds and acceptable handholds but no gear. The route then moves up the ledge system, back to the corner above and onto the grassy ledge. Move up this and belay below the corner of the final pitch. <br><strong class="pitch-title">Pitch 4 –<span class="length">30m</span> <span class="pitchGrade brit">4c</span></strong>:Climb directly up this corner. Pass the first small block staying in the corner and keep moving up. Move onto the ledge to the left and under the large overhanging block / nose. Another ledge then takes climbers to the end of the technical difficulty where a long low crack line leads left. Follow this and move around it back right to belay above the corner (see topo).	{"alt": "Pigeon Rock Crag in the Mournes", "url": "img/tiles/pigeon-rock-virgo.jpg"}	{"alt": "Virgo route topo on Pigeon Rock in the mournes", "url": "img/topos/pigeon/virgo-climb-on-pigeon-rock-mournes.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "our own image"}	{"alt": "Pigeon Rock Crag in the Mourne Mountains", "url": "img/topos/pigeon/maps/"}	2025-04-30 13:26:01.356+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
263	272	Donkey Serenades	publish	0101000020E6100000C5FEB27BF22022C057957D5704CF3D40	Africa/Casablanca	\N	270	8	quartzite	Slab	NE	BAS	HS 4b	VD	3c	2	UNSPECIFIED	\N	\N	\N	\N	15	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The Lower Eagle Crag in the Jebel El Kest mountain range offers some of the best rock climbing in the anti-atlas. The rock climbing is clean and the quartzite is generally very solid. Many routes ascend to around 300m with grades starting from V. Diff, like this classic route, Donkey Serenades. Pink Lady and Real Men wear Pink are nearby <abbr title="Very Severe">VS</abbr> climbs. Sir Chris Bonington’s climb, Black Beauty offers an exceptional E1 climb further down the crag. Routes from the Lower Eagle Crag can also be linked up with routes on the shorter Upper Eagle Crag for extended adventures. The route Donkey Serenades covered here, weaves its way up the north facing slabs, making use of the natural breaks and slopes in the rock to reach the top. There is little technical difficulty (depending of which line you take), but it does require solid mountaineering experience because all anchors need to be built from trad gear. Many of the pitches will be in the shade until later in the afternoon, giving a shadier option if you want to avoid the worst of the Morocco sun.	<strong>Approach</strong>: Park on the main road outside Anamr village, which sits under <a href="/climbs/east-buttress-on-ksar-rock/">Ksar Rock</a>. From here walk back along the road before cutting across a vague track to the base of the mountain. Follow the wall all the way to the climb. The climb can be hard so spot the start of from the undergrowth. Assuming you are using the pink Lady start, look for a wide right leaning diagonal crack that leads up to a plateau below a small roof the size of dining table, with a left leaning slab leading off the plateau under the overhang. \r\n</p><p>\r\n<strong>Descent</strong>: From the last belay, scramble up to the summit at the top of the Lower Eagle Crag. From here move West (right with your back to the route) following the Cairn stones that are piled along the way and mark the descent off the Crag. These will take you along the top of the cliff (but below the Upper Eagle Crag), and eventually weave there way down under some serious overhanging buttresses to the terraced fields below and back to the road.	Donkey Serenades takes the easiest line and obvious sweeping weakness up the more prominent part of the Lower Eagle Crag buttress. There are two possible starts and two different finishes depending which guidebook you use. The Oxford Alpine Club guide takes the easier start, which follows the first pitch of Pink Lady. There are also some options for variation throughout this multi-pitch climb.\r\n<br/>\r\n<strong class="pitch-title">Pitch 1 –<span class="length">25m</span> <span class="pitchGrade brit">3b</span></strong><br />\r\nFollow the broken right leading crack up to the ledge below the little overhang. From here head left up the easy slab to belay on one of the ledges. \r\n<br />\r\n<strong class="pitch-title">Pitch 2 –<span class="length">40m</span> <span class="pitchGrade brit">3c</span></strong><br />\r\nThere are a few options for getting to the so-called party time belay. The route takes the left side of the pillar and moves around to finish on the large ledge system. However, the climber could take the crack on the right side of the pillar in two pitches to follow Pink Lady graded <abbr title="Very Severe">VS</abbr> 4c. Alternatively the vegetated corner further right sill, follows the Real Men Wear Pink route, also VS. An additional option is to take the clean slab between these two VS lines for some exceptional climbing, with some decent gear options (not graded but also feels like VS). \r\n<br />\r\n<strong class="pitch-title">Pitch 3 –<span class="length">30m</span> <span class="pitchGrade brit"></span></strong><br />\r\nFollow the right side of the broken slab above the party time belay ledge until reaching a steeper slab covered in black moss, usually in the shadow of the headwall. Build a traditional belay here.\r\n<br />\r\n<strong class="pitch-title">Pitch 4 –<span class="length">25m</span> <span class="pitchGrade brit">3c</span></strong><br />\r\nHead up and slightly left on the black mossy slab. There are lots of options for climbing this wall. When approaching the top, look for one of the vertical blocks. Belays can be built around one of the blocks using slings and other gear. \r\n<br />\r\n<strong class="pitch-title">Pitch 5 –<span class="length">25m</span> <span class="pitchGrade brit"></span></strong><br />\r\nWalk left along the ledge. The climber can follow the low-level crack higher up on the wall, or walk on a lower section. It’s possible to make this into a longer pitch. The 3 pitches (this pitch and the following 2 pitches) can be linked into 2 longer ones if required or if the climbers are short of time. \r\n<br />\r\n<strong class="pitch-title">Pitch 6 –<span class="length">25m</span> <span class="pitchGrade brit">3c</span></strong><br />\r\nFollow the steeper right, shady side of the next face. A belay can be created below the next headwall, or if linking pitches, aim to go all the way to the belay ledge below the now obvious, large pinnacle. \r\n<br />\r\n<strong class="pitch-title">Pitch 7 –<span class="length">30m</span> <span class="pitchGrade brit"></span></strong><br />\r\nMove left towards the short ledges below the large pinnacle. Create an anchor here. Depending on the approach to the next pitch, create the belay further left or right if possible. \r\n<br />\r\n<strong class="pitch-title">Pitch 8 –<span class="length">30m</span> <span class="pitchGrade brit">3c</span></strong><br />\r\nThe Oxford Alpine guide suggests taking the route left and around the pinnacle, from the top of which the climber can scramble higher to build a final belay. The Morocco Rock guide suggests the climber should take the right grove around the right side of the pinnacle to reach the broken scramble above. A third option is to tackle the pinnacle directly for a much harder but much more impressive finish. The rock looks loose and very steep from below, but upon attacking the pinnacle directly the climber will be surprised to find the rock is solid and there are a number of good stances from which protection can be placed. The Donkey Direct finish is not listed in the guides but is likely not harder than VS and will offer the best possible end to the route if the climber is feeling unchallenged by the climbing up to that point. After building a belay on the ledges above to bring up the last of the party, then the climbers can scramble up to the summit paths without difficulty.	{"alt": "Lower Eagle Crag in the Anti-Atlas", "url": "img/tiles/lower-eagle-crag-in-the-anti-atlas.jpg"}	{"alt": "Donkey Serenades climb on Lower Eagle Crag", "url": "img/topos/eagle-crag/donkey-serenades-climb-on-lower-eagle-crag.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "our own image"}	{"alt": "The location of the eagle crag in Morocco", "url": "img/topos/eagle-crag/maps/"}	2026-07-16 05:12:54.187888+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	t	\N
256	234	Morpheus	publish	0101000020E610000076340EF5BB1005C06440F67AF7BB4940	Europe/London	\N	67	4	limestone	Slab	\N	BAS	S 4a	S	4a	3	G	\N	\N	\N	\N	1	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Morpheus is an enjoyable and varied multi-pitch climb originally graded Hard Very Difficult. The climb starts at the same point as Gronk on the left-hand part of the Sea Walls main area in Avon Gorge. Because it’s partially quarried limestone, the route offers and mix of climbing styles including moves on large crimps, laybacks on a flake, some delicate sloping moves and no doubt at least one mantle onto one of the many ledges. Protection is good and requires mostly wires, but some cams are also useful. Whilst the crux was originally the moves off the ground at the start, recent experience suggest the corner crack on the 3rd pitch is now much harder. This is because the limited footholds have been polished to a glass like texture by the feet of many thousand climbers. The rest of the route is mostly not too polished. The Sea Walls at Avon Gorge are a real city crag and some of the most accessible multi-pitch rock climbing in the UK because you can park right at the cliff. However the disadvantage is the main road that runs below the crag is very noisy and can make verbal communication difficult on this climb.	<strong>Approach</strong>: The easiest option is to park in the Sea Walls free car park directly below the cliff (51.468013, -2.632912). There is space for a dozen cars but it can fill up quickly at weekends. It’s also possible to park above the cliff and climb the fence to gain the path down.</p><p>\r\n<strong>Descent</strong>: To descend you can follow the path back down (assuming you parked at the bottom) to the car. The path is obvious and leads to the main road just right of the Sea Walls climbing area in Avon Gorge, Bristol.	The climb Morpheus takes a diagonal but weaving line up some of the easiest rock on the Sea Walls.  It makes for a great introduction to multipitch climbing due to plentiful ledge systems and a reasonably amenable grade (Hard Very Difficult / Severe). It’s possible to link the first two pitches into one long pitch providing you manage rope drag by extending runners and have a good level of confidence on the rock.\r\n<br />\r\n<strong class="pitch-title">Pitch 1 –<span class="length">28m</span> <span class="pitchGrade brit">4a</span></strong><br />\r\nClimb the short wall to a ledge with some better gear options. The initial wall does have some good holds, but they are well disguised in the limestone. Once on the first ledge, carefully walk right to a blocky corner. Place gear and move up this a little, before cutting back left. The next belay is a crack on the left side of the white stained block. It allows good protection behind it. \r\n<br /><strong class="pitch-title">Pitch 2 –<span class="length">16m</span> <span class="pitchGrade brit">3c</span></strong><br />\r\nClimb the block either by layback or reaching up and over while moving the feet up. From above the block move slightly right to good holds and climb onto one smaller ledge before moving up to a large ledge with some broken blocks below a corners system with a crack running through it. A belay can be created in the crack below the corner. \r\n<br /><strong class="pitch-title">Pitch 3 –<span class="length">10m</span> <span class="pitchGrade brit">4a</span></strong><br />\r\nOriginally not a graded pitch, years of climber’s feet have polished the stone here to make it arguably the hardest part of Morpheus whichever way you climb it. The original route suggests moving up the corner to the piton then moving out to the right before going up to the next belay. Whilst arguably still the easiest option, the move requires the climber to trust their feet on a highly polished hold where the foot slipping mid move could lead to an awkward fall. The alternative is to climb the corner directly. This means harder moves, especially for the shorter climber, however it feels much less exposed in the corner. Once this section is dealt with there are a couple of easy moves up onto a ledge with a stone seat and decent options for an anchor in the wall behind.\r\n<br /><strong class="pitch-title">Pitch 4 –<span class="length">12m</span> <span class="pitchGrade brit">3b</span></strong><br />\r\nThis pitch is much easier than it looks. Take good holds diagonally right, initially passing a under a small bush. A belay can be made at the end of the climbing. Alternatively, there is a good tree belay around the corner, however verbal communication with your partner here will be impossible. <br />\r\nIt’s a short scramble up the back wall and a walk off after the tree belay point.	{"alt": "The Sea Walls City Multi-pitch Climbing in Bristol", "url": "img/tiles/sea-walls-avon-gorge.jpg"}	{"alt": "Morpheus route on the Sea Walls in Avon", "url": "img/topos/avon/morpheus-climb-on-the-sea-walls.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "our own image"}	{"alt": "Location of Sea Walls climbing in Avon Gorge", "url": "img/topos/avon/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
1051	318	Granite Whisper	draft	0101000020E6100000EC51B81E85EB17C0105839B4C8164B40	\N	\N	90	3	\N	\N	\N	BAS	VS 4c	\N	\N	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	abseil	2	\N	\N	\N	\N	{5,6,7,8,9}	2	A wandering line up the North Tor's cleanest granite — delicate slab into a soaring corner crack, topping out above the Silent Valley.	Carrick Little car park, Annalong track 40 min, then open hillside to the tor.	\N	\N	\N	\N	2026-07-17 21:40:29.987289+00	human	\N	demo route — fictional; encrypted-cluster write test	f	2026-07-17 11:23:09.04722+00
277	255	Rincón de Placa	publish	0101000020E6100000AADCAE67E902C4BF179C4BF652504340	Europe/Madrid	\N	120	4	limestone	Vertical	S	UIAA	V+	VS	4c	5	G	\N	\N	\N	\N	10	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The Val de Guadar, often called echo valley by the British, offers a great range of climbing from easy to hard, with plenty of multi-pitch options up to just over 100m. The climbs described here on the el Castellet peak have a very short approach, typically 5 to 10mins, so the routes offer good half day options, or could be combined to make a great long day. Rincon de placa (plate corner) offers 4 pitches of solid grade V climbing or VS in British grades. The first pitch gets the highest technical grade in the new Spanish guide escaldes en Alacante, but all four pitches have engaging sections. The gear is also good, with the last pitch perhaps requiring a little more thought to keep it well protected. The route has been almost entirely de-bolted so a full rack is needed. Futher left the routes scorpion and wasp offer less balanced but still fun outings overall. As their names suggest, they have a sting in the tail with the last pitch having noticeably harder climbing. 	<strong>Approach:</strong><br>It’s possible to park right next to the crag, half on the narrow road (<a href="https://maps.app.goo.gl/A2tHy5F79qGQxQFs8" target="blank">38.62679459,-0.15848976025</a>). A better option is to park either before the crag or past it where there is room for a few cars in the bays on the bend (<a href="https://maps.app.goo.gl/K3DViqyaKKVNEW5i7" target="blank">38.62771448,-0.15886262726</a>). The descent path from the routes on the left like Scorpion and Wasp lead back here. From parking, walk to the crag and follow the various paths along the base to the climb. 5 to 15 mins depending on where you park.<br><br><strong>Descent:</strong><br>Descent from Rincón de Placa is by 2 x ~50m abseils With the second being from the station passed just before the belay point at the end of pitch 2. <strong>Note:</strong> Take care not to get the knot caught in the crack at the very top. When first climbing Via Esther I had to top rope solo up the last 2 pitches of Rincon de Placa using just prussicks to free the knot (<a href="/img/other/stuck-abseil.jpg" target="blank">see photo</a>); a formative early climbing experience of questionable safety.<br><br> Descent from the left side after Scorpion or Wasp is a more straightforward walk off. 	Rincón de Placa weaves the obvious line of weakness up to the high point of the  El Castellet peak on the right. The pitches are all pretty good and pretty consistent in grade. <br /><br/><strong class="pitch-title">Pitch 1 –<span class="length">~30m</span> <span class="pitchGrade uiaa">V/V+</span></strong>:<br />Climb the grove left of the arete/edge. The crux is on the lower half of this pitch in a corner section. The pitch steepens but with better handholds up to a vegetated ledge with options for a good thread belay just right of a bolted lower off, below the flat streaked 'plate' face. <br /><br/><strong class="pitch-title">Pitch 2 –<span class="length">~35m</span> <span class="pitchGrade uiaa">V-</span></strong>:<br />Climb the slab above up to the orange stained limestone, but stay below this on good rock trending up and left to the obvious corner. Climb the steep corner onto the block. Cross this and down climb a meter or so on the other side (very vegetated in 2026). Then traverse left on good holds past the lower off, then onto a ledge with a single bolt. Make a belay here. <br /><br/><strong class="pitch-title">Pitch 2 –<span class="length">~25m</span> <span class="pitchGrade uiaa">V</span></strong>:<br />A brilliant pitch more or less straight up to a double bolt belay on a ledge. Good holds and good gear but a slightly steeper wall.<br /><br/><strong class="pitch-title">Pitch 2 –<span class="length">~30m</span> <span class="pitchGrade uiaa">IV+ </span></strong>:<br />Graded the lowest, this pitch isn't really any easier than the others. Climb up the block right of the stance. Then move back left to a position above the belay then climb this slab directly to the top, keeping right of the steep corner higher up. Climbing above the block & tree (rather than moving back left above the belay) can lead into the slightly harder pitch of Dierdo Edwards.	{"alt": "Rincon de Placa Climb in the Echo Valley", "url": "img/tiles/rincon-de-placa-climb.jpg"}	{"alt": "Rincon de Placa climb on El Castellet in Echo Valley near Polop Spain", "url": "img/topos/echo-valley/rincon-de-placa-climb-topo-echo-valley.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "our own image"}	{"alt": "Map of Echo Valley climbing area near Alicante Spain", "url": "img/topos/echo-valley/maps/"}	2026-04-30 13:26:01.356+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
255	244	Great Slab	publish	0101000020E6100000AC1C5A643B5F10C0C3F01131258A4A40	Europe/London	\N	162	5	rhyolite	Slab	N	BAS	VS 4c	VS	4c	5	UNSPECIFIED	\N	\N	\N	\N	120	2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	A great crag and a great route, aptly named the great slab. There is only one technically demanding section up an often-damp corner. The route is long with a lot of variation possible.	From Llanberis either take Britain's only Rack and Pinion Railway to the Halfway House, or make the walk from Llanberis. Walk up the road opposite the Royal Victoria Hotel, then take the path left which runs parallel with the Snowdon Mountain Railway. After the Halfway House a miner's path breaks off right to coast beneath the crag and above picturesque Llyn Du'r Arddu. Beware of rock fall. Calculate 2 hours for the walk-in.	\N	{"alt": "The crag at Clogwyn Dur Arddu or Cloggy", "url": "img/tiles/cloggy-west-butress-small.jpg", "atributionURL": null, "attributionText": null}	{"alt": "The Great Slab Topo on Clogwyn Dur Arddu", "url": "img/topos/cloggy/cloggy-topo-for-great-slab.jpg", "dataFile": 5, "atributionURL": "https://www.thebmc.co.uk/zoomtopo/cloggy/", "attributionText": "BMC super zoom"}	{"alt": "Map showing the location of the great slab on Cloggy", "url": "img/topos/cloggy/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
155	62	Absolute Zero	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	E5 6b	E5	6b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:04.886241+00	source	\N	\N	f	\N
116	129	Jolly Roger	draft	\N	\N	\N	90	2	\N	\N	\N	BAS	E3 6a	E3	6a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.092755+00	source	\N	\N	f	\N
131	130	The Famished Road	draft	\N	\N	\N	\N	3	\N	\N	\N	BAS	HVS 5a	HVS	5a	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.331901+00	source	\N	\N	f	\N
76	91	Roaring Meg	draft	\N	\N	\N	100	3	\N	\N	\N	BAS	VS 5a	VS	5a	5	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:05.735127+00	source	\N	\N	f	\N
65	77	The Artful Dodger	draft	\N	\N	\N	\N	4	\N	\N	\N	BAS	E2 5b	E2	5b	\N	UNSPECIFIED	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	2026-07-15 20:33:06.075+00	source	\N	\N	f	\N
257	258	Le Merinos	publish	0101000020E6100000C0B0FCF9B6901340A7B1BD16F41C4940	Europe/Brussels	\N	100	4	limestone	\N	W	FS	f4c	S	4b	3	UNSPECIFIED	\N	bolted	\N	\N	20	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Le Merinos (graded at least British 3c) makes up the first 3 pitches with an optional addition of the harder La Savonnette (4b). The route takes the west facing arete up the most northern of the Limestone outcrops at Freÿr. Overlooking the Meuse river in Wallonia, this is a classic 70m route which, due to its popularity is highly polished in places, especially the start. Adding La Savonnette as a 4th pitch take the route over 100m. The area is mixed climbing with old bolts and pitons that are best supplemented with a rack of nuts at a minimum.	<strong>Approach</strong>: Parking at Freyr can be found next to the Alpine club huts at 50.220310, 4.894960. From here follow the path down into the forest and go North at the river Meuse. At the Tête du Lion (The Lions Head) outcrop the path goes out onto the river as it hugs the rock face. The Merinos cliff is the last outcrop to the north in the Freyr region. </p><p>\r\n<strong>Descent</strong>: If stopping after Le Merinos, you can scramble North off the crag. If climbing La Savonnette, then there is a scramble off the top. See the climbing topo above.	\N	{"alt": "Le Merinos Climbing Outcrop At Freyr", "url": "img/tiles/le-merinos-climbing-outcrop-at-freyr.jpg", "atributionURL": "https://commons.wikimedia.org/wiki/File:Hasti%C3%A8re_Rochers_de_Freyr_08.jpg", "attributionText": "Zairon"}	{"alt": "Classic multi-pitch climb Le Merinos at Freyr, Belgium", "url": "img/topos/freyr/classic-multi-pitch-le-merinos-at-freyr.jpg", "dataFile": 5, "atributionURL": "https://commons.wikimedia.org/wiki/File:Hasti%C3%A8re_Rochers_de_Freyr_14.jpg", "attributionText": "Original img: Zairon"}	{"alt": "Climbing location for Freyr in Wallonia in Belgium", "url": "img/topos/freyr/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
260	267	East Buttress	publish	0101000020E6100000A75CE15D2E2222C08E75711B0DD03D40	Africa/Casablanca	\N	120	6	quartzite	Slab & Vertical	SE	BAS	HS 4b	HS	4b	4	UNSPECIFIED	\N	\N	\N	\N	10	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Ksar rock offers great multi-pitch rock climbing up to around 150 meters with plenty of climbs in grades from Severe to E1. This is a popular destination for its quick approach, easy access and quality routes that get great winter sun on the south face. The East Buttress route is one of the easier climbs up Ksar Rock, graded as severe in some guides and hard severe in others, the route can be upgraded to very severe by taking some direct variations.	<strong>Approach:</strong>\r\nPark outside of Anammar Village, then follow the track into the village. The track ends at Ksar Rock Guesthouse (see references below for this accommodation option). Take the first obvious turn left down an alleyway and then follow this towards the base of Ksar Rock and the East Buttress climb. \r\n</p><p>\r\n<strong>Descent:</strong> Head over to the top of the cliff, here there will be some small walls and possibly even a traditional camping stove. From here descend down the north side with some scrabbling, which is steep in places, before heading around to the west and coming down the west gully.	The East Buttress climb gets a mixture of sun and shade depending on the time of day and depending on what part of the crag the climber is on as the route weaves back and forth between the east and south faces. This route offers a little of everything but the technical difficulty goes up and down considerably from pitch to pitch. Linking pitch one and two together through the use of long runners will make a for a better first belay and a more logical route given the comparatively easy climbing on these pitches. \r\n<br/>\r\n<strong class="pitch-title">Pitch 1 –<span class="length">20m</span> <span class="pitchGrade brit"></span></strong><br /> Climb up the stepped slabs. With a good rack, a belay can be build on the 3<sup>rd</sup> or 4<sup>th</sup> ledge. Alternatively, moving all the way to the top ledge i.e. the end of ptch two, which is at the base of the crack on the east wall is a good option. \r\n<br/>\r\n<strong class="pitch-title">Pitch 2 –<span class="length">20m</span> <span class="pitchGrade brit"></span></strong><br />If you haven’t linked this pitch, continue up the blocky slabs, taking the steeper right side of the final block, until you reach a belay at the base of the hand crack on the east wall. \r\n<br/>\r\n<strong class="pitch-title">Pitch 3 –<span class="length">20m</span> <span class="pitchGrade brit">4a</span></strong><br />Here the route takes a significant jump in technical difficulty with a short jamming crack. At the top of the crack you gain a ledge, from there take the right hand (east) corner of the large block. This gives way to another ledge where a belay can be made under the significant steepening wall. \r\n<br/>\r\n<strong class="pitch-title">Pitch 4 –<span class="length">30m</span> <span class="pitchGrade brit">3c</span></strong><br />Move left along the ledge to an obvious gully. Climb the block in the centre of the gully to the end. The last, steeper block can be climbed a number of ways either directly or via the wide crack on the right-hand side as recommended in the guidebook. A belay can be created on the large ledge.\r\n<br/>\r\n<strong class="pitch-title">Pitch 5 –<span class="length">15m</span> <span class="pitchGrade brit">4a</span></strong><br />In the North East corner of the ledge there is a large wide crack system running diagonally left (North-West) to another large ledge. This offers a short and enjoyable pitch. \r\n<br/>\r\n<strong class="pitch-title">Pitch  6–<span class="length">20m</span> <span class="pitchGrade brit">4b</span></strong><br />From the final giant ledge, the sixth pitch takes the right side of the wall up to a small ledge. From here the climber moves into an obvious grove. The grove narrows and the climb steepens until a large and somewhat hollow sounding flake of rock is used to gain the summit in a suitably epic finish to this interesting climb. A belay can be made amongst the blocks behind. A variant to this pitch, graded VS 4b is to take the wide crack directly from the belay ledge before gaining the obvious grove.	{"alt": "Ksar rock trad climbing Morocco", "url": "img/tiles/ksar-rock-trad-climbing-morocco.jpg", "atributionURL": "http://www.the-mountain-people.com/blog/morocco-trad-climbing-tafraout-recce-trip/", "attributionText": "The Mountain People"}	{"alt": "Ksar rock offers easy trad climbing Morocco", "url": "img/topos/ksar-rock/ksar-rock-east-buttress-climb-morocco.jpg", "dataFile": 5, "atributionURL": "http://www.the-mountain-people.com/blog/morocco-trad-climbing-tafraout-recce-trip/", "attributionText": "origina: The Mountain People"}	{"alt": "Location of Ksar Rock in Morocco", "url": "img/topos/ksar-rock/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
269	286	Espolón Central	publish	0101000020E6100000FC5580EF366FCABFFB95CE87674B4340	Europe/Madrid	\N	400	10	limestone	Vertical	S	UIAA	IV+	HS	4c	4	G	\N	\N	\N	\N	60	2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The route Epsilon Central on the mountain Puig Campana is truly a world class climb. The rock is solid. The pitches have variety and are all quite consistent in grade. It takes a beautiful line up one of the most prominent features on the face.  The views over Finestrat and out to the sea are panoramic, especially on the upper ridge. The weather can be exceptionally good in winter, with sun on most of the route most of the day. There is also very little polish despite being a very popular limestone route. The popularity of the climb is the routes only downside, even an early morning “alpine” head torch start can have the climber following one party while being tailed by another. This should be seen as an endorsement of the quality of the route as much as a downside. The descent is a bit involved requiring some steep scrambling helpfully protected by metal cables. The route described here is the more direct start which has better rock climbing for the first 100m.	<strong>Approach:</strong><br>The approach is simple and takes around an hour. There is a free car park designated for the Puig Campana trails at 38.579553,-0.210072. This is a good option for parking, alternatively roadside parking can be found up the road around 38.581656, -0.210525. From the parking walk up the road, around a tight hairpin bend at the top of a steep bit of road (there is parking here too), then take the trail on the right side of the road. Follow this trail and ideally take the correct right fork towards the main face. If the climb starts to go out of sight around the right side of the mountain, then the party can start to carefully cut across the shrub-land using one of the many paths to reach the rock and follow the base of the mountain to the start of the climb. The route starts just left of a large sideways-oval shaped flat bit of rock. A head-torch approach is highly recommended over a head-torch descent if worried about time required vs available daylight hours. <br><br><strong>Descent:</strong><br>Allow 2 hours for the Descent. As the climbing eases on the last pitch to become scrambling, look for a faded white arrow pointing right, this marks the way to the descent. The descent itself is marked by red dots of paint roughly the size of small dinner plates. There are metal cables and even some large staples that form a ladder on some parts of the descent. The climber can use a personal anchor and back up sling and carabiner to clip to the cables which protect most of the exposed edges and down-climbs. As a word of caution, personal anchors and slings are not designed or rated to take high factor falls that are possible on via Ferrata. As always with climbing, the party should make their own risk assessments based on ability, equipment and the conditions on the mountain. There are around 40mins of scrambling and via ferrata paths to reach the scree slope. From here the summit path can be found on the left side of the slope (facing down) which will take climbers back to the car in roughly 1h 20mins walking.	There are lots of options and variations on this climb. Other topos grade it as high as V+ which is at least VS. There are some tough moves on pitches evenly spread over the route, but they are all well protected either naturally or with pitons or threads so <abbr title="”Hard" severe”="">HS</abbr> as per the Rockfax guide feels an appropriate grade. There is a quick start (but less direct) option that trades the first 100m of climbing for a slightly longer, Diff graded scramble round the left side. The initial pitches described here are very good and there is enough daylight even on the winter solstice if climbing at a steady pace, so the quick start scramble is not recommended. Most stances are equipped with 2 bolts. All belay positions (apart from perhaps the one for the last pitch) can support a traditional anchor if the bolts are in use by another party (or 2). Linking some pitches makes sense on a rope of at least 60m, if the party is able to manage/mitigate the rope drag. Other pitches could also be linked. <br><strong class="pitch-title">Pitch 1 & 2–<span class="length">55m</span> <span class="pitchGrade UIAA">IV+</span></strong>:<br> Start just left of the oval shaped flat face of rock. <em>Esp Central</em> is painted on the rock near the start of this route. Move up the easy rock to the obvious corner where the first pitch ends (belay if on short rope). From this move out left onto the arête (prominent bulge). This is protected by some old pitons and threads. Then finish this pitch on a good ledge. <br><strong class="pitch-title">Pitch 3 –<span class="length">30m</span> <span class="pitchGrade UIAA">IV</span></strong>:<br> Climb the corner protected by a peg, continuing up easier ground after this. The new Rockfax guide grades this III, others places grade it as V. A belay can be created on the ledge with trees. <br><strong class="pitch-title">Pitch 4 & 5 –<span class="length">~50m</span> <span class="pitchGrade UIAA">III+</span></strong>:<br> Climb up past a small tree, especially awkward with a rucksack, then continue up to a large ledge with a path leading right. Pass the optional tree belay to a bolted belay at the base of the ridge. <br><strong class="pitch-title">Pitch 6 –<span class="length">20m</span> <span class="pitchGrade UIAA">IV</span></strong>:<br> Climb up the face of the ridge to a ledge. There is a belay on pegs just up and right from a tree. <br><strong class="pitch-title">Pitch 7 –<span class="length">45m</span> <span class="pitchGrade UIAA">IV</span></strong>:<br> Follow the ridge to a good ledge. <br><strong class="pitch-title">Pitch 8  & 9 –<span class="length">~50m</span> <span class="pitchGrade UIAA">IV+</span></strong>:<br> Move around the left and forwards for ~5m to the base of a cracked groove. Climb the groove until it eases to a ledge with a tree (optional belay). Move up and right to belay under the cracked wall. <br><strong class="pitch-title">Pitch 10–<span class="length">30m</span> <span class="pitchGrade UIAA">IV+</span></strong>:<br> Climb leftwards a little to the flared groove. Climb up this crack and groove to a ledge with bolt belay set back a bit. <br><strong class="pitch-title">Pitch 11–<span class="length">50m</span> <span class="pitchGrade UIAA">IV+</span></strong>:<br> Move back over broken ground for about 10m. Where the wall steepens there is a small pinnacle left of the blank wall.  The left and right of this are climbable but the left is probably easier and less hollow sounding than the right side. After this continue up the ridge to a stance with bolt belays. <br><strong class="pitch-title">Pitch 12–<span class="length">30m</span> <span class="pitchGrade UIAA">IV</span></strong>:<br>  Climb directly up the steep ridge on good but not always obvious hand holds. There is a zig-zag crack and the final belay is on a large flat ledge with a pair of bolts left of the deep crack / groove. <br><strong class="pitch-title">Pitch 13–<span class="length">40m</span> <span class="pitchGrade UIAA">IV</span></strong>:<br> Climb the deep groove right of the bolts. As it eases the climber is looking for a faded white arrow pointing right of some large red paint dots off to the right. A traditional anchor can be made using a tree and / or cracked rocks on the easy ground.	{"alt": "Epsolon Central climb on Puig Campana Mountain", "url": "img/tiles/epsolon-central-on-puig-campana-costa-blanca.jpg"}	{"alt": "Topo for Espolón Central climb on Puig Campana", "url": "img/topos/puig-campana/epsolon-central-puig-campana-climb-topo.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by/4.0/", "attributionText": "our own image"}	{"alt": "Puig Campana's Location in in Costa Blanca Spain", "url": "img/topos/puig-campana/maps/"}	2023-11-04 01:01:45.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
278	306	Grooved Arete	publish	0101000020E6100000C9E4D4CE30F50FC0A46DFC89CA8E4A40	Europe/London	\N	240	9	rhyolite	Slab	E	BAS	HVD 4a	HVD	4a	3	G	\N	\N	\N	\N	65	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The Grooved Arete climb on Tryfan is one of the most popular multi-pitch climbs in the UK. Graded <abbr>HVD</abbr> or Hard Very Difficult, it’s got some serious british 4a moves, sometimes made harder by the increasingly polished rock. This site tends to avoid the grade HVD, opting to downgrade to VDiff or up to Severe. In this instance Severe is the better grade. Grooved Arete is a lovely outing and is described in The Long Routes book, as <q>one of the best of Snowdonia's classic mountaineering rock climbs.</q> Certainly it’s a quality route, but less popular locations like Lliwedd, offer routes just as good without the crowds. Polish aside, the Grooved Arete climb on Tryfan has an interesting mix of climbing, with enough gear options to feel comfortable. The hike in and hike / scramble out are reasonably lengthy and steep. Typically taking more than an hour. The Knights slab was the traditional crux when done in hobnailed boots, but with rock shoes pitches 1, 6 and 8 all offer comparably tricky moves.	<strong>Approach</strong>: Finding the start of the route, or the path beneath the route called the heather terrace, is not the easiest. From the roadside parking (<a href="https://maps.app.goo.gl/o6jhWFJrisPCZSRB8" target="blank">53.1252100,-3.99056583</a>) before Lynn Ogwen (Lake Ogwen) when traveling from the east / Capel Curig, take a path that leads past the base of Little Tryfan (flat Pyramid crag ~50m heigh). The path then cuts right, but is often overgrown, hard to find, or hard to distinguish from sheep paths or water runoff. There is a notch in a gully with the heather terrace behind and left of this (<a href="/img/other/grooved-arete-approch.jpg" target="blank">see photo</a>). The Grooved Arete is reasonably far along the heather terrace. Guidebooks suggest a 45min approach in total. Many parties may find it takes more than an hour. GA is scratched in large letters in a prominent and highly polished corner. If you are unsure, you are in the wrong place. <a href="/img/other/grooved-arete-start.jpg" target="blank">See photo</a>. <br /><br /><strong>Descent</strong>: There are multiple options for descent. None straightforward if you haven’t been to the mountain before. One option from the top of pitch 9, is to scramble with care on the right (facing in / west) back down to the end of pitch 8. From here a rightward (facing in) path leads via scrambling back down the south ridge to either the heather terrace or other paths that can take climbers back towards the path to the road.	Grooved Arete sees hundreds of sends a year with around half of these on the weekend (30% Sat, 19% Sun). If you prefer a quieter time, start very early or climb in the week, with Wednesday (8%) being the quietest based on logbook data. <br><strong class="pitch-title">Pitch 1 –<span class="length">35m</span> <span class="pitchGrade brit">4a</span></strong>: Climb the polished corner, trending left at the top of corner, then move up the main rib on easier ground and belay before the next rib, on the left, just below a large pillar. <br><strong class="pitch-title">Pitch 2 –<span class="length">30m</span> <span class="pitchGrade brit">4a</span></strong>: Move slightly left into the grove and climb up this using the right hand arete / edge. At a small edge about half way, step left and make a long reach (cruxy - especially so if shorter) upwards from polished footholds. Then carry on to belay below a small overhang. <br><strong class="pitch-title">Pitch 3 –<span class="length">20m</span> <span class="pitchGrade brit"></span></strong>: Pass the overhang on the right and continue easily up to make a stance at the start of the terraces and ledges. <br><strong class="pitch-title">Pitch 4 & 5 –<span class="length">50m</span> <span class="pitchGrade brit">3c</span></strong>: Walk right to another rib looking for ‘GA’ scratched in the rock again. Move up a short slab with an optional belay at the base of the grove or continue up pitch 5 via the groove, or rib on the right, to an uncomfortably small stance (especially when climbing in a 3). <br><strong class="pitch-title">Pitch 6 –<span class="length">25m</span> <span class="pitchGrade brit">4a</span></strong>: Another contener for the crux, climb up the groove making tricky moves on polished footholds to exit it leftwards. Continue trending leftwards and upwards to the large (not that flat) ledge called the Haven. A belay can be made at the block at the top of this. <br><strong class="pitch-title">Pitch 7 –<span class="length">20m</span> <span class="pitchGrade brit">4a</span></strong>: The Kinghts slab pitch moves up a crack then rightwards across the slab the around the corner to a little niche where a belay can be made. <br><strong class="pitch-title">Pitch 8 –<span class="length">20m</span> <span class="pitchGrade brit">4a</span></strong>: Quite a burley and steep pitch on juggy holds. Move up and right into a steep corner. Climb this to a ledge with some large blocks. It’s possible to scramble off from here. <br><strong class="pitch-title">Pitch 9 –<span class="length">20m</span> <span class="pitchGrade brit">4a</span></strong>: Another pitch with a good mix of different moves needed to ascend. Starting on the Quartz topped block, climb up to the top.	{"alt": "Grooved Arete Climb on Tryfan", "url": "img/tiles/tryfan.jpg", "atributionURL": "https://thebaldscrambler.co.uk/snowdonia/glyderau/easiest-route-tryfan/", "attributionText": "Original Image: The Bald Scrambler"}	{"alt": "The Grooved Arete route shown in this topo is one of the most popular multi-pitch climbs in North Wales.", "url": "img/topos/tryfan/grooved-arete-on-tryfans-east-face.jpg", "dataFile": 5, "atributionURL": "https://thebaldscrambler.co.uk/snowdonia/glyderau/easiest-route-tryfan/", "attributionText": "The Bald Scrambler"}	{"alt": "Map of Tryfan climbing area near Snowdonia, Wales", "url": "img/topos/tryfan/maps/"}	2026-02-02 21:28:45.59+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
220	270	Longlands Continuation	publish	0101000020E6100000E84EB0FF3A3710C0577C43E1B3874A40	Europe/London	\N	280	12	rhyolite	Slab	N	BAS	S 4b	S	4b	3	PG	\N	\N	\N	\N	70	2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	This is a huge climb set quite a long walk from civilisation. Technically it’s 3 climbs: Avalanche then Red Wall then Longlands Continuation. These routes  flow into each other with a number of variants. For example you could swap out Avalanche and Red Wall for The Sword & Route 2. This would up the grade to Very Severe thanks to the first pitch of The Sword. With everything that’s going on on Y Lliwedd, the route finding can be a challenge but most sections up the Eastern Buttress of the crag are not too high in grade. Mount Y Lliwedd (colourless peak in English) was where British mountaineers trained before making some of the first attempts to summit Everest.	<strong>Parking</strong>: If you arrive very early (due to limited spaced) and don’t mind the parking fees, Parking in Pen Y Pass is easiest. Otherwise there is some roadside parking just after the turn off away from Llanberis Pass, but this will increase the hike by up to 30mins each way. Alternatively, you can park in the Nant Perris car park and take a shuttle taxi up to Pen Y Pass (£2 each way per person in 2019). For this follow the signs for park and ride. <br />\r\n<strong>Approach</strong>: From Pen Y Pass, take the Miners track to the first lake and the green pump house. Turn left here towards Mount Y Lliwedd. Follow the path briefly then cut right and away from the main tracks towards the base of the mountain. <br />\r\n<strong>Descent</strong>: If you head left after completing the climb (with the route behind you), this will take you to a path that leads off the summit and back to the main track. Allow up to 2 hours to get back to Pen Y Pass from the top of Lliwedd as the path weaves around the back of the mountain and you may well be pretty tired after the climb.	A true mountain classic that features in all major North Wales guidebooks and the iconic Classic Rock book by Ken Wilson. Allow plenty of time for route finding on the 12 pitches. Most of the climbing is technically straightforward with an reasonably exposed 4a pitch on the Red Wall section that’s very memorable and a crux 4b pitch right at the end which is a delicate slab with good but smaller spaced holds. 2 pitches are a short walk along a ledge so some time can be saved there. Allowing 12 hours for a round trip from Pen Y Pass would be sensible. It can be done much quicker, especially if you know the route, however it could also take much longer if you get lost so bringing a decent headtorch is a good idea. The route is North facing, so will be in the shade most of the day, this means it can take a couple of good days to dry out. Climbing it damp will be much harder and less enjoyable. The route has been given the grade Hard Very Difficult or HVD in older guides and Severe in the newer rockFax. Protection is mostly good, but being able to confidently and easily climb severe 4b is essential as there are not many easy escape options. J. Longland added his continuation to the Redwall in 1929. Where grades are shown as 3c I’m simply marking that it’s rock climbing of low technical difficulty by modern standards. This is simply to distinguish between climbing pitches and walking or scrambling pitches. \r\n<br />\r\n<strong class="pitch-title">Pitch 1 –<span class="length">25m</span> <span class="pitchGrade brit">3c</span></strong><br />\r\nThe first pitch goes up to the heather shelf from the base. Follow a steep curving groove to the right hand side of the shelf. If you are worried about timing you can scramble up the side and essentially skip this pitch. \r\n<br />\r\n<strong class="pitch-title">Pitch 2 –<span class="length">30m</span> <span class="pitchGrade brit">3c</span></strong><br />\r\nNot an obvious line and one it’s easy to get lost on. The key is to move diagonally right below a heather bush and over 2 ribs of rock, then climb up just under 5m to belay left of a spike. Moving over only one rib will lead you up a steeper gully with some harder moves. You can climb out of this at the top and back down into the correct path if you do get lost. \r\n<br />\r\n<strong class="pitch-title">Pitch 3 –<span class="length">15m</span> <span class="pitchGrade brit">3c</span></strong><br />\r\nClimb up a short pitch to belay on a ledge just left of a quartz band running though some rock to your right. \r\n<br />\r\n<strong class="pitch-title">Pitch 4 –<span class="length">25m</span> <span class="pitchGrade brit">3c</span></strong><br />\r\nClimb up and diagonally right via the quartz band to get over the buldge. Climb the right hand side of the rib to a spike belay.\r\n<br />\r\n<strong class="pitch-title">Pitch 5 –<span class="length">35m</span> <span class="pitchGrade brit">3c</span></strong><br />\r\nA straightforward pitch that goes broadly straight up to a ledge that marks the end of climbing for the route Avalance. You can belay on a reasonably square spike or move further right to a slightly higher ledge to belay from cracks in the wall.\r\n\r\n<br />\r\n<strong class="pitch-title">Pitch 6 –<span class="length">32m</span> <span class="pitchGrade brit"></span></strong><br />\r\nWalk / Scramble up and right keeping reasonably close to the main wall, until you get to the redwall with RW etched into it in big letters. You can create a belay here before taking on the magical redwall pitch. Alternatively, there is an escape option leftwards to the terminal arete which will be easier climbing / scrambling to the top (so guidebooks say).\r\n<br />\r\n<strong class="pitch-title">Pitch 7 –<span class="length">25m</span> <span class="pitchGrade brit">4a</span></strong><br />\r\nTo lead the redwall you take a beautiful rising traverse on delicate holds. Cams and some nuts can be used to protect the moves in a few places. The exposed moves take you onto a rib which you can move up though to some ledges and eventually a belay in a groove leaning towards the terminal arete (up and left). \r\n<br />\r\n<strong class="pitch-title">Pitch 8 –<span class="length">30m</span> <span class="pitchGrade brit">4a</span></strong><br />\r\nContinue up passing a pinnacle on the right. From the ledge you want to use a short wall to climb on to the grassy ledge called the Green Gallery. There are some belay options either on the left or on the centre of this ledge. \r\n<br />\r\n<strong class="pitch-title">Pitch 9 –<span class="length">10m</span> <span class="pitchGrade brit"></span></strong><br />\r\nWalk towards the edge of the ledge at the right. You can either create a new belay here or link this into the next pitch as one. If you are linking these up then make sure you use a long runner and ideally a carabineer with a wheel like the DMM Revolver. If in doubt don’t run them together or the rope drag will take the fun out of the climb and you risk a ground / ledge fall.\r\n<br />\r\n<strong class="pitch-title">Pitch 10 –<span class="length">25m</span> <span class="pitchGrade brit">3c</span></strong><br />\r\nIf you end up climbing an awkward but enjoyable chimney, chances are you left the ledge in the wrong place and may find the route slightly more difficult. The route is supposed to climb the left arete off of the right side of the Green Gallery, heading up and leftwards to some ledges and a slab. Move up past a broken block and create a belay in a pocket further up.\r\n<br />\r\n<strong class="pitch-title">Pitch 11 –<span class="length">30m</span> <span class="pitchGrade brit">3c</span></strong><br />\r\nMove up and rightwards directly towards the final slab of Longlands continuation. You should see or at least hear walkers on the summit by this point. A belay can be created on the ledge directly below the final slab. The multi-pitch climb is coming to an end but the hardest pitch remains.\r\n<br />\r\n<strong class="pitch-title">Pitch 12 –<span class="length">30m</span> <span class="pitchGrade brit">4b</span></strong><br />\r\nThe final pitch moves up and trends slightly left in before going straight to the summit of Lliwedd’s Eastern Buttress. The gear is good if you take the time to find it and delicate footwork will help see you thought. The rock is clean and generally solid. There are a number of belay options on the summit.	{"alt": "Lliwedd Buttress", "url": "img/tiles/lliwedd.jpg", "atributionURL": "http://footlesscrow.blogspot.com/2010/04/up-against-it.html", "attributionText": "Al Leary"}	{"alt": "Topo for Avalanch to Red Wall to Longlands Continuation", "url": "img/topos/lliwedd/longlands-continuation-climb-on-lliwedd.jpg", "dataFile": 5, "atributionURL": "https://www.flickr.com/photos/arg_flickr/14442887130/", "attributionText": "Andrew"}	{"alt": "Mount Y Lliwedd Location in Wales", "url": "img/topos/lliwedd/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
247	269	Gweilo via Topcat	publish	0101000020E61000008BC6DADFD98B5C40DD9733DB155A3640	Asia/Hong_Kong	\N	80	4	granite	Slab, Vertical & Overhanging	W	BAS	HVS 5b	HVS	5b	6	PG	\N	\N	\N	\N	40	2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Lion Rock sits on the Kowloon Peninsular in Hong Kong on the border with the new territories. Whilst not a huge mountain crag, it does offer in excess if 70m of climbing, especially on the winding routes. Gweilo is a classic 3 star multipitch sport route graded 5+. Topcat swaps out the middle of this for a harder but reasonably well protected trad line graded HVS 5b. The views on this route are stunning and utterly unique in the world of climbing. Fun fact, Gwáilóu means Ghostly Man in Cantonese and is used to refer to white westerners.  Hong Kong can range from roasting hot with lots of mosquitos to typhoon season with howling winds so plan accordingly.	Kowloon side: Take the MTR to Lok Fu Station and get a taxi to Lion Rock Country  Park (Sze Tsz San). Follow the road to the right of the park entrance gates for about 30 m before heading up the hill on a well signposted footpath. Upon reaching a small shelter on the ridge line take the upper right hand path (signposted to Lion Rock) and continue upwards. When approximately level with the toe of the crag a small dirt path breaks off right from the main track (by a small platform and a ‘Danger - Steep Cliffs’ signpost) and leads to the foot of the cliff. Approach time approx. 40 minutes. Sha Tin side: Take the MTR to Sha Tin Station and get a taxi to Mong Fu Shek BBQ. From here follow the obvious footpath up the hill towards the crag. From the shelter follow the left hand path up the ridge and approach as for Kowloon side. Approach time approx. 45 minutes.	\N	{"alt": "Lion Rock crag west face in Hong Kong", "url": "img/tiles/lion-rock-west-face.jpg", "atributionURL": "https://www.flickr.com/photos/wza/352391496/in/photostream/", "attributionText": "Warren R. M. Stuart"}	{"alt": "Lion Rock Topo for Topcat", "url": "img/topos/lion-rock/lion-rock-topo-for-gweilo-via-topcat.jpg", "dataFile": null, "atributionURL": "http://www.curiousatlas.com/hong-kong-lion-rock-hike-tai-wai/", "attributionText": "img: thewisebackpacker.com"}	{"alt": "Location of Lion Rock in Hong Kong China", "url": "img/topos/lion-rock/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
222	292	Keswick Brother's Climb	publish	0101000020E6100000007157AF22C309C0F452B131AF394B40	Europe/London	\N	74	3	rhyolite	\N	N	BAS	VD 3c	VD	3c	2	UNSPECIFIED	\N	\N	\N	\N	70	2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The Keswick Brothers were some of the key early rock climbing pioneers. What is particularly important about them is fact they travelled with an camera making them some of the first people to capture rock climbing imagery. They set first accents up and down the UK including their first climb on Scafell Crag in 1897. Keswick Brother’s Climb takes a shorter line up the left side of the buttress over easy ground and up the grooved slab. If you have ever wondered why Very Difficult climbs are generally easy, you need to understand the adjectival grading system used in Britain comes from the 1800’s. Climbers in that period didn’t have cams or even nuts. They didn’t have Kernmantle dynamic ropes or dedicated sticky rubber climbing shoes. In fact this climb was graded over 20 years before the carabiner was invented!	<strong> Approach:</strong>  Best approached from Wasdale where there are a couple of big car parks. Allow an hour to hike uphill to the crag. The route Leads most of the way to Scarfell Pike, but once the Scarfell Crag comes into sight, take a right less used fork in the path to the crag. Access to the starting terrace is gained via a path on the right of the crag.<br><br><strong>Descent:</strong> There are multiple options for decent on each end of the crag and require steep scrambling and/or and abseil. <br>	\N	{"alt": "Scafell Crag in the Lake District", "url": "img/topos/scafell/scarfell-pike-climbs-s.jpg", "atributionURL": "https://www.thebmc.co.uk/zoomtopo/scafell/", "attributionText": "BMC super zoom"}	{"alt": "Topo for keswick Brothers Climb on Scafell Crag", "url": "img/topos/scafell/scafell-route-for-keswick-brothers-climb.jpg", "dataFile": null, "atributionURL": "http://lakelandpilgrimage.blogspot.com/p/the-cathedrals.html", "attributionText": "John Fleetwood"}	{"alt": "Scafell Crag location", "url": "img/topos/scafell/maps/"}	2021-10-15 01:02:00.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
254	310	Right Hand Route	publish	0101000020E61000000AB952CF825005C0B83F170D19D54940	Europe/London	\N	87	4	limestone	Slab & Vertical	\N	BAS	HS 4b	HS	4b	4	G	\N	\N	\N	\N	20	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The right hand route is in many ways the opposite twin to the left hand route (also a Hard Severe climb). It has better pitches at the top where the left-hand route has better pitches at the bottom. While the right hand route looks heavily vegetated from the bottom it’s surprisingly clean. That’s not to say its perfect, just better than it looks. It has good variety and is more sustained in grade when compared to the left-hand route, which has a hard start and then eases off. It’s a classic limestone route with a small crack section, and exposed thin ledge system and a steeper juggy section at the end. Check the BMC RAD Database for route exit information (see references), but at the time of writing abseiling off is required (see descent info).	<strong>Approach:</strong> There is a grassy parking space for several cars above the outcrop at 51.666565, -2.665006. From there, continue on the road you came in on and take the first obvious path left not long after leaving the parking area. Follow the path and take the next obvious left after the old stone arches. After following this path until you come to the old chapel near the river. Pass it and turn left at h the river. Follow this path for a short distance until you near the outcrop then take a left up a climbers path to the base of the cliff. <br /><br />\r\n<strong>Descent:</strong> Following a change of ownership of the house above this section of crag, the previous arrangement to exit through its garden is not longer possible. Do not top out on any North Wall routes - only abseil descent from below the top of the crag is allowed. Trees and some abseil 'tat' allow climbers to return to the Great Ledge from the top of this climb. An abseil descent can then be made from one of the two bolted abseil stations above The Tap or Joe’s Route on the Great ledge. Climbers have reported being able to reach the base of the climb using a 50m rope abseil from the great ledge (maybe rope strech dependent). A 60m rope will allow a single abseil. There is an intermidate abseil point around halfway down the North wall. As always take care when abseiling and follow best practice (stopper knots, backup prussic and know how to ascend a rope if needed). 	The Right Hand Route takes a line up good rock, weaving around trees and foliage and makes good use of ledges for belay points. \r\n<br />\r\n<strong class="pitch-title">Pitch 1 –<span class="length">18m</span> <span class="pitchGrade brit">3c</span></strong><br />\r\nClimb the cracked gully diagonally right to get around some bushes then cut back left above them. There is a small stance and a decent tree belay just above the main ledge. The tree can be backed up with some protection in the rock. <br />\r\n<strong class="pitch-title">Pitch 2 –<span class="length">21m</span> <span class="pitchGrade brit">4b</span></strong><br />\r\nThe second pitch ups the grade after an easy start. Climb straight up behind the belay past some vegetation. Keep moving up until you’re below a left leaning thin crack that leads to another small ledge with a tree belay (again back it up with the rock). The crack offers good holds and protection but can feel a bit exposed and is a slight step up in the grade, especially if you can’t find the good holds.<br />\r\n<strong class="pitch-title">Pitch 3 –<span class="length">17m</span> <span class="pitchGrade brit">4b</span></strong><br />\r\nClimb up and slightly right onto some ledges. Take the left of two groves, this should have a peg you could use for additional protection. After that there should be a short neat slab and easier ground up onto the great ledge where there is a peg and tree belay at the back. Traversing left on a thin finger ledge before the great ledge offers a lovely if exposed climb with a big mantle move up. <br/>\r\n<strong class="pitch-title">Pitch 4 –<span class="length">30m</span> <span class="pitchGrade brit">4a</span></strong><br />\r\nA brilliant and rewarding pitch with great protection. Essentially you are looking to head though the broken V shape in the headwall above the ledge. The route has good holds, making it easer than it looks. After the broken V, climb the short wall above and then keep heading up to slings and an abseil ring set up on a tree. You can climb the chimney or the wall directly below the abseil and anchor point. Both are short but fun.	{"alt": "Limestone Outcrop Wintours Leap in the Wye Valley", "url": "img/tiles/wintours-leap-wye-valley-climbs.jpg"}	{"alt": "Right Hand Route Climb at Wintours Leap in the Wye Valley", "url": "img/topos/wye-valley/wye-valley-wintours-leap-right-hand-route.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "our own image"}	{"alt": "Location of Wintours Leap Climbing in the Wye Valley", "url": "img/topos/wye-valley/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
279	286	Aristotles	publish	0101000020E61000000213A4483196CABFD6FECEF6684B4340	Europe/Madrid	\N	340	9	limestone	Slab	SW	UIAA	V	HS	4b	4	G	\N	\N	\N	\N	40	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Overall Aristotles (spelled Arestotles locally) is a beautiful adventure on Puig Campana, arguably one of the best multi-pitch climbing locations in Europe for long, low to mid grade trad climbs. This route weaves a reasonably easy line up the impressive western arete to the top of the aguja encantada or enchanted needle. Referred to as Arista Aristóteles or Aristotle's edge, the route can be done in as few as 7 pitches or as many as 13 if staying in communication range is important to the party. Longer pitches will make it more enjoyable and faster. There is little fixed gear on the route, some bolted stances and some old pitons as well as a number of fixed threads. However a full rack is recommended as many of the threads and pitons are looking tired in 2026. Finger tape is also handy, because the sharp limestone will almost certainly draw blood at some point(s). The climbing only has two pitches graded V and the harder sections on these are short. The route ends with a short 10m then longer 60m abseil or the pepsi crest offers a 150m continuation to a different abseil finish from the mediterranean pillar. It’s hard not to compare the route to Espolon Central nearby. Aristotle's is much less consistent in grade and although some guides give it the Very Severe grade, it’s probably an easier undertaking overall, because many pitches have little difficulty. That said, routefinding is more complex on Aristotels.	<strong>Approach:</strong> From the roadside parking (<a href="https://maps.app.goo.gl/YQrD5JcTTTLQNHsD6" target="blank">38.5817212,-0.21224546</a>), cross the road and take the trail (lower parking joins this trail 5mins further up). Follow this trail and ideally take the correct right fork (a discrete climbers path, sometimes marked with cairns) towards the main face. The path leads over some short terraced walls past a completely white faded sign and eventually to the face of the Aristotles climb, marked with Arest in red with an arrow. Allow 35min or more from the roadside car park, perhaps 50mins from the main trails car park. <br /><strong>Descent:</strong> Bringing cord to back up the abseils and / or threads is recommended. The main cord connecting the 2 newer bolts had the sheath degraded and core exposed. We backed this up with a new 6mm thread (Jan 2026) but thin-thread has a short safe lifespan,  so bring your own.There is also a cord on a nearby thread so it does have ample redundancy. <br />The total abseil is just under 70m; however don't attempt it in one with a 70m rope because the pull angle won't work, the rope will get pinched and significant shenanigans will be needed to free it. Instead do the short 10m abseil to the newer rings in the col between the pillars and then do a 60m abseil to the ground. From here you can scramble down. We went over the notch in the small ridge on the left when facing out (which has a cord based anchor and maillon in situ) and onto the other side before descending on the left via the rope assisted path. From here we kept moving left and away from Aristotles until we reached a main path that allowed us to walk back past the base of the route and reverse the approach.	<strong>Note on the grade:</strong> Graded VS in the mountain adventures Costa blanca guide and V (five) in the Escalades en Alacante guide, but Hard Severe on UKC, this route is perhaps the only time I've thought maybe the grade Mild Very Severe (used mainly by lake district climbers) might be helpful. VS is perhaps a bit generous as protection is very good, the rock is sound and much less loose than other 350m climbs and the harder grade V moves are limited to a small section on pitch 2 protected by a ring bolt and a few meters of delicate slab near the top, with 3 pitons and some natural gear options making it feel more HS overall. There are plenty of variations to push the grade higher for those interested, including the Espolon Finestrat start or the Vincent M. Sellés variation instead of the traverse or the Via Elise Hector variation from the ledge. All in the V to 6a+ range. <br><br><strong class="pitch-title">Pitch 1 –<span class="length">38m</span> <span class="pitchGrade UIAA">IV</span></strong> Start where Arest is painted on the rock in red and climb up through the notch, moving up and right then back left to a good ledge with thread belays on a grey slab. The ring bolt protecting the crux of the climb can be seen in the orange left leaning crack 10m above this first belay.<br><strong class="pitch-title">Pitch 2 –<span class="length">50m</span> <span class="pitchGrade UIAA">V</span></strong> Move up to the ledge above and tackle the crux crack (orange limestone, left leaning) protected by the chunky ring bolt, following it as the difficulty of the pitch eases and trends right to reach a ledge with 2 options and arrows scratched / rubbed into the wall: MS (for Vincent M. Sellés) pointing up and A (for Aristotles) pointing right. <br><strong class="pitch-title">Pitch 3 –<span class="length">18m</span> <span class="pitchGrade UIAA">IV</span></strong> Traverse right to a wire thread (in 2026) and then up and slightly left to a thread on a small awkward stance where a belay can be made. It's possible/recommended to link the next pitch depending on rope drag. By over protecting the surprisingly easy traverse the awkward belay was the best option on our ascent.<br><strong class="pitch-title">Pitch 4 –<span class="length">28m</span> <span class="pitchGrade UIAA">IV+</span></strong>Go onto the block and move right into a small niche, then climb up the rounded rib, trending a little left then a little right to reach a two bolt stance.<br><strong class="pitch-title">Pitch 5 –<span class="length">45m</span> <span class="pitchGrade UIAA">III+</span></strong> Climb straight up on increasing easy terrain until reaching the large ledge (optional belay). Move to the back of this while trending right and create a belay on the back wall a couple of meters left of an obvious easy gully with trees above it.<br><strong class="pitch-title">Pitch 6 –<span class="length">40m</span> <span class="pitchGrade UIAA">IV+</span></strong> Move up the gully briefly 5 or so meters, before moving onto the steeper left wall. Climb this aiming to be above the previous belay on the ledge. There is an optional interim belay here, otherwise carry on trending up and left to a stance below a grey slab with a pair of bolts below-and-left from the slab under a small overhang. The letter A with an arrow pointing to the slab, should be prominently scratched at the stance.<br /><strong>Routefinding Note: </strong>If you you go too far up the gully and make a stance at a ledge on the left wall,  it might be tempting to climb up to the obvious slings and hardware on a grey pinnacle attached on the left side to the orange wall. Don't. It's isolated and you will need to lower or abseil back down this.<br /><strong class="pitch-title">Pitch 7 –<span class="length">25m</span> <span class="pitchGrade UIAA">V</span></strong> It’s possible to link pitches 7 & 8 here. 7 is a lovely pitch. Climb onto the slab (gear options) then up to the piton. The pitch goes up trending slightly right (2 pitons) to avoid the overlap which is passed on the right. After this the route moves back left to a belay or carry on into the next pitch. <br /><strong class="pitch-title">Pitch 8 –<span class="length">35m</span> <span class="pitchGrade UIAA">IV</span></strong> Climb up and left to a piton. Traverse left from here onto the arete. Climb up the rib with great moves and great views to a thread belay or higher bolted belay. A more direct line up the middle may be IV+ or V with the easier route weaving right around a slab before the bolt.<br /><strong class="pitch-title">Pitch 9 –<span class="length">55m</span> <span class="pitchGrade UIAA">IV</span></strong> Move straight up the rib to the top where easier moves lead to the belay to bolts with rings, one backed up by a thread and an old abseil bolt with maillons (as of 2026) on the far side of the peak. This pitch can easily be divided into two if desired by creating a belay at a ledge along the way.	{"alt": "Aristotles Climb on Puig Campana", "url": "img/tiles/aristotles-puig-campana.jpg"}	{"alt": "Aristotles climb on Puig Campana near Finestrat Spain", "url": "img/topos/arest/aristotles-climb-topo-for-puig-campana.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "our own image"}	{"alt": "Map of Aristotles climbing area on Puig Campana", "url": "img/topos/arest/maps/"}	2026-07-16 05:16:31.03552+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
214	245	Wreakers Slab	publish	0101000020E6100000271422E0103A12C0BE11DDB3AE754940	Europe/London	\N	130	3	sandstone	Slab	S	BAS	VS 4b	VS	4b	5	R	\N	\N	\N	\N	50	2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Wreakers slab is a fantastic adventure and one of the longest vertical multi-pitch climbs in the South of the UK.  With around 120m of cliff to scale, it makes for a great day out. The climbing is generally easy, but the rock is loose in places, especially on the first pitch, so make sure the leader is experienced. Protection on the first pitch can also be a challenge, but it gets better the higher you go.	Park in Morwenstow tea room car park lat/lon: 50.908732, -4.553767. Go into the morwenstow graveyard and pass out the bottom (north east) down a path past some private housing into a small wooded area. Go over the tiny stream and turn left out of the woods. Cross two fields and turn right at the cliff edge. Follow the coastal path until you see Cornakey Cliff. When above it, pass behind it to a sketchy and thorny scramble down the slope. Reach the loose rib and work your way down to the makeshift hut. Pass that to the (hopefully) in-situ rope. Descend to sea level when the tide is out and make your way around to the base of the climb. This may require some rock hopping or down climbing. Don't forget to enjoy the descent, it's part of the experience.	It's fair to say everyone has a slightly different experience on wreckers slab, partly because the cliff is loose and the holds likely change regularly, even between the leader and the second! This makes helmets an absolute must. Due to its scale it's likely a lot of people also take slightly different lines, especially at the bottom and top pitches where the route is less clear. I think it justifies the grade of VS 4b. With the low technical grade it's an easy route to underestimate. A lot of the protection early on is marginal and some placements could actually make the climb more dangerous. For instance, a cam behind a large loose block could put the seconds life in danger. In short, it's not an ideal choice for those new to traditional multi-pitch climbing, but it offers stunning views and is a wonderful lengthy adventure if you have the experience to lead it.\r\n<br />\r\n<strong class="pitch-title">Pitch 1 –<span class="length">40m</span> <span class="pitchGrade"">4a</span></strong><br />\r\nMy experience here is reasonably worthless except to say if you leave the guidebook at the top of the cliff (because who wants to climb with a guide book in their bag), then the chances are you won’t actually know exactly which way to go and may attack the first belay head on. This takes you over loose ground with little or no gear and possibly makes the route a harder grade. Instead I’d recommend you don’t start too far right, climb up a few of meters to where the cliff eases off then traverse all the way left to the arete and head up to the belay.\r\n<br />\r\nThere are 2 pegs that you can use to form part of your belay. I’d highly recommend a 3 or 4 point anchor in addition to them. I placed my gear below the pegs giving a reasonably comfy ledge to belay from. Your nut tool comes in handy to clean the cracks when you lead this pitch!\r\n<br />\r\n<strong class="pitch-title">Pitch 2 – <span class="length">40m</span> <span class="pitchGrade"">4b</span></strong><br />\r\nHead up and around the overhanging block just above the belay. Whilst this is probably the steepest part of the climb it’s not fully vertical making gear placements easier than it looks. Be careful not to throw too many handholds at the belay below and follow the reasonably obvious crack up to a big grassy ledge with a pillar of rock on it.  There are lots of options to build a traditional anchor here. You can use the front of the pillar, side or even the nearby crack further up.\r\n<br />\r\n<strong class="pitch-title">Pitch 3 – <span class="length">50m</span> <span class="pitchGrade"">4a</span></strong><br />\r\nThis is where the rock climbing becomes utterly enjoyable. For the most part the rock is solid and there are plenty of placements for gear, the left ridge is recommended with its stunning if a little intense views. Guidebooks suggest the pitch is 45m, but a the full 50m will take you over the top and right a little. A good belay can be built on the other side of the top ridge. Consider belaying your partner off the top 10m walk. It would be a stretch to call it a 4th pitch, but placing a couple of pieces of gear makes it a safer scramble.	{"alt": "Wreakers Slab Sea Cliff in Cornwall", "url": "img/tiles/wreakers-slab-small.jpg", "atributionURL": null, "attributionText": null}	{"alt": "Wreakers Slab Topo on Cornakey Cliff", "url": "img/topos/wreakers/wreakers-slab-climb-in-cornwall.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "our own image"}	{"alt": "Map showing Wreakers Slab on Cornakey Cliff", "url": "img/topos/wreakers/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
219	303	Durance	publish	0101000020E6100000831953B0C62D5AC07A8D5DA27A4B4640	America/Denver	\N	152	6	phonolite	Vertical	S	YDS	5.8	VS	4c	5	UNSPECIFIED	\N	\N	\N	\N	5	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Durance Route on the Devils Tower in Wyoming is listed as one of the 50 classic climbs in North America. It's a 4-6 pitch route in which the harder sections are mainly off-width and hand-cracks with a few spots of chimney. Don't forget to register at the Visitor's Center before the climb or you risk a fine. This is a crowded route so get on super early or be ready to follow others and possibly do the abseil descent in the dark with headtorches.	<strong>Approch</strong>: Follow Tower Trail to the right until the historic wooden ladder "viewing tubes". Follow the climbers trail up switch backs to the base of the Bowling Alley. Climb approach pitch. Traverse left on ledge system to base of Leaning Column. The meadows rappels can be done with a single 70 m rope with 15 feet of 4th class down climbing on the last rappel. The Bailey Direct rappels require two 60 m ropes.\r\n</p><p>\r\n<strong>Descent</strong>: The meadows rappels can be done with a single 70 m rope with 15 feet of 4th class down climbing on the last rappel. The Bailey Direct rappels require two 60 m ropes.\r\n<br />\r\nNote: Thuderstorms are common in the summer months and are not easily seen coming from the Durrance area. Check the weather ahead of time!	\N	{"alt": "The Back of the Devils tower Wyoming", "url": "img/tiles/devils-tower-wyoming.jpg", "atributionURL": "https://www.nps.gov/deto/planyourvisit/climbing.htm", "attributionText": "National parks service"}	{"alt": "The Back of the Devils tower", "url": "img/topos/devils-tower/devils-tower-durance-climb-topo.jpg", "dataFile": null, "atributionURL": "https://www.nps.gov/deto/planyourvisit/index.htm", "attributionText": "img: national parks service"}	{"alt": "The Devils Tower Location USA", "url": "img/topos/devils-tower/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
267	291	Via Maria	publish	0101000020E610000062F6B2EDB49D2740740987DEE23F4740	Europe/Rome	\N	370	10	dolomite	Vertical	S	UIAA	IV+	HS	4a	4	PG	\N	\N	\N	\N	70	2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The Route Via Maria offers an exceptional climb up a dramatic mountain face, finishing at an altitude of 2,950m. The climb is graded IV+ in <abbr title="Union International Alpine Association">UIAA</abbr> grades which is roughly around Severe or Hard Severe in British grades. The route is consistent in difficulty until the last section near the summit. Many of the pitches are graded IV. The crux, whilst a little strenuous (IV+), is early in the route and more straightforward than some of the later sections. There are pitons in place thought-out the route and many of the belay points are bolted with a thick single cemented ring. However, taking a light rack with plenty of slings is essential. The route provides exceptional positions with glorious views out over the valleys with the Marmolada glacier visible to the south. The route has sustained interest with a mixture of climbing, mostly on good holds.	<strong>Approach</strong>: Park at the large car park by the cable car station at Pordoi Pass (<a href=" https://goo.gl/maps/dnyy3jH8a63yB8Da8" target="blank">46.488146,11.810553</a>). From here there are 2 options. Climbers can follow the path up to the south face of Sass Pordoi, veering left up a scree rib where the summit path would go right. This is a long and strenuous, if straight forwards hike. Allow at least an hour for this, longer if your fitness is questionable. The other option is to take the cable car up to the summit then take the path back down and cutting across to the climb after descending the scree fan.  <br /><strong>Descent</strong>: There are again the 2 options for descent back to the car park. The easy option is to take the cable car from the summit. The climb ends at the cable car station. You need to buy tickets in advance and the last cable car down in summer is at 5pm (at the time of writing – Aug 2020). This will be announced in the 30min lead up to 5pm. The alternative option is to reverse the summit path back down passing the Rifugio Forcella Pordoi. Allow a couple of hours for the walk off descent.	Great rock, exposure and incredible views across the Dolomites. This climb is long, consistent in grade and offers a lot of Sun on the south face of Sass Pordoi. <br /><strong class="pitch-title">Pitch 1 –<span class="length">25m</span> <span class="pitchGrade UIAA">IV</span></strong><br />The first pitch is just under 25m, and is polished at the start, but has mostly good holds. Starting just left of the big break, climb the short-polished wall, then move left slightly before heading up the cracked section to a large cemented bolt belay. <br /><strong class="pitch-title">Pitch 2 –<span class="length">35m</span> <span class="pitchGrade UIAA">IV+</span></strong><br />The crux pitch of the route, moves into the gully a little before heading up the slab on the left. The pitch will steepen after a couple of pitons are passed and the crux will loosely follow a crack on good holds over steep ground protected by another couple of pitons. The pitch finishes on an obvious ledge below a crack, with a bolted belay. <br /><strong class="pitch-title">Pitch 3 –<span class="length">25m</span> <span class="pitchGrade UIAA">IV</span></strong><br />A solid pitch that tackles the crack above the belay for 5m before moving left, up and then back right. After this an easier crack leads to a bolted belay on a ledge. Note, the Rockfax guide description is not completely accurate here, i.e. don’t climb 45m.<br /><strong class="pitch-title">Pitch 4 –<span class="length">40m</span> <span class="pitchGrade UIAA">IV</span></strong><br />Follow a few pitons up the ramp towards the right side of the triangular roof. There is a bolted intermediate stance around the middle of this pitch, which is a bit of an awkward place to stop. Clipping the belay and moving on, following past a couple more pitons leads to a better belay on a bigger ledge. <br /><strong class="pitch-title">Pitch 5 –<span class="length">50m</span> <span class="pitchGrade UIAA">III+</span></strong><br />Traverse right and then up on loose rock using natural protection (some good options for threads). Climb more or less any line up to the block between where the two parts of the mountain meet on the right. A belay can be created on the block next to the main wall where there may already be an in-situ thread. 50m rope will make the block assuming there isn’t lots of zig-zagging.  <br /><strong class="pitch-title">Pitch 6 –<span class="length">35m</span> <span class="pitchGrade UIAA">IV</span></strong><br />Climb up the block slightly before crossing over to the main wall on good holds in an exposed an airy position. Make a rising traverse all the way out to the right edge, moving up past a niche on the right side (protected by a piton) to reach a belay on a good ledge. From the start of this pitch there will be 4 pocket looking niches higher up on the main wall, the climber is aiming to pass the right most of these on the right. <br /><strong class="pitch-title">Pitch 7 –<span class="length">50m</span> <span class="pitchGrade UIAA">IV</span></strong><br />This pitch is likely best broken into two. First traverse right to reach a scoop / shallow cave type structure. Climb up the right side on good holds before moving back left to a position broadly above the last belay at about 25m (depending where protection was placed). A belay point can be created here on using threads and natural protection. If climbing all the way to the summit plateau, head up on good holds, heading for a large pillar above. Move left behind the smaller block (in front of the large pillar) then right up a short chimney to reach the summit plateau which is protected by a bolted anchor. <br /><strong class="pitch-title">Pitch 8-10 –<span class="length">120m</span> <span class="pitchGrade UIAA">II to III</span></strong><br />There are multiple options to finish the route. The ground is loose under foot but the climbing / scrambling is easy. Essentially the line goes left around the tower before cutting back right and heading up to the cable car in roughly 3 pitches. Belays will need to be made using natural protection and threads. There is an option for a grade IV section on a short chimney after the tower. The cable car station is best approached on the left side climbing up and over the wall.	{"alt": "Via Maria Climb in the Dolomites on the South Face of Sass Pordoi", "url": "img/tiles/via-maria-climb-in-dolomites-sass-pordoi.jpg"}	{"alt": "Via Maria, Sass Pordoi in the Dolomites", "url": "img/topos/pordoi/via-maria-on-sass-pordoi-south-face-in-the-dolomites.jpg", "dataFile": 5, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "our own image"}	{"alt": "Via Maria Climb is on the Sass Pordoi face in the Dolomites", "url": "img/topos/pordoi/maps/"}	2021-10-15 01:01:43.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
273	283	Via Pany	draft	0101000020E6100000440F26F60F16B33F414063CB57514340	Europe/Madrid	\N	220	7	limestone	Slab & Vertical	N	UIAA	IV+	VS	4c	5	UNSPECIFIED	\N	\N	\N	\N	20	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Via Pany was the first climbing route established up Penon Ifach (in 1955) and is, to this day, the easiest climbing route to the summit. It sits on the North face so it is in shade until late in the day. The North face also has a climbing ban due to nesting birds in April, May and June. The route is around the UIAA grade IV+. Roughy hard serve but often graded very severe (VS) in UK guides. The route has some great pitches with a variety of different styles needed making it a very accessible and very enjoyable route. Whilst it’s still a serious climb it's much more forgiving than the south face routes like Diedro UBSA because Via Pany has less sun, less loose rock, less polish and less sustained climbing, it is nevertheless, very worthwhile with incredible views looking back over Calpe throughout the route.	<strong>Approach:</strong><br>Parking in Calpe and following the tourist path until under the climb would be recommended. There is a shorter scrappy scrambling path, used by climbers which cuts from the marina up to the tourist path avoiding the information center.<br><br><strong>Descent:</strong><br>The route finishes by the summit. From here follow the circuitous tourist path marked with large red dots. The path is very polished and slippery, so wearing good approach footwear is recommended.	<strong class="pitch-title">Pitch 1 – <span class="length">30m</span> <span class="pitchGrade uiaa">Grade IV</span></strong><br>Climb up the initial grove on the right hand side. Moving up and slightly left onto a block. Use both walls to gain the good handholds on the steep right hand wall and climb this until it eases and reaches a bolted belay.<br> <strong class="pitch-title">Pitch 2 – <span class="length">48m</span> <span class="pitchGrade uiaa">Grade III+</span></strong><br> Initially a long and easy scramble sticking to the rock while passing through vegetation. The pitch approaches another bigger gully on the left and a steeper wall in-front/to the right. A belay can be made below the steep wall or this can be climbed directly (probably more like IV) to reach a large ledge with a pair of bolts for the belay.<br> <strong class="pitch-title">Pitch 3 – <span class="length">25m</span> <span class="pitchGrade uiaa">Grade IV+</span></strong><br> A dog leg shaped pitch. Starting with easier moves up into a niche. This is passed with much harder moves to the right before moving up and doing a delicate traverse left to belay under the steeper overhang below the gully / chimney section. <br> <strong class="pitch-title">Pitch 4 – <span class="length">25m</span> <span class="pitchGrade uiaa">Grade IV+</span></strong><br>Probably the crux of the route, this pitch is sometimes given the higher grade of V. It climbs the chimney directly before moving onto the steep right wall and then onto a good ledge along to the belay.<br> <strong class="pitch-title">Pitch 5 – <span class="length">~25m</span> <span class="pitchGrade uiaa">Grade IV</span></strong><br>Move right stepping across a gap and moving around a corner, going up the slab to the belay.<br> <strong class="pitch-title">Pitch 6 – <span class="length">30m</span> <span class="pitchGrade uiaa">Grade IV+</span></strong><br>Climb a wonderful slab above the belay to a crack system. Pass a bolt at around 7m. Pass an orange bulge on the right and move up and left to belay on a pair of bolts.<br> <strong class="pitch-title">Pitch 7 – <span class="length">~30m</span> <span class="pitchGrade uiaa">IV+</span></strong><br>Climb leftwards with steep initial moves that ease as the pitch and route come to an end at the summit.	{"alt": "Peñón de Ifach rising out of Calpe offers great climbing on Via Pany", "url": "img/tiles/via-pany-costa-blanca.jpg"}	{"alt": "Via Pany on the face of Penon Ifach, Calpe", "url": "img/topos/penon-north/via-pany-topo.jpg", "dataFile": null, "atributionURL": "https://creativecommons.org/licenses/by-sa/4.0/", "attributionText": "Our own image"}	{"alt": "Costa Blanca climbing location", "url": "img/topos/penon-north/maps/"}	2026-07-17 11:24:00.997394+00	llm	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
281	290	Fedele	publish	0101000020E61000007BA01518B29A2740ED65DB696B404740	Europe/Rome	\N	555	16	dolomite	Vertical	NW	UIAA	IV+	HS	4a	4	UNSPECIFIED	\N	\N	\N	\N	45	2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	A superb and impressive route, often seen as the best climbs of its grade (UIAA IV+) in the Dolomites. The climb weaves its way along the edges of the large black water steak that dominates the face. This water that comes heavy in wetter months, has shaped the rock in to lots of clean jugs making the accent surprisingly easy for the steep face. Make sure you wait for a dry period to tackle this climb or you will have to deal with seepage or potentially a full on waterfall, especially on the higher pitches across the black streak. For those up to the challenge the Dibona Upper Wall provides the logical continuation. Combining the routes gives almost a kilometre of climbing up one of the most impressive faces of the Dolomites whilst never exceeding grade IV+.	Its possible to park at Ristorante Pian Schiavaneis (46.503278,11.802140). From there, head North and slightly East to Sass Pordoi. Start 50m left of the prominent black streak, directly below the huge boulder on the upper ledge. Climb easy scree and rocks to a scree basin where the climb starts.	\N	{"alt": "The Amazing Alpine Crag of Sass Pordoig", "url": "img/tiles/fedele-on-sass-pordoi-in-the-alps.jpg", "atributionURL": "https://pixabay.com/photos/sass-pordoi-sella-massif-2738856/", "attributionText": "Hans"}	{"alt": "Sass Pordoi Route Via Fedele Topo", "url": "img/topos/sass/sass-pordoi-via-fedele-topo-crop.jpg", "dataFile": null, "atributionURL": "https://pixabay.com/en/sass-pordoi-sella-massif-2738856/", "attributionText": "Pixabay"}	{"alt": "Map showing Sass Pordoi In the Dolomites", "url": "img/topos/sass/maps/"}	2021-10-15 01:01:42.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
283	217	The Devils Slide	publish	0101000020E6100000BF9A030473B412C0B9AAECBB22984940	Europe/London	\N	117	5	granite	Slab	W	BAS	HS 4a	HS	4a	4	UNSPECIFIED	\N	\N	\N	\N	120	3	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	The Devils slide was first climbed in the early 1960's. The face has been claimed to be the tallest granite slab in Europe. Whilst untrue, it is never the less one of the tallest slab climbs in England and certainly a must climb classic. It makes for an exceptional climb at an amenable grade. This popular route was climbed, or perhaps more accurately "walked", feet only by Jonny Dawes in 2017. Although Lundy (meaning Puffin Island in Norse) has climbing restrictions some of the year, the devils slide and a number of other areas are exempt. The slide doesn't have nesting birds, likely because it's so exposed, <span class="ILfuVd" lang="en"><span class="hgKElc">bear </span></span>that in mind when planning. To get to Lundy a ferry can be taken from Ilfracombe in Devon. The route climbs up the right-hand side of the slab following the groove. The last pitch takes an obvious traverse left under the headwall. Whilst originally 5 pitches of climbing, it can be done in as few as three with long ropes and careful runner placements. See references below for more info.	<strong>Approach</strong>: Getting to the Island is not straight forwards as the boats are not regular. Once there the sea cliff is a couple of hours walk from the harbour. From the top of the cliff descend down the southern gully. At least one short abseil is required to pass an outcrop. The Blocks at the bottom of the slide can be reached mid-tide and below. Care should be taken as Lundy and the Bristol channel in general has one of the largest tidal ranges in the world. <br>	\N	{"alt": "The Devils slide On Lundy", "url": "img/tiles/devils-slide-on-lundy.jpg", "atributionURL": "https://www.flickr.com/photos/geographyalltheway_photos/6843213186", "attributionText": "Richard Allaway"}	{"alt": "The Devils Slide Route Topography", "url": "img/topos/lundy/the-devils-slide-lundy-topo.jpg", "dataFile": 5, "atributionURL": "https://shadthecat.com/tag/lundy-island/", "attributionText": "Shadthecat"}	{"alt": "Map showing the location of the Tormore Sea Stacks", "url": "img/topos/lundy/maps/"}	2021-10-15 01:01:47.339+00	human	{"date": "2026-07-06", "model": "claude-cli"}	\N	f	\N
\.


--
-- Data for Name: route_character; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.route_character (route_id, character_code) FROM stdin;
1	sustained
1	exposed
2	technical
2	delicate
3	technical
5	powerful
5	sustained
6	exposed
7	exposed
7	sustained
8	sustained
8	pumpy
54	delicate
52	delicate
52	sustained
51	fingery
51	sustained
49	crimpy
49	exposed
49	sustained
49	technical
50	exposed
50	powerful
50	technical
15	fingery
15	powerful
13	powerful
14	technical
16	fingery
42	fingery
41	sustained
19	exposed
19	technical
27	exposed
27	sustained
29	exposed
29	technical
86	crimpy
86	delicate
86	technical
88	technical
94	sustained
92	exposed
92	technical
87	technical
60	technical
10	reachy
9	pumpy
67	fingery
63	sustained
69	fingery
69	sustained
62	technical
214	exposed
216	sustained
216	exposed
216	delicate
216	reachy
219	exposed
220	delicate
220	exposed
221	sustained
221	exposed
224	delicate
224	exposed
225	sustained
225	exposed
248	sustained
248	delicate
248	exposed
249	exposed
252	exposed
252	sustained
253	exposed
253	sustained
254	sustained
254	exposed
255	technical
256	crimpy
256	delicate
256	reachy
258	delicate
258	exposed
259	technical
259	exposed
260	technical
261	technical
261	delicate
265	exposed
266	technical
266	delicate
267	sustained
267	exposed
268	exposed
270	technical
270	crimpy
271	exposed
272	exposed
1051	delicate
1051	exposed
273	delicate
274	reachy
276	sustained
276	technical
276	exposed
277	technical
278	reachy
278	powerful
279	delicate
280	delicate
280	exposed
282	sustained
282	exposed
284	technical
250	sustained
250	technical
283	exposed
\.


--
-- Data for Name: route_climatology; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.route_climatology (route_id, month, rainy_days, temp_high, temp_low) FROM stdin;
7	8	9	14	4
7	7	9	14	4
8	8	6	30	19
8	7	6	30	19
1	1	20	8	5
1	2	17	7	5
1	3	20	8	5
1	4	16	9	6
1	5	15	11	8
1	6	14	13	10
1	7	15	15	12
1	8	17	15	13
1	9	17	14	11
1	10	20	12	9
1	11	19	10	7
1	12	17	8	6
214	1	16	8	6
214	2	12	8	6
214	3	13	10	7
214	4	11	11	8
214	5	10	15	11
214	6	10	16	13
214	7	11	19	15
214	8	11	19	16
214	9	11	17	14
214	10	16	14	11
214	11	16	11	8
214	12	15	8	6
215	1	19	6	4
215	2	15	7	4
215	3	18	8	5
215	4	13	10	7
215	5	12	13	10
215	6	13	15	12
215	7	14	17	13
215	8	15	17	14
215	9	16	15	12
215	10	19	12	9
215	11	19	9	6
215	12	18	7	5
216	1	4	13	4
216	2	4	14	4
216	3	5	16	6
216	4	6	19	9
216	5	5	22	12
216	6	3	26	17
216	7	2	28	19
216	8	4	29	19
216	9	5	26	16
216	10	5	22	13
216	11	4	17	8
216	12	4	13	4
217	1	19	8	2
217	2	15	8	2
217	3	16	10	3
217	4	13	12	5
217	5	13	15	7
217	6	13	17	10
217	7	15	18	12
217	8	16	18	12
217	9	15	16	10
217	10	17	13	8
217	11	19	10	5
217	12	18	9	3
218	1	15	9	5
218	2	12	9	5
218	3	11	9	6
218	4	10	13	9
218	5	9	16	11
218	6	9	16	11
218	7	8	18	13
218	8	9	18	14
218	9	9	16	12
218	10	12	14	10
218	11	14	11	8
218	12	15	10	7
219	1	4	4.2	-7.8
219	2	6	4.7	-7.4
219	3	8	8.6	-4.2
219	4	10	12.7	-0.7
219	5	12	18.2	4.6
219	6	11	24.1	9.4
219	7	10	28.6	13.1
219	8	11	27.3	12.3
219	9	8	22.1	7.1
219	10	7	14.9	1.1
219	11	6	8.1	-4.3
219	12	6	3.4	-8.2
220	1	13	8	3
220	2	10	8	2
220	3	11	9	3
220	4	9	12	4
220	5	8	15	7
220	6	8	17	10
220	7	8	19	12
220	8	9	18	12
220	9	10	17	10
220	10	14	13	8
220	11	14	10	5
220	12	14	8	3
221	1	15	-8	-15
221	2	15	-8	-14
221	3	17	-6	-13
221	4	15	-2	-9
221	5	17	3	-4
221	6	17	6	-1
221	7	16	9	2
221	8	18	8	1
221	9	19	5	-2
221	10	19	-1	-6
221	11	15	-5	-10
221	12	16	-7	-13
222	1	17	7	2
222	2	13	7	2
222	3	16	9	3
222	4	13	12	4
222	5	12	15	7
222	6	12	18	9
222	7	13	19	11
222	8	14	19	11
222	9	14	17	9
222	10	18	13	7
222	11	18	10	4
222	12	17	8	2
223	1	9	-10	-15
223	2	7	-6	-11
223	3	9	-3	-8
223	4	9	-2	-8
223	5	11	2	-3
223	6	13	12	5
223	7	13	15	7
223	8	11	14	7
223	9	9	9	3
223	10	6	5	-1
223	11	8	-4	-8
223	12	7	-10	-14
224	1	15	9	5
224	2	12	9	5
224	3	11	9	6
224	4	10	13	9
224	5	9	16	11
224	6	9	16	11
224	7	8	18	13
224	8	9	18	14
224	9	9	16	12
224	10	12	14	10
224	11	14	11	8
224	12	15	10	7
225	1	18	5	0
225	2	15	5	0
225	3	17	7	1
225	4	16	9	2
225	5	14	12	4
225	6	14	15	7
225	7	15	16	9
225	8	14	16	9
225	9	14	14	7
225	10	18	10	5
225	11	18	7	2
225	12	20	5	0
247	1	6	18	14
247	2	9	18	14
247	3	10	21	17
247	4	11	25	20
247	5	15	28	24
247	6	19	30	26
247	7	17	31	27
247	8	17	31	26
247	9	14	30	25
247	10	8	28	23
247	11	6	24	19
247	12	4	20	15
248	1	4	15	6
248	2	3	16	6
248	3	4	18	8
248	4	4	19	10
248	5	4	23	13
248	6	2	27	17
248	7	1	29	20
248	8	1	29	21
248	9	3	27	18
248	10	4	24	14
248	11	4	18	9
248	12	4	16	7
249	1	5	12	4
249	2	6	13	4
249	3	5	15	6
249	4	5	19	9
249	5	5	25	14
249	6	3	29	19
249	7	2	32	22
249	8	2	32	22
249	9	2	27	18
249	10	5	22	14
249	11	6	17	9
249	12	6	13	6
250	1	6	1	-9
250	2	5	2	-8
250	3	5	7	-5
250	4	7	9	-3
250	5	5	14	1
250	6	4	18	4
250	7	2	21	7
250	8	2	21	7
250	9	4	16	3
250	10	7	11	0
250	11	6	5	-5
250	12	6	1	-8
251	1	10	-1	-7
251	2	10	-1	-8
251	3	12	2	-5
251	4	14	6	-2
251	5	16	10	1
251	6	17	12	5
251	7	17	15	7
251	8	16	16	8
251	9	13	13	4
251	10	10	10	1
251	11	11	3	-4
251	12	12	-1	-6
252	1	9	-7	-18
252	2	7	-4	-15
252	3	10	2	-11
252	4	10	5	-7
252	5	12	10	-3
252	6	14	14	0
252	7	15	16	2
252	8	14	15	2
252	9	10	10	-2
252	10	7	4	-7
252	11	9	-3	-13
252	12	9	-7	-17
253	1	4	15	5
253	2	4	16	5
253	3	4	18	7
253	4	4	21	9
253	5	4	24	13
253	6	2	29	17
253	7	0	31	19
253	8	1	32	20
253	9	2	28	17
253	10	4	23	14
253	11	5	18	9
253	12	4	16	6
254	1	13	7	1.6
254	2	9	7.3	1.5
254	3	11	9.6	2.8
254	4	9	12.7	4.9
254	5	8	16	7.7
254	6	8	19.2	10.7
254	7	7	20.7	12.2
254	8	8	20.2	12
254	9	9	17.7	10
254	10	11	14.1	7.4
254	11	10	9.7	4
254	12	11	7.9	2.5
255	1	13	8	3
255	2	10	8	2
255	3	11	9	3
255	4	9	12	4
255	5	8	15	7
255	6	8	17	10
255	7	8	19	12
255	8	9	18	12
255	9	10	17	10
255	10	14	13	8
255	11	14	10	5
255	12	14	8	3
256	1	13	8	3
256	2	9	8	3
256	3	11	11	5
256	4	9	13	6
256	5	8	17	9
256	6	8	19	12
256	7	7	22	14
256	8	8	21	14
256	9	9	18	12
256	10	11	15	9
256	11	10	11	6
256	12	11	9	4
257	1	13	5	1
257	2	11	6	1
257	3	10	10	3
257	4	8	14	5
257	5	15	18	9
257	6	12	21	12
257	7	11	23	13
257	8	12	23	13
257	9	12	19	11
257	10	10	14	7
257	11	12	9	4
257	12	13	6	1
258	1	9	0	-8
258	2	8	5	-7
258	3	9	9	-2
258	4	10	13	2
258	5	13	18	6
258	6	16	22	9
258	7	15	23	11
258	8	15	22	10
258	9	11	20	8
258	10	10	15	2
258	11	11	6	-2
258	12	10	0	-7
259	1	20	5	2
259	2	14	5	2
259	3	15	5	2
259	4	13	7	4
259	5	11	10	6
259	6	10	12	8
259	7	10	14	10
259	8	12	14	10
259	9	14	11	8
259	10	17	9	7
259	11	20	7	4
259	12	19	5	3
260	1	4	16.2	2.4
260	2	3	17.7	3.7
260	3	4	19.8	6.7
260	4	3	22.5	9.1
260	5	2	24.3	11.5
260	6	2	27.3	13.9
260	7	2	31.3	17.4
260	8	2	31.1	18
260	9	3	28	15.3
260	10	3	24.2	11.5
260	11	5	19.9	7.5
260	12	6	16.4	3.7
261	1	4	19	11
261	2	3	20	12
261	3	4	21	13
261	4	3	21	14
261	5	1	22	15
261	6	1	22	16
261	7	1	23	17
261	8	1	24	18
261	9	2	24	17
261	10	2	23	16
261	11	4	22	15
261	12	4	20	12
262	1	4	16.2	2.4
262	2	3	17.7	3.7
262	3	4	19.8	6.7
262	4	3	22.5	9.1
262	5	2	24.3	11.5
262	6	2	27.3	13.9
262	7	2	31.3	17.4
262	8	2	31.1	18
262	9	3	28	15.3
262	10	3	24.2	11.5
262	11	5	19.9	7.5
262	12	6	16.4	3.7
263	1	4	16.2	2.4
263	2	3	17.7	3.7
263	3	4	19.8	6.7
263	4	3	22.5	9.1
263	5	2	24.3	11.5
263	6	2	27.3	13.9
263	7	2	31.3	17.4
263	8	2	31.1	18
263	9	3	28	15.3
263	10	3	24.2	11.5
263	11	5	19.9	7.5
263	12	6	16.4	3.7
264	1	6	6	-1
264	2	6	9	1
264	3	6	14	5
264	4	8	19	10
264	5	8	24	14
264	6	8	28	18
264	7	6	31	20
264	8	5	30	19
264	9	5	25	15
264	10	5	19	10
264	11	7	12	5
264	12	6	8	1
265	1	16	8	4
265	2	13	8	4
265	3	8	9	5
265	4	12	12	6
265	5	10	15	9
265	6	13	18	12
265	7	9	19	14
265	8	12	19	14
265	9	9	17	12
265	10	15	14	10
265	11	16	11	7
265	12	15	9	5
266	1	18	5	0
266	2	15	5	0
266	3	17	7	1
266	4	16	9	2
266	5	14	12	4
266	6	14	15	7
266	7	15	16	9
266	8	14	16	9
266	9	14	14	7
266	10	18	10	5
266	11	18	7	2
266	12	20	5	0
267	1	4	5	-6
267	2	4	8	-3
267	3	5	14	1
267	4	7	18	4
267	5	10	22	8
267	6	9	26	12
267	7	9	28	14
267	8	9	26	14
267	9	6	18	10
267	10	6	18	5
267	11	6	10	0
267	12	4	6	-5
268	1	4	5	-6
268	2	4	8	-3
268	3	5	14	1
268	4	7	18	4
268	5	10	22	8
268	6	9	26	12
268	7	9	28	14
268	8	9	26	14
268	9	6	18	10
268	10	6	18	5
268	11	6	10	0
268	12	4	6	-5
269	1	3	14	9
269	2	3	14	9
269	3	3	16	11
269	4	4	17	13
269	5	4	20	16
269	6	2	24	20
269	7	1	27	23
269	8	1	27	23
269	9	3	25	21
269	10	4	22	18
269	11	4	18	13
269	12	4	15	11
270	1	9	8	3
270	2	9	8	2
270	3	8	9	3
270	4	9	12	4
270	5	11	15	7
270	6	9	17	10
270	7	9	19	12
270	8	9	18	12
270	9	8	17	10
270	10	11	13	8
270	11	14	10	5
270	12	12	8	3
271	1	13	8	3
271	2	10	8	2
271	3	11	9	3
271	4	9	12	4
271	5	8	15	7
271	6	8	17	10
271	7	8	19	12
271	8	9	18	12
271	9	10	17	10
271	10	14	13	8
271	11	14	10	5
271	12	14	8	3
272	1	4	15	6
272	2	3	16	6
272	3	4	18	8
272	4	4	19	10
272	5	4	23	13
272	6	2	27	17
272	7	1	29	20
272	8	1	29	21
272	9	3	27	18
272	10	4	24	14
272	11	4	18	9
272	12	4	16	7
273	1	4	15	6
273	2	3	16	6
273	3	4	18	8
273	4	4	19	10
273	5	4	23	13
273	6	2	27	17
273	7	1	29	20
273	8	1	29	21
273	9	3	27	18
273	10	4	24	14
273	11	4	18	9
273	12	4	16	7
274	1	18	5	0
274	2	15	5	0
274	3	17	7	1
274	4	16	9	2
274	5	14	12	4
274	6	14	15	7
274	7	15	16	9
274	8	14	16	9
274	9	14	14	7
274	10	18	10	5
274	11	18	7	2
274	12	20	5	0
275	1	19	8	2
275	2	15	8	2
275	3	16	10	3
275	4	13	12	5
275	5	13	15	7
275	6	13	17	10
275	7	15	18	12
275	8	16	18	12
275	9	15	16	10
275	10	17	13	8
275	11	19	10	5
275	12	18	9	3
276	1	18	5	0
276	2	15	5	0
276	3	17	7	1
276	4	16	9	2
276	5	14	12	4
276	6	14	15	7
276	7	15	16	9
276	8	14	16	9
276	9	14	14	7
276	10	18	10	5
276	11	18	7	2
276	12	20	5	0
277	1	4	15	6
277	2	3	16	6
277	3	4	18	8
277	4	4	19	10
277	5	4	23	13
277	6	2	27	17
277	7	1	29	20
277	8	1	29	21
277	9	3	27	18
277	10	4	24	14
277	11	4	18	9
277	12	4	16	7
278	1	13	8	3
278	2	10	8	2
278	3	11	9	3
278	4	9	12	4
278	5	8	15	7
278	6	8	17	10
278	7	8	19	12
278	8	9	18	12
278	9	10	17	10
278	10	14	13	8
278	11	14	10	5
278	12	14	8	3
279	1	4	15	6
279	2	3	16	6
279	3	4	18	8
279	4	4	19	10
279	5	4	23	13
279	6	2	27	17
279	7	1	29	20
279	8	1	29	21
279	9	3	27	18
279	10	4	24	14
279	11	4	18	9
279	12	4	16	7
280	1	18	5	0
280	2	15	5	0
280	3	17	7	1
280	4	16	9	2
280	5	14	12	4
280	6	14	15	7
280	7	15	16	9
280	8	14	16	9
280	9	14	14	7
280	10	18	10	5
280	11	18	7	2
280	12	20	5	0
281	1	4	5	-6
281	2	4	8	-3
281	3	5	14	1
281	4	7	18	4
281	5	10	22	8
281	6	9	26	12
281	7	9	28	14
281	8	9	26	14
281	9	6	18	10
281	10	6	18	5
281	11	6	10	0
281	12	4	6	-5
282	1	13	8	3
282	2	10	8	2
282	3	11	9	3
282	4	9	12	4
282	5	8	15	7
282	6	8	17	10
282	7	8	19	12
282	8	9	18	12
282	9	10	17	10
282	10	14	13	8
282	11	14	10	5
282	12	14	8	3
283	1	15	8	5
283	2	11	7	5
283	3	13	8	6
283	4	11	10	7
283	5	10	12	9
283	6	9	15	12
283	7	10	17	14
283	8	11	17	14
283	9	11	15	13
283	10	16	13	11
283	11	16	11	8
283	12	15	9	7
284	1	15	9	0
284	2	12	10	1
284	3	15	13	2
284	4	10	15	4
284	5	11	19	7
284	6	7	23	11
284	7	3	28	13
284	8	5	28	13
284	9	7	23	11
284	10	12	18	7
284	11	14	12	3
284	12	17	9	1
\.


--
-- Data for Name: route_discipline; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.route_discipline (route_id, discipline_code) FROM stdin;
1	trad
2	trad
4	trad
6	trad
7	trad
8	trad
1	multi-pitch
2	multi-pitch
4	multi-pitch
6	multi-pitch
7	multi-pitch
8	multi-pitch
3	trad
5	trad
3	single-pitch
5	single-pitch
6	alpine
7	alpine
257	mixed
257	multi-pitch
257	trad
264	aid
264	multi-pitch
264	trad
223	multi-pitch
223	trad
256	multi-pitch
256	trad
224	multi-pitch
224	trad
218	multi-pitch
218	trad
214	multi-pitch
214	trad
222	multi-pitch
222	trad
254	multi-pitch
254	trad
283	multi-pitch
283	trad
250	alpine
250	multi-pitch
250	sport
250	trad
249	multi-pitch
249	sport
249	trad
247	multi-pitch
247	trad
217	multi-pitch
217	trad
275	multi-pitch
275	trad
252	alpine
252	multi-pitch
252	trad
281	alpine
281	multi-pitch
281	trad
258	alpine
258	multi-pitch
258	trad
267	alpine
267	multi-pitch
267	trad
268	alpine
268	multi-pitch
268	trad
262	multi-pitch
262	trad
263	multi-pitch
263	trad
260	multi-pitch
260	trad
261	multi-pitch
261	trad
155	multi-pitch
155	trad
54	multi-pitch
54	trad
157	multi-pitch
157	trad
153	multi-pitch
153	trad
156	multi-pitch
156	trad
52	multi-pitch
52	trad
55	multi-pitch
55	trad
154	multi-pitch
154	trad
47	multi-pitch
47	trad
51	multi-pitch
51	trad
53	multi-pitch
53	trad
49	multi-pitch
49	trad
56	multi-pitch
56	trad
48	multi-pitch
48	trad
50	multi-pitch
50	trad
105	multi-pitch
105	trad
106	multi-pitch
106	trad
102	multi-pitch
102	trad
103	multi-pitch
103	trad
104	multi-pitch
104	trad
108	multi-pitch
108	trad
107	multi-pitch
107	trad
115	multi-pitch
115	trad
120	multi-pitch
120	trad
119	multi-pitch
119	trad
113	multi-pitch
113	trad
116	multi-pitch
116	trad
121	multi-pitch
121	trad
117	multi-pitch
117	trad
118	multi-pitch
118	trad
114	multi-pitch
114	trad
15	multi-pitch
15	trad
13	multi-pitch
13	trad
14	multi-pitch
14	trad
16	multi-pitch
16	trad
17	multi-pitch
17	trad
11	multi-pitch
11	trad
12	multi-pitch
12	trad
18	multi-pitch
18	trad
44	multi-pitch
44	trad
45	multi-pitch
45	trad
40	multi-pitch
40	trad
43	multi-pitch
43	trad
42	multi-pitch
42	trad
46	multi-pitch
46	trad
41	multi-pitch
41	trad
110	multi-pitch
110	trad
130	multi-pitch
130	trad
129	multi-pitch
129	trad
134	multi-pitch
134	trad
132	multi-pitch
132	trad
124	multi-pitch
124	trad
127	multi-pitch
127	trad
133	multi-pitch
133	trad
122	multi-pitch
122	trad
123	multi-pitch
123	trad
135	multi-pitch
135	trad
126	multi-pitch
126	trad
131	multi-pitch
131	trad
125	multi-pitch
125	trad
136	multi-pitch
136	trad
128	multi-pitch
128	trad
21	multi-pitch
21	trad
24	multi-pitch
24	trad
19	multi-pitch
19	trad
20	multi-pitch
20	trad
23	multi-pitch
23	trad
22	multi-pitch
22	trad
27	multi-pitch
27	trad
26	multi-pitch
26	trad
31	multi-pitch
31	trad
29	multi-pitch
29	trad
30	multi-pitch
30	trad
32	multi-pitch
32	trad
28	multi-pitch
28	trad
33	multi-pitch
33	trad
25	multi-pitch
25	trad
192	multi-pitch
192	trad
174	multi-pitch
174	trad
184	multi-pitch
184	trad
172	multi-pitch
172	trad
173	multi-pitch
173	trad
179	multi-pitch
179	trad
185	multi-pitch
185	trad
187	multi-pitch
187	trad
190	multi-pitch
190	trad
189	multi-pitch
189	trad
183	multi-pitch
183	trad
181	multi-pitch
181	trad
175	multi-pitch
175	trad
191	multi-pitch
191	trad
178	multi-pitch
178	trad
177	multi-pitch
177	trad
186	multi-pitch
186	trad
193	multi-pitch
193	trad
188	multi-pitch
188	trad
176	multi-pitch
176	trad
180	multi-pitch
180	trad
182	multi-pitch
182	trad
93	multi-pitch
93	trad
83	multi-pitch
83	trad
78	multi-pitch
78	trad
77	multi-pitch
77	trad
84	multi-pitch
84	trad
86	multi-pitch
86	trad
90	multi-pitch
90	trad
88	multi-pitch
88	trad
82	multi-pitch
82	trad
80	multi-pitch
80	trad
94	multi-pitch
94	trad
91	multi-pitch
91	trad
92	multi-pitch
92	trad
76	multi-pitch
76	trad
85	multi-pitch
85	trad
89	multi-pitch
89	trad
95	multi-pitch
95	trad
87	multi-pitch
87	trad
79	multi-pitch
79	trad
81	multi-pitch
81	trad
59	multi-pitch
59	trad
61	multi-pitch
61	trad
57	multi-pitch
57	trad
60	multi-pitch
60	trad
58	multi-pitch
58	trad
200	multi-pitch
200	trad
201	multi-pitch
201	trad
202	multi-pitch
202	trad
196	multi-pitch
196	trad
203	multi-pitch
203	trad
197	multi-pitch
197	trad
204	multi-pitch
204	trad
198	multi-pitch
198	trad
109	multi-pitch
109	trad
199	multi-pitch
199	trad
10	multi-pitch
10	trad
9	multi-pitch
9	trad
71	multi-pitch
71	trad
66	multi-pitch
66	trad
73	multi-pitch
73	trad
68	multi-pitch
68	trad
75	multi-pitch
75	trad
72	multi-pitch
72	trad
67	multi-pitch
67	trad
70	multi-pitch
70	trad
63	multi-pitch
63	trad
74	multi-pitch
74	trad
65	multi-pitch
65	trad
69	multi-pitch
69	trad
62	multi-pitch
62	trad
64	multi-pitch
64	trad
97	multi-pitch
97	trad
100	multi-pitch
100	trad
101	multi-pitch
101	trad
96	multi-pitch
96	trad
98	multi-pitch
98	trad
99	multi-pitch
99	trad
35	multi-pitch
35	trad
36	multi-pitch
36	trad
34	multi-pitch
34	trad
39	multi-pitch
39	trad
37	multi-pitch
37	trad
38	multi-pitch
38	trad
225	multi-pitch
225	trad
274	multi-pitch
274	trad
280	multi-pitch
280	trad
276	multi-pitch
276	trad
266	multi-pitch
266	trad
221	alpine
221	multi-pitch
221	trad
284	multi-pitch
284	sport
284	trad
215	multi-pitch
215	trad
259	multi-pitch
259	trad
277	multi-pitch
277	trad
216	mixed
216	multi-pitch
216	trad
248	multi-pitch
248	sport
248	trad
273	multi-pitch
273	trad
272	multi-pitch
272	trad
253	multi-pitch
253	trad
279	multi-pitch
279	trad
269	multi-pitch
269	trad
251	multi-pitch
251	sport
251	trad
219	multi-pitch
219	trad
271	multi-pitch
271	trad
278	multi-pitch
278	trad
265	multi-pitch
265	trad
255	multi-pitch
255	trad
282	multi-pitch
282	trad
270	multi-pitch
270	sport
270	trad
220	multi-pitch
220	trad
\.


--
-- Data for Name: route_feature; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.route_feature (route_id, feature_code) FROM stdin;
1	face
1	crack
2	slab
3	crack
3	corner
4	slab
5	crack
5	corner
6	pillar
6	ridge
7	corner
7	face
8	groove
8	face
54	chimney
54	corner
54	crack
54	flake
54	groove
54	pillar
52	corner
52	crack
52	flake
52	pillar
51	chimney
51	crack
51	groove
49	corner
49	crack
49	groove
49	roof
50	chimney
50	corner
50	crack
50	groove
50	roof
105	corner
105	groove
102	corner
103	chimney
104	corner
104	crack
15	corner
15	crack
15	flake
13	offwidth
14	crack
16	crack
11	corner
11	crack
11	groove
11	slab
18	corner
18	crack
42	crack
42	groove
46	groove
41	corner
41	crack
41	groove
41	offwidth
41	roof
24	chimney
24	pillar
19	roof
20	groove
20	offwidth
27	corner
27	crack
27	flake
27	groove
27	roof
29	corner
29	crack
29	groove
29	pillar
29	roof
77	corner
84	groove
86	corner
86	crack
86	roof
90	groove
90	roof
88	arête
88	corner
88	crack
88	groove
88	pillar
88	roof
82	arête
94	crack
94	flake
94	groove
91	arête
91	groove
91	roof
92	arête
92	crack
92	groove
89	arête
89	corner
89	roof
95	groove
87	corner
79	chimney
81	arête
81	corner
81	groove
81	slab
61	corner
61	crack
61	flake
61	groove
61	roof
60	chimney
60	crack
109	crack
109	groove
109	offwidth
109	pillar
10	corner
10	face
10	slab
9	crack
9	groove
9	slab
66	crack
66	flake
66	groove
66	slab
68	corner
68	crack
68	groove
67	crack
67	flake
67	groove
70	chimney
63	crack
69	crack
69	flake
69	groove
62	crack
62	groove
62	roof
64	corner
64	crack
64	groove
64	slab
96	arête
98	face
99	arête
36	corner
36	crack
36	roof
34	crack
39	groove
37	crack
1051	crack
1051	corner
1051	arête
214	slab
214	arête
214	ridge
214	crack
214	pillar
215	ridge
216	slab
216	face
216	ridge
216	pockets
216	pillar
217	slab
218	crack
218	corner
218	slab
218	face
219	offwidth
219	crack
219	chimney
220	slab
220	groove
221	pillar
221	ridge
222	slab
222	groove
223	slab
223	corner
224	crack
224	corner
225	crack
225	slab
225	corner
248	corner
248	crack
248	chimney
248	slab
248	roof
248	pockets
249	pillar
251	slab
251	face
252	arête
252	ridge
252	crack
252	flake
253	offwidth
253	crack
253	corner
253	groove
253	arête
253	face
254	crack
254	slab
254	chimney
254	groove
255	slab
255	corner
256	crack
256	corner
256	flake
257	arête
257	face
259	face
259	crack
260	slab
260	crack
260	corner
260	groove
260	flake
261	slab
261	crack
261	corner
261	flake
262	slab
262	crack
262	pillar
262	roof
263	slab
263	crack
263	corner
263	groove
263	pillar
263	face
263	roof
264	face
265	ridge
265	arête
265	crack
265	groove
266	slab
266	ridge
266	crack
266	corner
267	face
267	slab
267	crack
267	chimney
267	pillar
267	roof
268	crack
268	chimney
268	corner
268	arête
269	face
269	crack
269	ridge
269	arête
269	corner
269	groove
269	pillar
270	slab
270	crack
270	arête
270	face
271	ridge
271	arête
271	chimney
271	slab
271	face
272	slab
272	arête
272	crack
272	ridge
272	groove
273	groove
273	slab
273	crack
273	chimney
273	corner
273	face
273	roof
274	chimney
274	crack
274	groove
275	ridge
276	crack
276	corner
276	flake
276	roof
277	groove
277	arête
277	corner
277	slab
278	arête
278	groove
278	corner
278	slab
278	crack
278	pillar
279	arête
279	crack
279	slab
280	slab
280	crack
280	arête
280	corner
280	roof
280	offwidth
281	face
282	slab
282	crack
282	corner
282	groove
284	slab
284	face
283	slab
283	groove
\.


--
-- Data for Name: route_grade; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.route_grade (route_id, grade_system_code, value) FROM stdin;
\.


--
-- Data for Name: route_guidebook; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.route_guidebook (route_id, guidebook_id, page, description) FROM stdin;
1	23	266	A brilliant book covering such a wide and varied set of crags in the north of Scotland. The section on The Old Man of Stoer Routes is good. The images of longer routes and indeed this sea stack can be a bit small. Some of the descriptions are also a little lacking on longer routes.
214	1	128	This is a great example of a guidebook. This guide covers a huge mix of regions in the south west with clear images and good topography. Especially for Conakey Cliff and the Clum Coast.
214	2	187	South West climbs by Pat Littlejohn is a traditional guidebook. It has decent route descriptions and information. The guide covers a great range of climbing areas in the south west of England. Although it covers Cornakey Cliff and the Wreakers Slab climb, it lacks detail for this area and the route. The guidebook is, for the most part, printed in black and white and the photos and diagrams are not up to the standard of more recent guidebooks. For a traditional overview of rock climbing in the southwest it’s fine. For Cornakey Cliff, it lists a few climbs with high level detail and is not super helpful.
215	3	32	An extensive and well-made guidebook covering every worthwhile crag in Southern Scotland. The guides are clear with generally very good photography, however some of the longer routes lack the clear imagery of their single pitch counterparts.
216	4	162	A huge selection of over a thousand routes many of which are big wall multi-pitch climbs. Montserrat is well bolted area but many routes require a full trad rack. The book has some good topography but lacks details when to comes to the approach. The book is a tome of information but not brilliantly organised for such a recent publication. It is also at the more expensive end of guidebook prices, but can be purchased cheaper from mainland Europe.
217	5	80	A very comprehensive guide to Climbing Irelands North West County of Donegal. Author Iain Miller is a very accomplished climber and set many of the first accents in the book. The book is great value for money, however if you are on a budget, much of the material is posted free on Iain Millers Website uniqueascent.ie
218	1	258	This book comes into its own for so many areas in the south west of Britain. This guide covers a huge mix of regions with clear images and good topography. The section on Chair Ladder is brilliant covers a great mix of multi-pitch routes across the grades.
218	2	261	As a traditional guidebook, South West climbs by Pat Littlejohn has good route descriptions and information. The book covers climbing in the south west of England. The book has good maps making an approach easier. The guide does have a photo topography for the route Pegasus, however neither the photo or description would make route finding easy on this sea cliff.
219	6	?	Rock Climbing Wyoming describes 11 major climbing areas in the state of Wyoming. It offers approximately 550 climbing routes. Falcon guides have maps, good topos, and action photos accompanying clearly written descriptions of the routes. The book is ideal for a trip to Wyoming, but enough of the information on the devils tower is available online for those looking to save some money.
220	7	156	A brilliant guidebok with a good section on Lliwedd. Overall this book covers a good selection of climbs from a good selection of cliffs, including the 300m routes up Lliwedd
220	8	34	You would imagine a climbing guide dedicated to Lliwedd would be perfect for climbing this Welsh Mountain crag. Kelvin Neal’s 4th edition of this guidebook certainly offers and good amount of detail (95 pages) and it comes in a small portable format. However, that’s where the positive points end.  Like most Climbers Climb guides, it focuses on text-based descriptions with little or no imagery. If you are looking for a very loose suggestion of where to go, when climbing almost 1,000 feet, this book might suite. And yes, despite the fourth edition being published in 1998 it still uses the imperial system of feet. Fun fact: The original first edition was published in 1909 and was one of the first guidebooks to ever be published!  To summarise, it’s not going to be hugely helpful with route finding, but it’s a cheap enough guidebook with good historical relevance.
221	9	354	This covers rock climbing on Lofoten and Stetind in Arctic Norway. A great publication from Rockfax with clear topography and good information. The patronising puffin that appears on certain pages with silly comments does somewhat detract from the professional quality of the book but I’m sure it appeals to some. Overall an essential guidebook for people looking to climb in this part of the world and great value for money.
222	10	\N	The FRCC Scafell and Wasdale Climbing guidebook was released in April 2014, 100 years after the first ascent of Central Buttress on Scafell Crag. The Centenary Edition guide is full of inspirational climbs often with great history. The pocket sized nature of the book makes it portable but somewhat less practical for route finding. The BMC super zoom is more useful for Scafell Crag if you are a visual person.
223	11	327	The Canadian Rock: Select Climbs of the West guide documents more than 1200 rock climbs across Western Canada, and in full-colour brings together into a single collection the best climbs in Western Canada, from Squamish to Lake Louise, to the Ghost River Valley. It has a good two page spread on the climb Joy. It can be light on details for some of the longer climbs but overall a great guidebook.
224	1	206	This is a great example of why I believe Rockfax are one of the world’s leading guidebook publishers. This guide covers a huge mix of regions in the south west with clear images and good topography. Especially for Bosigran.
224	12	129	Ken Wilson's Classic Rock is one of the most popular and iconic works of climbing literature ever written. First published in 1978, Classic Rock represented the absolute best of British climbing at that time, and to this day highlights the best climbing in Great Britain, covering 80 routes up to the grade of Hard Severe or Mild Very severe.  The book is more of a coffee table book than a guidebook in the traditional sense. It brings each route to life through a superb selection of photographs, anecdotes and essays from some of the most accomplished climbers of the day. This book covers the route Doorpost at Bosigran in great detail over 6 pages of inspiring photography and great detail.  The route topography is small but the book in general is exceptional, as is the second book Hard Rock.
225	13	129	This book is a very comprehensive guide to trad climbing in the Mourne Mountains. A worthwile book if you're there for a while, however the generic Rock Climbing in Ireland Book will cover you if you only plan a fleeting visit.
247	4	4	This publicly availible guidebook is so clear and comprehensive that I almost didn't bother adding Lion Rock to this website because its covered in far better detail in this guide.
248	14	267	A good book covering a wide and varied set of crags in sunny Spain. This Rockfax guide covers the climbs around Calpe including Diedre UBSA and many others. A great book for the multi-pitch climber with a penchant for trad. Peñón de Ifach is covered in good detail. However, for this route rockfax seems to under grade a lot of the pitches (compared to local guides - see references). The guide also suggests the route is HVS 5c. It seems Rockfax have accidentally combined the British HVS with the European grade 5c for some reason.
248	15	239	A new 2025 guidebook covering many of the best climbs in the Alacant region of Spain including Peñón de Ifach and Diedro U.B.S.A.. The book is in Spanish but has clear topos and good local route information. The book is ideal for those who like longer routes that need a trad rack to protect them. This is a very well produced guidebook, head and shoulders better than the english language guides. If you can't read Spanish, Google lens does a good enough job translating pages.
249	16	410	An old book presumably aimed at American climbers, however its truly brilliant can be picked up cheap. Described as the authoritative guide to the best climbing destinations in Western Europe, including Great Britain, France, Belgium, Spain, Italy, Switzerland, Greece, Germany, and Norway. The route topos are although black and white are accompanied by good route descriptions, equipment recommendations, and accurate route ratings. The book contains a good mixture of Trad and sport across single and multi-pitch climbs. Its basically a thick A4 book thou so not practical to take to the cliff. Highly recommended.
249	17	157	The book is in French and English and covers regions around the world. The book has clear photo topographies of most routes and good descriptions including gear recommendations. The book covers trad, sport and mixed protection routes like Traumpfeiler. The only issue is, its not a cheap book, but it's well designed and tends to cover harder longer routes with most graded TD / ED alpine grades which is low to mid E grades in the British system, i.e. serious climbs.
250	18	34	I want to recommend this guidebook but I just can’t. In some ways it’s brilliant, the hand drawn topos are very artistic, the book has 3 languages and it takes the approach of highlighting the best climbs on the cliff, much like the approach we have taken on multi-pitch.com. Sadly, a lot of the photography is poor to terrible. The “action” shots are from the belay to the leader or second, so give little in the way of inspiration and many of the mountain images are blurry silhouettes.  In addition, the images of the mountains are often just a third of the page. In this pocket-sized book, it means a 400m climb could be reduced to the size of your thumbnail. The final issue is the price which seem to be around £40.
251	18	300	I want to recommend this guidebook but I just can’t. In some ways it’s brilliant, the hand drawn topos are very artistic, the book has 3 languages and it takes the approach of highlighting the best climbs on the cliff, much like the approach we have taken on multi-pitch.com. Sadly, a lot of the photography is poor to terrible. The “action” shots are from the belay to the leader or second, so give little in the way of inspiration and many of the mountain images are blurry silhouettes.  In addition, the images of the mountains are often just a third of the page. In this pocket-sized book, it means a 400m climb could be reduced to the size of your thumbnail. The final issue is the price which seem to be around £40.
252	19	86	This guide covers everything you need for a multi-pitch climbing trip regardless of ability, it covers sport, trad and via ferrata routes. It features all the major areas and has very clear topos and route descriptions including the Catinaccio / Rosengarten region where the Vajolet Towers are located in the Alps. That said the guidebook has a surprisingly large number of mistakes throughout, including the description and route topography for the Piaz Arête climb on the Delago Tower that don't seem to match the polished line of the route or other local guidebooks.
252	20	54	This Italian language guidebook combines clear imagery with exquisitely detailed and accurate hand drawn route topography along with descriptions. The book is so well made it’s clear and usable even without being able to understand Italian. The book covers the Catinaccio region in good detail. The book will be hard to purchase outside Italy, but at the time of writing, the nearby Rifugio has a copy in the restaurant for guests to read. The books topo of the Vajolet Towers is the clearest of any guide.
254	21	101	The guidebook <em>Lower Wye Valley: Climbers' Club Guides to the Wye Valley and Forest of Dean</em> has a good amount of information and climbs. The photos are, for the most part very clear. However, the way the book is organised makes it difficult to use. In true climber’s club style, there are no route numbers on the descriptions or page references on the photo topos, making it slow to find the details. When you do find the climb details, they use complex language and terminology, making it hard to understand. Unfortunately, there are not any other guidebook options for Wintour’s Leap. All things said, the guidebook is not too expensive a must for getting the most out of the area.
255	7	149	If you could only own one book on multi-pitch climbing in the UK this book would be a great choice. North wales has pleanty of Trad climbs above 50m. The book covers a good selection of climbs on each crag including Cloggy.
256	1	53	This guide covers a huge mix of regions in the south west with clear images and good topography. The section on Avon Gouge rock climbing area only spans around a dozen pages, but covers the main routes on the main areas. It has very clear images for the Sea Walls climbing area where this route is located. Many of the routes covered in here are easy to mid-level multi-pitch climbs, although there are single pitch and higher E grade trad climbs as well.
257	22	20	Published in 1995 this climbing guidebook is best described as classic. It covers a number of climbs at Freyr including Le Merinos and La Savonnette. It’s written in English and is one of the early guidebooks from Chris Craggs probably better known for his more recent work with Rockfax. The guide has decent route descriptions and uses British grades. There are pictures for some climbs but not this one on the Merinos face. Whilst it can be picked up cheaply there are newer guides to the area, although most are sadly not in English.
258	19	240	This guide covers everything you need for a multi-pitch climbing trip regardless of ability, it also has sport, trad and via ferrata routes. It features all the major areas and has very clear topos and route descriptions including Grande Femeda and the sourounding shark fin Alps of delle Odle group. The guide covers a really good mix of grades from easy to very hard providing lots of options for climbing adventure.
259	23	459	An extensive and well-made guidebook covering every worthwhile crag in Northern Scotland. The guides are clear with generally very good photography. The climb on the Old Man of Hoy has a good amount of detail. The guide also covers key Scottish sea stacks like The Old Man of Stoer and Am Buachaille. A guide that comes highly recomended.
260	24	102	A fantastic guidebook to the quartzite trad climbing around the Jebel el Kest and Jebel Taskra massifs. Mostly multi-pitch climbs up to to 800m mountain adventures.This is a selective guide in that it describes 79 of the best crags, but does offer comprehensive coverage of those crags. It covers the East Buttress climb on Ksar rock in exceptional detail.
260	25	244	Morocco Rock is a quality guidebook and one of the original for the region. The imagery and description are clear and the book contains an incredible number of routes in all key trad climbing areas. The guide covers routes from Diff up to E6. It only covers the Jebel El Kest and Taskra, therefore misses out (often bolted) routes on the Tafraoute granite. The guide covers Ksar Rock and specifically the East Buttress Climb in good detail. It shows the first pitch of the route as a full 50m climb to the pedestal before the crack. A long first pitch is much more logical than breaking it up. The guide also combines the middle pitches (4 & 5 on the above topo). This makes less sense because the rope drag would be hard to manage even without any runners. The guide is a worthwhile investment, grading the climb here as HS 4a.
261	24	137	A fantastic guidebook to the quartzite trad climbing around the Jebel el Kest and Jebel Taskra massifs and Tafraout Grabite. The book covers mostly multi-pitch climbs including some mountain routes over a kilometer long. This is a selective guide that describes 79 of the best crags, and offers comprehensive coverage of the key route or two on those crags. It covers the High Sierra climb in exceptional detail.
262	25	107	Morocco Rock offers great information for climbing on the Amzkhssan Wall. The descriptions and photography for his wall are both on the smaller side, but it’s still more than clear enough to get up the wall. The book overall also offers an incredible about of information on the routes and climbing in the Jebel El Kest.
263	25	190	Morocco Rock is a quality guidebook and one of the original for the region. The imagery and description are clear and the book contains an incredible number of routes in all key trad climbing areas. The guide covers climbing graded from Diff up to E6. The guide covers the whole Eagle Rock section and specifically the climb Donkey Serenades in good detail. The route in this guide shows a start further left (East) on the crag graded 4a. I also has finish that takes the right side of the final pinnacle.  The book is great value for money but not as well organised as The Oxford Alpine club books for this region.
264	26	169	The guidebook is in Bulgarian and in English and coves more than 500 sport and trad climbing routes in Vratsa. This edition comprises all information, expanded and updated from the previously published guidebook Vratsa Rocks, Alpine Routes (Petkov & Maslarov, 1987) as well as recently developed areas and routes. \r\n</p><p>For each sector, routes are traced out on photographs. For trad/alpine routes including the Bulgaria 1300 route, you will also find short pitch-by-pitch descriptions on a drawn topo.
265	27	87	This is a selective rock climbing guide to the Gower peninsula in South Wales. Gower Rock aims to showcase the depth and quality of rock climbing on this wild, beautiful yet somewhat unknown peninsula. The book does a good job highlighting the best of the area, including a short section on Great Tor. The directions to find the climbs in the book seem to be inaccurate because they rely on landmarks that change (the white house near Paviland is not white anymore and the bench on the way to Great Tor is no where to be found). The book is good value for money for the climber planning a passing visit to Gower.
266	13	86	This book is a very comprehensive guide to trad climbing in the Mourne Mountains. The section on Slieve Lamagan covers the route FM and nearby lines up Lamagan. The guide is pocket sized, so it's easy to take on route. The photo topo is not bad but hard to read once on the route. That said the generic Ireland guide is not much clearer and attempting to follow it may take the climbing party the wrong way on a gearless tour of the lower friction slabs of Slieve Lamagan.
266	28	75	This recent guide was created by local climbers and covers 25 traditional routes in the Irish province of Ulster. The guide includes several multi-pitch routes and some new routes not yet covered in other guides. Inspired by Ken Wilson's Classic Rock, this guide often dedicates multiple pages to a single climb, but unlike classic rock the topos here are clear and so the book can be used to find and climb routes in the Mourne mountains, Fair Head and Donegal mountain and coastal routes. The section on Slieve Lamagan is very clear and used the previous topo (before Cherchez-La was added) from this site. Mountaineering Ireland sell copies in their shop. 
266	29	255	This is a great guide to rock climbing in Ireland. The book has a focus on trad climbing and covers many multi-pitch routes from Donegal to Fair Head and plenty of routes in the Mourne Mountains, including FM on Slieve Lamagan. The photo topo is clear, but taken from an angle that makes it a little tricky to read. At least that’s my excuse for taking my wife on an extra two pitch mystery tour of the lower friction slabs.
267	19	168	The rockfax guide is well structured and covers many great multi-pitch routes in the dolomites including Via Maria / Mariakante. It’s a well-made guidebook with lots of helpful information. That said there are mistakes in some of the diagrams and descriptions which can make route finding tricky. Especially on the upper section of this route.
267	30	162	A brilliant guide book covering 70 of the best multi-pitch climbs in the Dolomites from grades II to VI. The book has a two-page spread per climb with a photo and a hand drawn topo. The approch and descent information is much better than the rockfax guide. However, the downside to this book is it has no pitch by pitch description which will make route finding on bigger walls hard. The book covers Via Maria and the the other climbs on this site and is a worthwhile purchase if you're able to get hold of it. The gift shop in the Sella pass, closest to the sella towers stocked it at the time of writting (Aug 2020).
268	19	200	The rockfax guide is well structured and covers many great multi-pitch routes in the dolomites including Via Steger. It’s a well-made guidebook with pleanty of information. That said the detail on this route (Via Steger) is very wrong. The pitches and descriptions are for the original climb but the photo topo route includes the lower extension. To make matters worse the two have been merged to try and make them match up resulting in extra confusion. For this route, only the info for the last 4 pitches is correct.
268	30	98	A brilliant guide book covering 70 of the best multi-pitch climbs in the Dolomites from grades II to VI. The book has a two-page spread per climb with a photo and a hand drawn topo. The approch and descent information is much better than the rockfax guide. However, the downside to this book is it has no pitch by pitch description which will make route finding on bigger walls hard. The book covers Via Steger and the the other climbs on this site. It is a worthwhile purchase if you're able to get hold of it. The gift shop in the Sella pass, closest to the sella towers stocked it at the time of writting (Aug 2020).
269	31	204	A great book covering a wide and varied set of crags in sunny Spain. This guide covers a lot of sport routes both single and multi-pitch as well as a smaller number of traditionally protected routes with some single and many multi-pitch routes. Most of the trad multi-pitch routes do have some fixed gear / anchors. The guide covers a few popular lines up Puig Campana in detail, including Epsolon Central. Pitch 3 in the new guide has the wrong grade. The old version of this guide is as good and covers the Edwards Extension up to the summit of Pic Prim the smaller peak southwest of Puig Campana.
270	32	50	A good clear guide to Slate Quarries in the Llanberis area including Dinorwic Quarry and the Garret Pit. The photos and descriptions are clear and the guide contains a lot of history and other useful information. The book is a worthwhile purchase assuming you can get hold of a copy of  it as it's now out of print.
271	7	187	North wales has plenty of multi-pitch Trad climbs. This book covers a good selection of climbs from the best mountains and cliff faces in North Wales. It has a page (187) dedicated to the Cneifion Arete. The book is very much a worthwhile investment for any rock climbing trip to the Llanberris and Snowdon area of Wales. The book also covers nearby climbs on Tryfan, the Idwal Slabs, Sub Cneifion Rib and Glyder Fatch.
272	33	1	The original guide can be found in the free topos section linked on the compass west site. There are also well written paid topos on the site for other areas and compass west also offers affordable accommodation and guiding. The guide is more than clear enough to complete the route and link up. It also shows a possible HVS variation on tower one as well as the traverse and scramble up to the summit of La Capella.
273	14	267	A good book covering a lot of sport, trad and multi-pitch climbing, as well as ridge climbs and via feretta in the Costa Blanca area of Spain. This guide covers the climbs around Calpe including Via Pany. Rockfax grades the steep 4th pitch, UIAA grade V which is a little higher than local guides which put it at IV+. The drawn topo also seems wrong on pitches 3, 6 and 7.
274	13	71	A very comprehensive guide to trad climbing in the Mourne Mountains. The section on Buzzards Roost is very detailed, although specific details for The Sheugh are vague. With the 3rd pitch description written as 'Further wiggling leads to a secluded meadow' which makes little sense. 
274	29	253	This is a great guide to rock climbing in Ireland. The book has a focus on trad climbing and covers many multi-pitch routes from Donegal to Fair Head and plenty of routes in the Mourne Mountains, including The Sheugh. It describes the route as 'A dank but atmospheric journey into the heart of darkness', which is pretty accurate. However the description is very vague and inaccurate for pitch 2 and 3.
275	5	80	A very comprehensive guide to Climbing Irelands North West County of Donegal. Author Iain Miller is a very accomplished climber and set many of the first accents in the book including Cnoc Na Mara. The book is great value for money, however if you are on a budget, much of the material is posted free on Iain Millers Website uniqueascent.ie
276	13	234	A comprehensive guide to trad climbing in the Mourne Mountains. Pigeon Rock is covered in detail. The guide describes the route in 3 pitches, which is possible but may lead to rope drag on pitch one.
276	29	241	This is a great guide to rock climbing in Ireland. The book has great photography and succinct, but mostly sufficient descriptions. The photography is better than the Mourne Mountains Guide in general but the 3rd pitch of virgo is not visible in this guide (although it's hard to get lost on the 3rd pitch).
277	14	235	An okay book, covering a lot of sport, trad and multi-pitch climbing in the Costa Blanca area of Spain. This guide covers many routes in the Echo Valley. However the more you use the book the more mistakes you find. On this route belay and abseil are mixed up at the end of pitch 2 and the grades are wrong in relative terms, if not also absolute terms. That aside, the topo for Rincon de Placa is usable. The description is weak. In short the spanish guide is easier to use, even for non-spanish speakers.
277	15	188	This new 2025 guidebook covers 145 of the best climbs in the Alacant region of Spain including Rincon de Placa. The book is in Spanish but has clear topos and good local route information. The book is ideal for those who like longer routes that need a trad rack to protect them. This is a very well produced guidebook. If you can't read Spanish, Google lens does a good enough job translating pages.The hand drawn topo of Rincón de Placa is brilliant and makes route finding easy.
278	7	169	North wales has plenty of multi-pitch Trad climbs. This book covers a good selection of climbs from the best mountains and cliff faces in North Wales. It has a few pages dedicated to the Tryfan and has a good description of the Grooved Arete. The book is very much a worthwhile investment for any rock climbing trip to the Llanberris and Snowdon area of Wales. The book also covers nearby climbs on the Idwal Slabs and Glyder Fatch.
279	34	176	This book takes the unusual approach of highlighting a handful of locations for ridge scrambles, via ferrata, canyoning, sport climbing, trad climbing, hiking, trail running and mountain biking. Despite it not being a dedicated climbing guidebook, it does a great job on the routes it covers, highlighting 6 of the classic multi-pitch trad climbs in Costa Blanca including Aristotles and the Pepsi Crest continuation on Puig Campana. The descriptions are pretty good (only got lost once - see our pitch description). The guide generously grades Aristotles Very Severe. Given the price I’d highly recommend this book. It’s also the only English guide to cover this route. 
279	15	188	This spanish language guidebook covers 145 of the best climbs in the Alacant region of Spain including Arista Aristóteles and the Pepsi Crest (which the guidebook notes, is named after the christmas jingle on the popular pepsi advert at the time of the first ascent). The book is in Spanish but has clear topos and good local route information. The book is ideal for those who like longer routes that need a trad rack to protect them. This is a very high quality guidebook of coffee table proportions. If you can't read Spanish, Google lens does a good enough job translating pages.
280	13	247	This book covers almost all the trad climbing in the Mourne Mountains, although newer and old / niche routes are missing. The section on Eagle Mountain at the back feels like it was added as an afterthought to an otherwise good guide. The photography is terrible and makes the crag look small and slimy which is underserved, and perhaps why it sees so little traffic; although the NE aspect does mean it’s far from perfect. The description of Sammy Higgins is good enough. The guide also highlights the key nearby climbs like the Great Corner (E1) to the right and Motor Cycle Mania (VS) to the left.
281	19	175	This guide covers everything you need for a multi-pitch climbing trip regardless of ability, it also has sport, trad and via ferrata routes. It features all the major areas and has very clear topos and route descriptions including Fedele and the extension and adjecent route Dibona.
282	7	191	North wales has plenty of Trad climbs above 50m. This book covers a good selection of climbs from a good selection of cliffs, including a variety of routes up the Idwal Slabs. The book is very much a worthwhile investment for any rock climbing trip to the Llanberris and Snowdon area of Wales. 
283	1	104	Whilst this is a great book in general, it's section on Lundy is of little value. It has no topos and little information on Lundy. So for climbing in the west country including many good multi-pitch routes, it is great, but for Lundy specifically it's of little value.
283	12	113	Ken Wilson's Classic Rock is one of the most popular and iconic works of climbing literature ever written. First published in 1978, Classic Rock represented the absolute best of British climbing at that time, and to this day highlights the best climbing in Great Britain, covering 80 routes up to the grade of Hard Severe or Mild Very severe.  The book is more of a coffee table book than a guidebook in the traditional sense. It brings each route to life through a superb selection of photographs, anecdotes and essays from some of the most accomplished climbers of the day. This book covers the climb on the devils Slide in Lundy over 5 large pages covering more detail and inspiration for rock climbing than any guidebook.
283	2	160	South West climbs by Pat Littlejohn is a traditional guidebook. It has good route descriptions and information. The guide covers a great range of climbing areas in the south west of England and covers Lundy, and in particular the Devils Slide climb and its namesake cliff face well. The guidebook is, for the most part, printed in black and white and the photos and diagrams are not up to the standard of more recent guidebooks. However, it does a much better job of route descriptions than most modern guides. Overall not a bad investment, but it certainly feels its age.
284	35	34	A solid guidebook with clear topography that is well organised and covers bouldering, sport and trad. The book lacks detailed descriptions on the routes themselves, but this is probably a good thing for those with a strong on-sight ethic. The book is not essential for climbing at Meadinha as the meadinha.com website has far more information but the book is a worthwhile purchase for someone traveling around Portugal, however the price tag feels a bit high all things considered.
\.


--
-- Data for Name: route_hazard; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.route_hazard (route_id, hazard_code, evidence_span, source_url) FROM stdin;
3	tidal	approach beach cut off around high water	https://example.dev/fixture
6	stormExposed	high alpine face, no quick retreat in afternoon storms	https://example.dev/fixture
7	stormExposed	high alpine face, no quick retreat in afternoon storms	https://example.dev/fixture
8	polished	\N	\N
51	traverse	multi-pitch.com source flag	https://multi-pitch.com/data/data.json
103	loose	multi-pitch.com source flag	https://multi-pitch.com/data/data.json
15	traverse	multi-pitch.com source flag	https://multi-pitch.com/data/data.json
11	grassLedges	multi-pitch.com source flag	https://multi-pitch.com/data/data.json
18	traverse	multi-pitch.com source flag	https://multi-pitch.com/data/data.json
24	loose	multi-pitch.com source flag	https://multi-pitch.com/data/data.json
88	traverse	multi-pitch.com source flag	https://multi-pitch.com/data/data.json
89	grassLedges	multi-pitch.com source flag	https://multi-pitch.com/data/data.json
79	loose	multi-pitch.com source flag	https://multi-pitch.com/data/data.json
61	traverse	multi-pitch.com source flag	https://multi-pitch.com/data/data.json
60	abseil	multi-pitch.com source flag	https://multi-pitch.com/data/data.json
60	loose	multi-pitch.com source flag	https://multi-pitch.com/data/data.json
109	loose	multi-pitch.com source flag	https://multi-pitch.com/data/data.json
109	traverse	multi-pitch.com source flag	https://multi-pitch.com/data/data.json
70	loose	multi-pitch.com source flag	https://multi-pitch.com/data/data.json
1	abseil	multi-pitch.com curated flag	https://multi-pitch.com/climbs/original-route-on-old-man-of-stoer/
1	traverse	multi-pitch.com curated flag	https://multi-pitch.com/climbs/original-route-on-old-man-of-stoer/
1	tidal	multi-pitch.com curated flag	https://multi-pitch.com/climbs/original-route-on-old-man-of-stoer/
214	tidal	multi-pitch.com curated flag	https://multi-pitch.com/climbs/wreakers-slab-on-cornakey-cliff/
214	loose	multi-pitch.com curated flag	https://multi-pitch.com/climbs/wreakers-slab-on-cornakey-cliff/
216	abseil	multi-pitch.com curated flag	https://multi-pitch.com/climbs/esparraguera-on-roca-gris/
216	traverse	multi-pitch.com curated flag	https://multi-pitch.com/climbs/esparraguera-on-roca-gris/
216	loose	multi-pitch.com curated flag	https://multi-pitch.com/climbs/esparraguera-on-roca-gris/
217	abseil	multi-pitch.com curated flag	https://multi-pitch.com/climbs/roaring-forties-on-sail-rock/
218	tidal	multi-pitch.com curated flag	https://multi-pitch.com/climbs/pegasus-on-chair-ladder/
219	abseil	multi-pitch.com curated flag	https://multi-pitch.com/climbs/durance-on-the-devils-tower/
220	seepage	multi-pitch.com curated flag	https://multi-pitch.com/climbs/longlands-continuation-on-lliwedd/
221	abseil	multi-pitch.com curated flag	https://multi-pitch.com/climbs/sydpillaren-on-stetind/
222	seepage	multi-pitch.com curated flag	https://multi-pitch.com/climbs/keswick-brothers-climb-on-scafell/
223	loose	multi-pitch.com curated flag	https://multi-pitch.com/climbs/joy-on-mount-indefatigable/
224	seepage	multi-pitch.com curated flag	https://multi-pitch.com/climbs/doorpost-on-bosigran/
225	seepage	multi-pitch.com curated flag	https://multi-pitch.com/climbs/poetic-justice-on-slieve-beg/
248	abseil	multi-pitch.com curated flag	https://multi-pitch.com/climbs/diedro-ubsa-on-peñón-de-ifach/
248	polished	multi-pitch.com curated flag	https://multi-pitch.com/climbs/diedro-ubsa-on-peñón-de-ifach/
248	loose	multi-pitch.com curated flag	https://multi-pitch.com/climbs/diedro-ubsa-on-peñón-de-ifach/
249	abseil	multi-pitch.com curated flag	https://multi-pitch.com/climbs/traumpfeiler-on-heiliger-geist/
250	abseil	multi-pitch.com curated flag	https://multi-pitch.com/climbs/visite-obligatoire-on-aiguille-dibona/
251	loose	multi-pitch.com curated flag	https://multi-pitch.com/climbs/direkte-plattenwand-on-brüggler/
252	abseil	multi-pitch.com curated flag	https://multi-pitch.com/climbs/piaz-arete-delagokante-on-vajolet-towers/
252	traverse	multi-pitch.com curated flag	https://multi-pitch.com/climbs/piaz-arete-delagokante-on-vajolet-towers/
252	polished	multi-pitch.com curated flag	https://multi-pitch.com/climbs/piaz-arete-delagokante-on-vajolet-towers/
253	abseil	multi-pitch.com curated flag	https://multi-pitch.com/climbs/mendez-and-guillermo-on-cathedral-rock/
253	traverse	multi-pitch.com curated flag	https://multi-pitch.com/climbs/mendez-and-guillermo-on-cathedral-rock/
253	loose	multi-pitch.com curated flag	https://multi-pitch.com/climbs/mendez-and-guillermo-on-cathedral-rock/
254	abseil	multi-pitch.com curated flag	https://multi-pitch.com/climbs/right-hand-route-on-wintours-leap/
255	seepage	multi-pitch.com curated flag	https://multi-pitch.com/climbs/great-slab-on-clogwyn-dur-arddu/
256	polished	multi-pitch.com curated flag	https://multi-pitch.com/climbs/morpheus-on-avon-gorge/
257	polished	multi-pitch.com curated flag	https://multi-pitch.com/climbs/le-merinos-on-freÿr/
258	abseil	multi-pitch.com curated flag	https://multi-pitch.com/climbs/normal-route-on-grande-fermeda/
259	abseil	multi-pitch.com curated flag	https://multi-pitch.com/climbs/original-route-on-old-man-of-hoy/
259	traverse	multi-pitch.com curated flag	https://multi-pitch.com/climbs/original-route-on-old-man-of-hoy/
259	tidal	multi-pitch.com curated flag	https://multi-pitch.com/climbs/original-route-on-old-man-of-hoy/
261	abseil	multi-pitch.com curated flag	https://multi-pitch.com/climbs/high-sierra-on-high-sierra-dome/
267	traverse	multi-pitch.com curated flag	https://multi-pitch.com/climbs/via-maria-on-sass-pordoi-south-face/
268	abseil	multi-pitch.com curated flag	https://multi-pitch.com/climbs/via-steger-on-sella-towers/
268	polished	multi-pitch.com curated flag	https://multi-pitch.com/climbs/via-steger-on-sella-towers/
270	traverse	multi-pitch.com curated flag	https://multi-pitch.com/climbs/australia-west-face-on-dinorwic-quarry/
270	grassLedges	multi-pitch.com curated flag	https://multi-pitch.com/climbs/australia-west-face-on-dinorwic-quarry/
271	polished	multi-pitch.com curated flag	https://multi-pitch.com/climbs/cneifion-arete-on-cwm-cneifion/
272	abseil	multi-pitch.com curated flag	https://multi-pitch.com/climbs/dos-hermanos-on-penya-roc/
272	traverse	multi-pitch.com curated flag	https://multi-pitch.com/climbs/dos-hermanos-on-penya-roc/
272	loose	multi-pitch.com curated flag	https://multi-pitch.com/climbs/dos-hermanos-on-penya-roc/
272	grassLedges	multi-pitch.com curated flag	https://multi-pitch.com/climbs/dos-hermanos-on-penya-roc/
273	traverse	multi-pitch.com curated flag	https://multi-pitch.com/climbs/via-pany-on-peñón-de-ifach/
273	polished	multi-pitch.com curated flag	https://multi-pitch.com/climbs/via-pany-on-peñón-de-ifach/
273	grassLedges	multi-pitch.com curated flag	https://multi-pitch.com/climbs/via-pany-on-peñón-de-ifach/
274	traverse	multi-pitch.com curated flag	https://multi-pitch.com/climbs/the-sheugh-on-buzzards-roost/
274	seepage	multi-pitch.com curated flag	https://multi-pitch.com/climbs/the-sheugh-on-buzzards-roost/
275	abseil	multi-pitch.com curated flag	https://multi-pitch.com/climbs/cnoc-na-mara-on-tormore-group/
275	boat	multi-pitch.com curated flag	https://multi-pitch.com/climbs/cnoc-na-mara-on-tormore-group/
275	tidal	multi-pitch.com curated flag	https://multi-pitch.com/climbs/cnoc-na-mara-on-tormore-group/
275	loose	multi-pitch.com curated flag	https://multi-pitch.com/climbs/cnoc-na-mara-on-tormore-group/
276	traverse	multi-pitch.com curated flag	https://multi-pitch.com/climbs/virgo-on-pigeon-rock/
276	seepage	multi-pitch.com curated flag	https://multi-pitch.com/climbs/virgo-on-pigeon-rock/
276	grassLedges	multi-pitch.com curated flag	https://multi-pitch.com/climbs/virgo-on-pigeon-rock/
277	abseil	multi-pitch.com curated flag	https://multi-pitch.com/climbs/rincón-de-placa-on-el-castellet/
277	traverse	multi-pitch.com curated flag	https://multi-pitch.com/climbs/rincón-de-placa-on-el-castellet/
278	polished	multi-pitch.com curated flag	https://multi-pitch.com/climbs/grooved-arete-on-tryfan/
279	abseil	multi-pitch.com curated flag	https://multi-pitch.com/climbs/aristotles-on-puig-campana/
279	traverse	multi-pitch.com curated flag	https://multi-pitch.com/climbs/aristotles-on-puig-campana/
280	abseil	multi-pitch.com curated flag	https://multi-pitch.com/climbs/sammy-higgins-on-eagle-mountain/
280	seepage	multi-pitch.com curated flag	https://multi-pitch.com/climbs/sammy-higgins-on-eagle-mountain/
280	grassLedges	multi-pitch.com curated flag	https://multi-pitch.com/climbs/sammy-higgins-on-eagle-mountain/
283	abseil	multi-pitch.com curated flag	https://multi-pitch.com/climbs/the-devils-slide-on-lundy/
\.


--
-- Data for Name: route_parking; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.route_parking (id, route_id, label, geom, ord) FROM stdin;
6	214	Morwenstow tea room car park	0101000020E6100000876A4AB20E3712C0126A865451744940	1
7	214	layby (overflow)	0101000020E61000004F1E166A4D3312C0068195438B744940	2
\.


--
-- Data for Name: route_reference; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.route_reference (id, route_id, prefix, text, url) FROM stdin;
157	1	\N	Climb Info: Mountain Project Page	https://www.mountainproject.com/route/106636010/the-old-man-of-stoer
158	1	\N	Climb Info: UKC Page	https://www.ukclimbing.com/logbook/crag.php?id=300
159	1	\N	Climb Image: Climber on better penultimate belay. Credit Malcolm H.	https://www.multi-pitch.com/img/topos/stoer/belay-position-on-stoer-sea-stack.jpg
160	1	Video	Video: The swim & climb to the sea stack	https://www.youtube.com/watch?v=pgrfVtOotb8
161	214	Video	Video: Salute To The Admiral (the story of Wrecker’s Slab)	https://vimeo.com/447803688
162	214	Video	Video: Headcam video of the accent on youTube	https://www.youtube.com/watch?v=ifNQuBPfHJU
163	216	\N	Map of the approch to Grey Rock	https://www.google.com/maps/d/u/0/viewer?mid=19-UZpbBH4Q90XN_z9Huj85GhcZI&ll=41.58559982322766%2C1.8162812289963313&z=16
164	216	\N	A nice blog covering the climb Esparraguera	https://climbasana.blogspot.com/2018/01/roca-gris-via-esparraguera.html
165	216	\N	Brilliant drawn topo and blog	https://elcoleccionistadevies.blogspot.com/2016/07/18-anys-de-laresta-esparreguera-la-roca.html
166	219	\N	Climb Info: Mountain Project Page	https://www.mountainproject.com/area/105714267/devils-tower
167	219	\N	Blog: Guide to the Devils Tower	https://www.lydiascapes.com/rock-climbing-devils-tower-guide-wyoming/
168	220	\N	A great overview of Lliwedd by Kate Edhouse	https://kateedhouse.wordpress.com/2013/05/24/my-favourite-experience-on-mountain-moor-and-cave/
169	220	\N	Rockfax preview covering  key climbs up Lliwedd	https://www.rockfax.com/wp-content/uploads/intros/north-wales-climbs-preview.pdf
170	220	\N	Red Wall details on Mountain Project	https://www.mountainproject.com/route/108164049/red-wall
171	221	\N	Climb Info: Stetind South Pillar Mini Guide 2003	http://www.stetind.nu/uploads/6/1/8/8/6188415/stetind_sydpillaren.pdf
172	223	\N	Mountain Project Page	https://www.mountainproject.com/route/107186623/joy
173	224	\N	UKC photo gallery	https://www.ukclimbing.com/photos/item.php?nstart=24&crag=199&route=doorpost
174	224	\N	BMC Regional Access Database Page for Bosigran	https://www.thebmc.co.uk/modules/rad/view.aspx?id=1878
175	224	\N	Climbers Climb Guide, Sample for Bosigran	http://www.climbers-club.co.uk/cms/wp-content/uploads/2013/07/West-Cornwall-North-sampler.pdf
176	225	\N	Climb Info: Climbing.ie Wiki Page	http://wiki.climbing.ie/index.php?title=Slieve_Beg
177	225	\N	Climb Info: UKC Page (has useful photo)	https://www.ukclimbing.com/logbook/c.php?i=87282#photos
178	247	\N	Guid to climbing Lion Rock	https://hongkongclimbing.files.wordpress.com/2012/06/lionrock.pdf
179	248	\N	Climb Info: Good Guide to Diedro U.B.S.A. in Spanish	https://www.calpe.es/sites/default/files/descubre_calpe_docs/2022-05/senderos_de_la_roca_-_penon_de_ifach_-_ruta_24_-_diedro_ubsa.pdf
180	248	\N	Climb Info: Good Diedro U.B.S.A. Topo in Spanish	https://elev-arte.com/via-diedro-ubsa-250-m-6a-cara-sur-penon-de-ifach/
181	248	\N	Climb Info: Good Guide in Spanish	http://cuadernodemontana.blogspot.com/2021/10/21-10-2021-diedro-ubsa-penon-de-ifach.html
182	248	\N	Climb Info: A Blog Post in Spanish	http://elrefugioalpino.blogspot.com/2014/06/diedro-ubsa-penon-de-ifach.html
183	249	\N	Climb Info: Summit Post Page	https://www.summitpost.org/traumpfeiler-pillar-of-dreams/292553
184	250	\N	Soreiller Refuge - Mountain Hut Info	https://soreiller.com/en/home/
185	252	Accommodation	Accommodation: Rifugio Alberto	https://www.rifugiorealberto.com/en/
186	252	\N	Weather: Vajolet Towers	https://www.mountain-forecast.com/peaks/Vajolet-Towers/forecasts/2821
187	253	Access	Access Info: Goat hunting schedule (mouflon)	https://www.tenerifeon.es/en/updates-and-news/full-information-about-the-2025-mouflon-control-campaign
188	253	\N	Climb Info: Good Local trad in the area including this route	http://anuestraputabolacroquis.blogspot.com/search/label/P.N.%20DEL%20TEIDE
189	253	\N	Climb Info: UKC Page, including other pictures	https://www.ukclimbing.com/logbook/crag.php?id=17495#overview
190	253	Video	Video: Climbing in Tenerife 2023 including La Cathedral	https://www.youtube.com/watch?v=x7rUnzPlrGs&t=199s
191	254	\N	Climb Info: BMC RAD database Page	https://www.thebmc.co.uk/modules/RAD/View.aspx?id=744
192	254	Article	Article: Great blog post on the Left Hand Route	https://www.adventureswithdicken.co.uk/2020/12/06/a-fantastic-multipitch-climb-in-wintours-leap-after-work/
193	255	\N	Clogwyn Du'r Arddu on UKC	https://www.ukclimbing.com/logbook/crag.php?id=457
194	255	\N	BMC Supper Zoom topo of Clogwyn Du'r Arddu	https://www.thebmc.co.uk/zoomtopo/cloggy/
195	255	\N	Rockfax preview covering the Great Slab climb on Cloggy	https://www.rockfax.com/wp-content/uploads/intros/north-wales-climbs-preview.pdf
196	256	\N	UKC Page for Morpheus	https://www.ukclimbing.com/logbook/c.php?i=29806
197	258	\N	Brilliant drawn topo	https://www.ramellasergio.it/Testo/VIE_FUTURE/ODLE/schizzo_normale_grande_fermeda.html
198	258	\N	Mountain Hut - Rifugio Firenze in Cisles	http://www.enrosadira.it/rifugi/firenze.htm
199	259	\N	Climb Info: Climbs on The Old Man of Hoy	https://www.ukclimbing.com/articles/destinations/the_old_man_of_hoy-69
200	259	Video	Video: BBC documentry from 1992 focused on The Old Man of Hoy	https://www.youtube.com/watch?v=wNzUtvy0lsI
201	259	Video	Video: Catherine Destivelle soloing The Old Man of Hoy	https://www.youtube.com/watch?v=Ruvzhhg_B-s
202	259	Article	Article: The Blind Man of Hoy	https://www.ukclimbing.com/articles/features/the_blind_man_of_hoy-5602
203	259	Article	Article: Blind Man Leads Old Man of Hoy	https://www.independent.co.uk/news/uk/home-news/jesse-dufton-blind-climber-record-orkney-old-man-hoy-sheer-cliff-a8949946.html
204	259	Article	Article: 8 year old climbs Old Man of Hoy for charity	https://www.thebmc.co.uk/eight-year-old-climbed-old-man-of-hoy-receives-award
205	260	\N	Climb Info: Sample of Climb Tafraout | 100 Classic Climbs covering Ksar Rock	https://issuu.com/oxfordalpineclub/docs/100cc_preview_reduced
206	260	Article	Article: Morocco Trad Climbing | Tafraout	http://www.the-mountain-people.com/blog/morocco-trad-climbing-tafraout-recce-trip/
207	260	Accommodation	Accomerdation: Ksar Rock Guest House	https://www.facebook.com/pages/category/Local-Service/Ksar-Rock-Guesthouse-392611694523681/
208	264	\N	Hiking in Vratsa, Bulgaria	https://www.sawthisdidthat.ca/2016/08/day-hike-from-vratsa-bulgaria.html
209	264	\N	Blogpost guide to Vratsa	http://climbing-in-bulgaria.blogspot.com/2011/04/
210	265	\N	Climb Info: South Wales Climbing Wiki Great Tor page	https://swcw.org.uk/wiki/Great_Tor_Proper
211	266	\N	Climb Info: UKC Page	https://www.ukclimbing.com/logbook/crags/slieve_lamagan-1168/fm-67468#photos
212	267	\N	Climb Info: UKC Page (including questionable pitch info)	https://www.ukclimbing.com/logbook/crags/sass_pordoi-21063/via_mariamariakante-102096#photos
213	268	\N	Climb Info: UKC Page (pitch info excludes bottom 2 pitch extension)	https://www.ukclimbing.com/logbook/crags/sella_towers-2631/via_steger-68904
214	269	\N	Climb Info: Good compilation in Spanish	http://fjalejandre.blogspot.com/2015/02/PuigCampanaEspolonCentral.html
215	269	\N	Climb Info: Climb Madrid Topo	https://climbmadrid.com/espolon-central-al-puig-campana-v/
216	269	\N	Climb Info: Elev-arte Topo	https://elev-arte.com/index.php/escuelas-de-escalada/com-valenciana/alicante/129-puig-campana/1044-via-espolon-central-5-430-mts-puig-campana
217	269	\N	Climb Info: UKC Page	https://www.ukclimbing.com/logbook/crags/puig_campana-1689/espolon_central-22506
218	270	\N	Historic Info: wikipedia page	https://en.wikipedia.org/wiki/Dinorwic_quarry
219	270	\N	Climb Info: Longer alternative on UKC	https://www.ukclimbing.com/logbook/crags/australia-10/a_very_trad_day_out-490859#overview
220	271	\N	Climb Info: UKC Page	https://www.ukclimbing.com/logbook/crags/cwm_cneifion-2157/cneifion_arete-33981
221	273	\N	Climb Info: Good Guide to Via Pany in Spanish	https://www.calpe.es/sites/default/files/descubre_calpe_docs/2023-02/senderos_de_la_roca_-_penon_de_ifach_-_ruta_07_-_pany.pdf
222	273	\N	Climb Info: A very detailed guide to Pany in Spanish	https://www.blogdeaventura.com/escalada-penon-de-ifach/
223	274	\N	Climb Info: UKC Page (including great comments)	https://www.ukclimbing.com/logbook/crags/buzzards_roost-1148/the_sheugh-86377#overview
224	275	\N	Cnoc Na Mara by Iain Miller (first ascensionist)	https://uniqueascent.ie/cnoc_na_mara
225	276	\N	Climb Info: Ireland Climbing Wiki Pigeon Rock	http://wiki.climbing.ie/index.php?title=Pigeon_Rock
226	278	\N	Climb Info: ⭐ Incredible topo of the Tryfan East Face ⭐	https://ogwen-rescue.org.uk/wp-content/uploads/2023/02/1000026186.jpg
227	278	\N	Climb Info: UKC Page	https://www.ukclimbing.com/logbook/crags/tryfan-491/grooved_arete-29169
232	282	\N	UKC Page	https://www.ukclimbing.com/logbook/crag.php?id=496
233	283	\N	Mountain Project Page	https://www.mountainproject.com/area/106669941/the-devils-slide
234	283	Video	Video: Jonny Dawes cimbs the Devils Slide with only his feet	https://www.youtube.com/watch?v=OuTOnNwLUbk
239	279	\N	Climb Info: Spanish topo	https://pacobonati.blogspot.com/2018/01/
240	279	\N	Climb Info: Great topo of Espolon Finestrat variation	https://circomarco.blogspot.com/2014/08/puig-campana-espolon-finestrat.html
241	279	\N	Climb Info: Spanish Guide	https://cuadernodemontana.blogspot.com/2016/06/01-06-2016-arista-aristoteles-espolon.html
242	279	\N	Climb Info: Spanish Guide with some mistakes (length, grades, line etc)	https://cms.smartcostablanca.com/sites/default/files/2024-03/puig_campana_r25.pdf
235	283	Travel	Travel: Lundy Ferry Timetable & Prices	https://www.landmarktrust.org.uk/lundyisland/Timetable/
236	283	Info	Info: National Trust Page	https://www.nationaltrust.org.uk/lundy/features/facilities-and-access-on-lundy
237	283	Article	Article: Lundy Island CircumSummit	https://medium.com/@tommyoswin/lundy-island-circumsummit-3a1577bb7738
238	284	\N	Comprehansive guide to meadinha	http://www.meadinha.com/vias_en.html#vias
\.


--
-- Data for Name: source; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.source (id, name, type, method, license, tos, regions, cadence, teaches) FROM stdin;
openbeta	OpenBeta	route-db	graphql	CC (open)	ingestion-encouraged	{*}	monthly	hierarchical areas, cascading gradeContext, all-systems grades, composable disciplines, structured pitches
thecrag	theCrag	route-db	scrape	proprietary	restricted	{*}	on-demand	grade context at any level, structured cascading tag-sets, 0–100 quality → stars
ukclimbing	UKClimbing	route-db	scrape	proprietary	restricted	{GB,IE}	on-demand	faceted crag search (rocktype/aspect/type), first-class access notes
mountainproject	Mountain Project	route-db	scrape	proprietary	restricted	{US,*}	on-demand	multi-discipline route type, grade-system auto-detect from leading chars
multipitch	multi-pitch.com	route-db	manual	own data	owned	{*}	manual	the curated route record + description style this schema is grounded in
dev-fixtures	Dev fixtures	route-db	manual	n/a	owned	{*}	manual	local development only
\.


--
-- Data for Name: sun_window; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.sun_window (code, meaning) FROM stdin;
morning	Sun until around midday (roughly E-facing) — cool afternoons.
afternoon	Sun from around midday (roughly W-facing) — cold starts, warm finishes.
all-day	Open to the sun most of the day (roughly S-facing) — dries fast, hot in summer.
shade	Little or no direct sun (N-facing or sheltered) — slow to dry, cool in heat.
\.


--
-- Data for Name: topo; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.topo (id, media_id, area_id, title, belay_size, status, updated_at) FROM stdin;
1	1	16	Old Man of Stoer > Original Route | VS 5a - 67m	26	publish	2026-07-17 09:18:20.131945+00
2	2	245	Cornakey Cliff > Wreckers Slab | VS 4b - 130m	22	publish	2026-07-17 09:18:20.131945+00
3	3	288	Roca Gris > Esparraguera - VS 5a | 190m	22	publish	2026-07-17 09:18:20.131945+00
4	4	242	Chair Ladder > Pegasus | HS 4b - 70m	20	publish	2026-07-17 09:18:20.131945+00
5	5	270	Lliwedd > Longlands Continuation | S 4b - 280m	12	publish	2026-07-17 09:18:20.131945+00
6	6	278	Mount Indefatigable > Joy | S 4a (5.7 / 5.8 YSD) - 300m	26	publish	2026-07-17 09:18:20.131945+00
7	7	235	Bosigran > Doorpost | HS 4b - 67m	24	publish	2026-07-17 09:18:20.131945+00
8	8	296	Slieve Beg > Poetic Justice | VS 4b - 80m	28	publish	2026-07-17 09:18:20.131945+00
9	9	283	Peñón de Ifach > Diedro U.B.S.A. | UIAA V+ or HVS 5a - 250m	26	publish	2026-07-17 09:18:20.131945+00
10	10	307	Vajolet towers > Piaz Arete Delagokante | HS 4a - 156m	32	publish	2026-07-17 09:18:20.131945+00
11	11	241	Cathedral Rock > Via Mendez & Guillermo | UIAA V+ or ~VS 5a - 115m	22	publish	2026-07-17 09:18:20.131945+00
12	12	310	Wintours Leap > Right Hand Route | HS 4b - 87m	18	publish	2026-07-17 09:18:20.131945+00
13	13	244	Clogwyn Du'r Arddu > Great Slab | VS 4c - 162m	16	publish	2026-07-17 09:18:20.131945+00
14	14	234	Avon Gorge > Morpheus | HVD 4a - 67m	24	publish	2026-07-17 09:18:20.131945+00
15	15	258	Freÿr > Le Merinos | S 4b - 100m	24	publish	2026-07-17 09:18:20.131945+00
16	16	259	Grande Fermeda > Via Normale | VDiff / UIAA IV- | 720m	14	publish	2026-07-17 09:18:20.131945+00
17	17	280	Old Man of Hoy > Original Route | E1 5b - 137m	17	publish	2026-07-17 09:18:20.131945+00
18	18	267	Ksar Rock > East Buttress | S 4b - 120m	28	publish	2026-07-17 09:18:20.131945+00
19	19	263	High Sierra > High Sierra Dome | VS 5a - 120m	26	publish	2026-07-17 09:18:20.131945+00
20	20	232	Pinnacle Slab > Amzkhssan Wall | Diff 3b - 130m	32	publish	2026-07-17 09:18:20.131945+00
21	21	272	Donkey Serenades > Lower Eagel Crag | VD 3c - 270m	22	publish	2026-07-17 09:18:20.131945+00
22	22	228	Vratsa > Bulgaria 1300 | E1 5c - 400m	28	publish	2026-07-17 09:18:20.131945+00
23	23	260	Great Tor > East Ridge | S 3c - 71m	24	publish	2026-07-17 09:18:20.131945+00
24	24	297	Slieve Lamagan > FM | VDiff 3c - 160m	26	publish	2026-07-17 09:18:20.131945+00
25	25	291	Sass Pordoi South Face > Via Maria | HS 4a - 370m	22	publish	2026-07-17 09:18:20.131945+00
26	26	293	Sella Towers > Via Steger | HS 4a - 175m	22	publish	2026-07-17 09:18:20.131945+00
27	27	286	Puig Campana > Espolón Central | IV+ / HS 4a - 400m	18	publish	2026-07-17 09:18:20.131945+00
28	28	250	Dinorwic Quarry > Australia West Face | E1 5b - 113m	18	publish	2026-07-17 09:18:20.131945+00
29	29	246	Cwm Cneifion > Cneifion Arete | D 3a - 120m	26	publish	2026-07-17 09:18:20.131945+00
30	30	283	Peñón de Ifach > Via Pany | UIAA IV+ or VS 4c - ~220m	26	publish	2026-07-17 09:18:20.131945+00
31	31	237	Buzzards Roost > The Sheugh | Severe 3c - 71m	20	publish	2026-07-17 09:18:20.131945+00
32	32	285	Pigeon Rock > Virgo | Very Severe 4c - 90m	20	publish	2026-07-17 09:18:20.131945+00
33	33	255	El Castellet > Rincón de Placa | UIAA V+ or Very Severe 4c - 120m	20	publish	2026-07-17 09:18:20.131945+00
34	34	306	Tryfan > Grooved Arete | HVD 4a - 240m	11	publish	2026-07-17 09:18:20.131945+00
35	35	286	Puig Campana > Aristotles | UIAA V or Hard Severe 4b - 340m	20	publish	2026-07-17 09:18:20.131945+00
36	36	253	Eagle Mountain > Sammy Higgins | Very Severe 4c - 56m	32	publish	2026-07-17 09:18:20.131945+00
37	37	247	Cwm Idwal > Ordinary Route | D 3a - 140m	20	publish	2026-07-17 09:18:20.131945+00
38	38	217	Lundy > The Devils Slide | HS 4a - 117m	24	publish	2026-07-17 09:18:20.131945+00
47	47	318	North Tor, Slieve Binnian	24	publish	2026-07-17 18:57:51.8369+00
\.


--
-- Data for Name: topo_line; Type: TABLE DATA; Schema: climbing; Owner: climbing
--

COPY climbing.topo_line (topo_id, route_id, line, pitches, descent, source_id, updated_at) FROM stdin;
20	262	[[0.7125, 0.95464], [0.663, 0.8797], [0.613, 0.80645], [0.568, 0.73454], [0.53575, 0.67742], [0.50425, 0.53427], [0.45925, 0.4244], [0.433, 0.34207], [0.443, 0.32796], [0.39375, 0.19657], [0.3625, 0.08266]]	[{"grade": "", "height": "50m", "belayPosition": [0.49625, 0.5252], "labelPosition": [0.5525, 0.65457]}, {"grade": "", "height": "50m", "belayPosition": [0.39, 0.1791], "labelPosition": [0.45625, 0.32191]}, {"grade": "", "height": "30m", "belayPosition": [0.36075, 0.08098], "labelPosition": [0.39, 0.1203]}]	\N	multipitch	2026-07-17 12:28:12.671432+00
29	271	[[0.39706, 0.92218], [0.35866, 0.88766], [0.35049, 0.81005], [0.314, 0.78391], [0.30719, 0.7355], [0.26961, 0.70833], [0.29548, 0.65319], [0.29194, 0.62561], [0.27315, 0.61499], [0.23965, 0.59988], [0.19962, 0.59395], [0.21596, 0.57435], [0.24156, 0.53472], [0.2805, 0.51981], [0.38399, 0.48162], [0.47386, 0.45792], [0.5719, 0.42218], [0.6408, 0.35335], [0.6909, 0.31393], [0.7707, 0.30331], [0.86874, 0.28288], [0.83469, 0.26593], [0.75109, 0.21834], [0.69308, 0.20118], [0.69935, 0.17096], [0.69499, 0.15584], [0.66367, 0.13317], [0.66394, 0.09906], [0.64951, 0.07618], [0.66585, 0.06597], [0.65632, 0.05882], [0.66449, 0.04432]]	[{"grade": "Diff 3a", "height": "20m", "belayPosition": [0.28513, 0.62112], "labelPosition": [0.38399, 0.74163]}, {"grade": "Diff 3a", "height": "10m", "belayPosition": [0.25054, 0.53105], "labelPosition": [0.28949, 0.55331]}, {"grade": "", "height": "", "belayPosition": [0.69907, 0.31209], "labelPosition": [null, null]}, {"grade": "", "height": "", "belayPosition": [0.69499, 0.18587], "labelPosition": [null, null]}, {"grade": "", "height": "", "belayPosition": [0.65904, 0.05964], "labelPosition": [null, null]}]	[{"path": [[0.65632, 0.03942], [0.60539, 0.04126]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}]	multipitch	2026-07-17 12:28:12.671432+00
38	283	[[0.82394, 0.84493], [0.80866, 0.79194], [0.7937, 0.73765], [0.80611, 0.69181], [0.80006, 0.59785], [0.79115, 0.53674], [0.78001, 0.45644], [0.78797, 0.4475], [0.74658, 0.38979], [0.68927, 0.24772], [0.70583, 0.22692], [0.66285, 0.14012], [0.66221, 0.11671], [0.63578, 0.11736], [0.61382, 0.11931], [0.60013, 0.0868], [0.54632, 0.0607]]	[{"grade": "", "height": "", "belayPosition": [0.82362, 0.84493], "labelPosition": [null, null]}, {"grade": "3c", "height": "50m", "belayPosition": [0.78797, 0.4475], "labelPosition": [0.75018, 0.55055]}, {"grade": "4a", "height": "40m", "belayPosition": [0.70583, 0.22692], "labelPosition": [0.67377, 0.31434]}, {"grade": "4a", "height": "30m", "belayPosition": [0.54919, 0.06144], "labelPosition": [0.59748, 0.13596]}]	[{"path": [[0.80229, 0.45335], [0.80866, 0.48895]], "label": "Abseil in", "anchor": [0.8007, 0.44733], "labelPosition": [0.82362, 0.47188]}, {"path": [[0.76886, 0.22724], [0.74339, 0.23375], [0.75072, 0.25878]], "label": "Scramble or abseil down", "anchor": [null, null], "labelPosition": [0.76472, 0.24805]}]	multipitch	2026-07-17 12:28:12.671432+00
1	1	[[0.56548, 0.84102], [0.55522, 0.81349], [0.52943, 0.8244], [0.50529, 0.83185], [0.48214, 0.84028], [0.45304, 0.84152], [0.41634, 0.84524], [0.37235, 0.84028], [0.33532, 0.82961], [0.3502, 0.80903], [0.3631, 0.78795], [0.3955, 0.76587], [0.42427, 0.69023], [0.46362, 0.67832], [0.47685, 0.66096], [0.47784, 0.63988], [0.48049, 0.61235], [0.48776, 0.59846], [0.46792, 0.5692], [0.44742, 0.55481], [0.42163, 0.55432], [0.43155, 0.53695], [0.45569, 0.49802], [0.45899, 0.48735], [0.48049, 0.48636], [0.51852, 0.47197], [0.54597, 0.45337], [0.55589, 0.4375], [0.56085, 0.41865], [0.56911, 0.41344], [0.56647, 0.39559], [0.55655, 0.37178], [0.52745, 0.3564], [0.55721, 0.34152], [0.57705, 0.3063], [0.58135, 0.29712], [0.58499, 0.27059], [0.58532, 0.2495], [0.58168, 0.23785], [0.55886, 0.15923], [0.53075, 0.13938], [0.53274, 0.12624]]	[{"grade": "5a", "height": "15m", "belayPosition": [0.36376, 0.83631], "labelPosition": [0.46693, 0.8688]}, {"grade": "4b", "height": "12m", "belayPosition": [0.46561, 0.67336], "labelPosition": [0.36442, 0.73264]}, {"grade": "4b", "height": "15m", "belayPosition": [0.46329, 0.4876], "labelPosition": [0.50728, 0.59201]}, {"grade": "4c", "height": "10m", "belayPosition": [0.52745, 0.3564], "labelPosition": [0.57507, 0.45015]}, {"grade": "4a", "height": "15m", "belayPosition": [0.53274, 0.12624], "labelPosition": [0.53009, 0.23686]}]	[{"path": [[0.54067, 0.1255], [0.5539, 0.13616], [0.57771, 0.16121], [0.58565, 0.19767]], "label": " < 60m abseil", "anchor": [0.53274, 0.12624], "labelPosition": [0.59358, 0.1441]}]	multipitch	2026-07-17 12:28:12.671432+00
2	214	[[0.73139, 0.90946], [0.73139, 0.89343], [0.72583, 0.87059], [0.7175, 0.85737], [0.70833, 0.84816], [0.70639, 0.81611], [0.68611, 0.80529], [0.67694, 0.79728], [0.67028, 0.77604], [0.68139, 0.72516], [0.68333, 0.69191], [0.68889, 0.66627], [0.69528, 0.64383], [0.69528, 0.61418], [0.6925, 0.53806], [0.69167, 0.52364], [0.7, 0.47556], [0.68528, 0.39543], [0.68417, 0.36058], [0.68139, 0.32051], [0.67028, 0.26042], [0.66306, 0.22316], [0.66861, 0.15905], [0.67861, 0.13221], [0.71472, 0.11098]]	[{"grade": "4a", "height": "40m", "belayPosition": [0.69444, 0.63181], "labelPosition": [0.7075, 0.72917]}, {"grade": "4b", "height": "40m", "belayPosition": [0.68333, 0.3778], "labelPosition": [0.71389, 0.48478]}, {"grade": "4a", "height": "50m", "belayPosition": [0.69167, 0.123], "labelPosition": [0.67417, 0.1883]}]	[{"path": [[0.45, 0.45553], [0.40833, 0.48878], [0.34917, 0.53165]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.33333, 0.89623], [0.36583, 0.88822]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.46861, 0.89062], [0.50278, 0.91466], [0.53056, 0.90425], [0.56861, 0.91466], [0.61472, 0.90665], [0.66583, 0.94151], [0.71389, 0.9387]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}]	multipitch	2026-07-17 12:28:12.671432+00
3	216	[[0.10143, 0.96404], [0.09536, 0.90518], [0.11321, 0.84625], [0.125, 0.79089], [0.14286, 0.73304], [0.1775, 0.68125], [0.20714, 0.67054], [0.21857, 0.63661], [0.23643, 0.61589], [0.25607, 0.59625], [0.25429, 0.57125], [0.27571, 0.55268], [0.29, 0.50161], [0.3025, 0.50268], [0.32214, 0.49196], [0.33643, 0.47589], [0.34357, 0.44625], [0.3625, 0.38911], [0.36607, 0.35268], [0.36786, 0.32411], [0.37571, 0.29732], [0.3875, 0.27839], [0.415, 0.28732], [0.42679, 0.28732], [0.44179, 0.26232], [0.45, 0.23375], [0.45786, 0.21054], [0.49179, 0.21054], [0.49643, 0.19018], [0.50893, 0.14554], [0.52321, 0.14446], [0.52679, 0.12661], [0.53643, 0.11946], [0.54464, 0.11875]]	[{"grade": "UIAA IV", "height": "30m", "belayPosition": [0.11536, 0.83107], "labelPosition": [0.1275, 0.90964]}, {"grade": "UIAA V", "height": "40m", "belayPosition": [0.20821, 0.66071], "labelPosition": [0.17143, 0.74536]}, {"grade": "UIAA V+", "height": "25m", "belayPosition": [0.3, 0.50107], "labelPosition": [0.27607, 0.58107]}, {"grade": "UIAA IV", "height": "50m", "belayPosition": [0.38929, 0.27857], "labelPosition": [0.37857, 0.40964]}, {"grade": "UIAA IV", "height": "20m", "belayPosition": [0.49643, 0.18929], "labelPosition": [0.46679, 0.25]}, {"grade": "UIAA IV+", "height": "30m", "belayPosition": [0.54179, 0.11679], "labelPosition": [0.53929, 0.1475]}]	[{"path": [[0.57393, 0.11679], [0.58571, 0.1225], [0.59286, 0.13929], [0.60607, 0.14036], [0.625, 0.14036], [0.64643, 0.15464]], "label": "80m", "anchor": [null, null], "labelPosition": [0.64643, 0.13346]}, {"path": [[0.72607, 0.20132], [0.71679, 0.22857]], "label": "40m", "anchor": [0.72964, 0.19286], "labelPosition": [0.76429, 0.21786]}, {"path": [[0.68821, 0.38821], [0.68214, 0.41893]], "label": "40m", "anchor": [0.68929, 0.37775], "labelPosition": [0.70607, 0.41321]}, {"path": [[0.64893, 0.58464], [0.65714, 0.61071]], "label": "60m", "anchor": [0.64536, 0.575], "labelPosition": [0.66679, 0.63821]}]	multipitch	2026-07-17 12:28:12.671432+00
4	218	[[0.43976, 0.78657], [0.44474, 0.77255], [0.44474, 0.75301], [0.45569, 0.72345], [0.45802, 0.70391], [0.46001, 0.67034], [0.46764, 0.65731], [0.47063, 0.63327], [0.47859, 0.60872], [0.47892, 0.58517], [0.47262, 0.54609], [0.48888, 0.51403], [0.49884, 0.49299], [0.49685, 0.46693], [0.49585, 0.44439], [0.5088, 0.40681], [0.52373, 0.39429], [0.54663, 0.37575], [0.56721, 0.37275], [0.55825, 0.36122], [0.54431, 0.34018], [0.52572, 0.33116], [0.52473, 0.3011], [0.53535, 0.28557], [0.54265, 0.27054], [0.54862, 0.24399]]	[{"grade": "4b", "height": "32m", "belayPosition": [0.47594, 0.5476], "labelPosition": [0.47693, 0.68136]}, {"grade": "4a", "height": "20m", "belayPosition": [0.56754, 0.37325], "labelPosition": [0.53103, 0.43186]}, {"grade": "4b", "height": "18m", "belayPosition": [0.55028, 0.24399], "labelPosition": [0.54962, 0.28156]}]	[{"path": [[0.2237, 0.30361], [0.23266, 0.34319], [0.19881, 0.37124]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.18619, 0.56012], [0.19881, 0.58116], [0.16794, 0.6022], [0.18022, 0.62625]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.24262, 0.6999], [0.26684, 0.72545], [0.28775, 0.71794], [0.30534, 0.73747], [0.31065, 0.76804], [0.33455, 0.77856]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}]	multipitch	2026-07-17 12:28:12.671432+00
5	220	[[0.24868, 0.72614], [0.25256, 0.69322], [0.25115, 0.66359], [0.25963, 0.64384], [0.27234, 0.63726], [0.27375, 0.60369], [0.28647, 0.55365], [0.29071, 0.5135], [0.30272, 0.49111], [0.30343, 0.45885], [0.32038, 0.45359], [0.32709, 0.42857], [0.33063, 0.41475], [0.33804, 0.40619], [0.34369, 0.36866], [0.34087, 0.35681], [0.33663, 0.35352], [0.33522, 0.33641], [0.35147, 0.33509], [0.35994, 0.33246], [0.355, 0.29954], [0.3444, 0.27123], [0.34369, 0.25609], [0.35888, 0.25148], [0.35853, 0.22054]]	[{"grade": "", "height": "20m", "belayPosition": [0.25327, 0.66294], "labelPosition": [0.25786, 0.69849]}, {"grade": "", "height": "30m", "belayPosition": [0.27411, 0.60764], "labelPosition": [0.27552, 0.64121]}, {"grade": "", "height": "15m", "belayPosition": [0.28541, 0.54707], "labelPosition": [0.28788, 0.57867]}, {"grade": "", "height": "25m", "belayPosition": [0.30131, 0.4898], "labelPosition": [0.29495, 0.52469]}, {"grade": "", "height": "33m", "belayPosition": [0.30625, 0.45425], "labelPosition": [0.31332, 0.47465]}, {"grade": "", "height": "33m", "belayPosition": [0.32568, 0.42725], "labelPosition": [0.3278, 0.45161]}, {"grade": "", "height": "24m 4a", "belayPosition": [0.34158, 0.37854], "labelPosition": [0.34369, 0.4029]}, {"grade": "", "height": "30m 4a", "belayPosition": [0.34193, 0.33509], "labelPosition": [0.30025, 0.35813]}, {"grade": "", "height": "", "belayPosition": [0.35959, 0.32719], "labelPosition": [null, null]}, {"grade": "", "height": "25m ", "belayPosition": [0.34723, 0.27716], "labelPosition": [0.36312, 0.29559]}, {"grade": "", "height": "30m", "belayPosition": [0.35676, 0.24819], "labelPosition": [0.32215, 0.25609]}, {"grade": "", "height": "15m 4b", "belayPosition": [0.35924, 0.21856], "labelPosition": [0.36842, 0.23634]}]	[{"path": [[0.28718, 0.27386], [0.27305, 0.26267], [0.24267, 0.27386]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}]	multipitch	2026-07-17 12:28:12.671432+00
6	223	[[0.41917, 0.78175], [0.42383, 0.7815], [0.43017, 0.773], [0.446, 0.75325], [0.456, 0.74425], [0.45583, 0.741], [0.47167, 0.7185], [0.493, 0.6945], [0.50683, 0.67875], [0.52383, 0.659], [0.53483, 0.64525], [0.53467, 0.64175], [0.55417, 0.61875], [0.574, 0.59725], [0.60333, 0.56225], [0.61117, 0.543], [0.62933, 0.5105], [0.65067, 0.47875], [0.68417, 0.42275], [0.69683, 0.39025], [0.7035, 0.37125], [0.71283, 0.354], [0.726, 0.33075]]	[{"grade": "", "height": "", "belayPosition": [0.47317, 0.717], "labelPosition": [null, null]}, {"grade": "5.4", "height": "", "belayPosition": [0.5305, 0.64975], "labelPosition": [0.504, 0.682]}, {"grade": "5.4", "height": "", "belayPosition": [0.56933, 0.60175], "labelPosition": [0.5535, 0.622]}, {"grade": "5.6/7", "height": "", "belayPosition": [0.59717, 0.56875], "labelPosition": [0.5855, 0.58375]}, {"grade": "5.4", "height": "", "belayPosition": [0.61933, 0.52725], "labelPosition": [0.611, 0.543]}, {"grade": "5.7/8", "height": "", "belayPosition": [0.63933, 0.49475], "labelPosition": [0.6325, 0.50375]}, {"grade": "5.4", "height": "", "belayPosition": [0.66083, 0.46175], "labelPosition": [0.65283, 0.4745]}, {"grade": "5.4", "height": "", "belayPosition": [0.6875, 0.41325], "labelPosition": [0.67383, 0.4375]}, {"grade": "5.6/7", "height": "", "belayPosition": [0.70583, 0.368], "labelPosition": [0.701, 0.3775]}, {"grade": "5.6/7", "height": "", "belayPosition": [0.72667, 0.3295], "labelPosition": [0.722, 0.3375]}]	[{"path": [[0.72867, 0.308], [0.7225, 0.2905], [0.72167, 0.272]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.71833, 0.2275], [0.70967, 0.22075], [0.70117, 0.22075]], "label": "Summit & Descent", "anchor": [null, null], "labelPosition": [0.68367, 0.2075]}, {"path": [[0.741, 0.252], [0.746, 0.269], [0.76, 0.279], [0.761, 0.29625], [0.77183, 0.30025]], "label": "Non Summit Descent", "anchor": [null, null], "labelPosition": [0.76333, 0.2875]}, {"path": [[0.93633, 0.3895], [0.97333, 0.40325], [0.976, 0.43625], [0.98433, 0.4565]], "label": "", "anchor": [null, null], "labelPosition": [0.938, 0.37768]}]	multipitch	2026-07-17 12:28:12.671432+00
7	224	[[0.46733, 0.82059], [0.46889, 0.79273], [0.46489, 0.75501], [0.46844, 0.73293], [0.47067, 0.69895], [0.476, 0.68977], [0.48044, 0.68739], [0.49222, 0.65817], [0.49933, 0.6473], [0.50289, 0.62283], [0.50778, 0.6157], [0.51333, 0.60211], [0.51556, 0.58784], [0.51222, 0.57424], [0.50778, 0.56337], [0.50333, 0.56337], [0.50333, 0.54366], [0.50489, 0.50357], [0.50489, 0.49168], [0.51289, 0.4876], [0.51289, 0.46959], [0.51556, 0.44444], [0.52844, 0.42644], [0.51889, 0.43765], [0.50956, 0.43425], [0.51, 0.39925], [0.51044, 0.37173], [0.50889, 0.34285], [0.50333, 0.31838], [0.49933, 0.298], [0.50378, 0.26062], [0.50289, 0.23921], [0.50222, 0.21305], [0.50844, 0.20251], [0.52044, 0.18722]]	[{"grade": "4a", "height": "27m", "belayPosition": [0.51444, 0.5841], "labelPosition": [0.504, 0.66599]}, {"grade": "4b", "height": "15m", "belayPosition": [0.52556, 0.42949], "labelPosition": [0.52289, 0.49745]}, {"grade": "4a", "height": "25m", "belayPosition": [0.51511, 0.19572], "labelPosition": [0.52289, 0.30717]}]	[{"path": [[0.79822, 0.71016], [0.76444, 0.73734], [0.73844, 0.75093], [0.70667, 0.76521], [0.68511, 0.75535], [0.65933, 0.76555]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}]	multipitch	2026-07-17 12:28:12.671432+00
8	225	[[0.5905, 0.94548], [0.582, 0.93061], [0.543, 0.91837], [0.5275, 0.90612], [0.5345, 0.84052], [0.533, 0.82362], [0.54325, 0.76093], [0.57575, 0.65306], [0.59325, 0.62303], [0.612, 0.58863], [0.62125, 0.57493], [0.62575, 0.54286], [0.635, 0.49679], [0.63575, 0.48367], [0.6405, 0.46181], [0.6355, 0.44023], [0.622, 0.42682], [0.6075, 0.41662], [0.59675, 0.41983], [0.58625, 0.41399], [0.58375, 0.40787], [0.58375, 0.40787], [0.58375, 0.38309], [0.5755, 0.3793], [0.577, 0.35102], [0.5625, 0.34431], [0.5595, 0.32391], [0.54575, 0.32332], [0.553, 0.2688], [0.547, 0.2586], [0.55425, 0.22945], [0.55325, 0.21603], [0.5545, 0.19592], [0.56875, 0.1965], [0.56875, 0.16676], [0.57325, 0.13673], [0.575, 0.10845], [0.58375, 0.08571], [0.59875, 0.05831]]	[{"grade": "4b", "height": "45m", "belayPosition": [0.583, 0.39359], "labelPosition": [0.65925, 0.53469]}, {"grade": "4b", "height": "25m", "belayPosition": [0.5655, 0.18863], "labelPosition": [0.57675, 0.27318]}, {"grade": "4b", "height": "12m", "belayPosition": [0.59875, 0.05802], "labelPosition": [0.5945, 0.12391]}]	[{"path": [[0.823, 0.51469], [0.82675, 0.51195], [0.85575, 0.5551], [0.853, 0.61195]], "label": "Devils Coach Road Approach", "anchor": [null, null], "labelPosition": [0.75925, 0.48029]}, {"path": [[0.82625, 0.95685], [0.76, 0.95773], [0.707, 0.94169]], "label": "Direct Approach", "anchor": [null, null], "labelPosition": [0.7755, 0.92985]}]	multipitch	2026-07-17 12:28:12.671432+00
9	248	[[0.68151, 0.85289]]	[{"grade": "Grade III", "height": "15m", "belayPosition": [0.68029, 0.85205], "labelPosition": [0.65223, 0.88898]}, {"grade": "Grade V+", "height": "40m", "belayPosition": [0.63606, 0.68206], "labelPosition": [0.71629, 0.73389]}, {"grade": "Grade V+", "height": "30m", "belayPosition": [0.54057, 0.53326], "labelPosition": [0.50641, 0.58951]}, {"grade": "Grade V+", "height": "30m", "belayPosition": [0.54301, 0.41406], "labelPosition": [0.60281, 0.46212]}, {"grade": "Grade V", "height": "30m", "belayPosition": [0.50458, 0.27639], "labelPosition": [0.56162, 0.32802]}, {"grade": "Grade V+", "height": "30m", "belayPosition": [0.48505, 0.19937], "labelPosition": [0.60555, 0.22875]}, {"grade": "Grade V", "height": "40m", "belayPosition": [0.44082, 0.24596], "labelPosition": [0.3795, 0.2852]}, {"grade": "Grade V+", "height": "45m", "belayPosition": [0.27151, 0.21322], "labelPosition": [0.31269, 0.18888]}]	[{"path": [[0.48017, 0.2042], [0.47376, 0.21133], [0.46217, 0.22455]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}]	multipitch	2026-07-17 12:28:12.671432+00
10	252	[[0.26831, 0.71109], [0.28017, 0.65844], [0.27389, 0.61389], [0.27761, 0.59595], [0.28784, 0.57223], [0.30458, 0.55622], [0.30388, 0.52112], [0.30365, 0.5001], [0.31249, 0.47348], [0.32667, 0.4378], [0.33899, 0.40309], [0.36782, 0.39846], [0.37828, 0.36837], [0.38549, 0.34079], [0.39014, 0.31707], [0.39572, 0.2918], [0.40804, 0.28042], [0.41479, 0.25477], [0.41711, 0.23259], [0.42734, 0.21929], [0.45199, 0.18168], [0.45943, 0.1622], [0.43641, 0.1433], [0.4292, 0.13462], [0.44641, 0.13076], [0.48105, 0.11379], [0.52778, 0.1082], [0.5594, 0.10762]]	[{"grade": "UIAA IV+", "height": "30m", "belayPosition": [0.30435, 0.52131], "labelPosition": [0.30551, 0.59479]}, {"grade": "UIAA IV", "height": "25m", "belayPosition": [0.37875, 0.36818], "labelPosition": [0.36689, 0.43645]}, {"grade": "UIAA IV", "height": "25m", "belayPosition": [0.41548, 0.25497], "labelPosition": [0.42409, 0.30222]}, {"grade": "UIAA IV", "height": "25m", "belayPosition": [0.43525, 0.14388], "labelPosition": [0.46431, 0.19634]}, {"grade": "UIAA III", "height": "25m", "belayPosition": [0.55871, 0.108], "labelPosition": [0.50174, 0.12498]}]	[{"path": [[0.56847, 0.11971], [0.57173, 0.13057]], "label": "< 60m", "anchor": [0.56545, 0.11398], "labelPosition": [0.57103, 0.1676]}, {"path": [[0.65101, 0.44031], [0.65589, 0.45246], [0.65775, 0.46532]], "label": "~60m", "anchor": [0.65031, 0.43452], "labelPosition": [0.63985, 0.48486]}, {"path": [[0.46501, 0.86577], [0.46315, 0.82989], [0.40549, 0.80366], [0.35341, 0.79229], [0.3076, 0.73308], [0.28203, 0.71919]], "label": "Grade II scramble", "anchor": [null, null], "labelPosition": [0.39061, 0.88582]}]	multipitch	2026-07-17 12:28:12.671432+00
11	253	[[0.50099, 0.81647], [0.48677, 0.79241], [0.4828, 0.75843], [0.47057, 0.71751], [0.47718, 0.68824], [0.45304, 0.63914], [0.42262, 0.61409], [0.39517, 0.60392], [0.37467, 0.59896], [0.37004, 0.57937], [0.36177, 0.56176], [0.35284, 0.55977], [0.36673, 0.54737], [0.38624, 0.53993], [0.41733, 0.53348], [0.44808, 0.52257], [0.46858, 0.5067], [0.49074, 0.48785], [0.49107, 0.45883], [0.4828, 0.41369], [0.47983, 0.37103], [0.48578, 0.34648], [0.47851, 0.31696], [0.47751, 0.29911], [0.47354, 0.27679], [0.47255, 0.25694], [0.46263, 0.2314], [0.45734, 0.21081], [0.47586, 0.20114], [0.49504, 0.18353], [0.4828, 0.16741], [0.46329, 0.14707]]	[{"grade": "UIAA IV+", "height": "35m", "belayPosition": [0.35384, 0.55977], "labelPosition": [0.52116, 0.70288]}, {"grade": "UIAA IV+", "height": "45m", "belayPosition": [0.47784, 0.31176], "labelPosition": [0.54134, 0.41741]}, {"grade": "UIAA V+", "height": "35m", "belayPosition": [0.46329, 0.14658], "labelPosition": [0.51157, 0.21974]}]	[{"path": [[0.46197, 0.15278], [0.45701, 0.18279]], "label": "30m", "anchor": [0.44808, 0.312], "labelPosition": [0.44345, 0.19965]}, {"path": [[0.44015, 0.31448], [0.40906, 0.33532], [0.37963, 0.36483], [0.35615, 0.38591], [0.32176, 0.39583], [0.29993, 0.39162], [0.32011, 0.4065], [0.30688, 0.41468]], "label": "UIAA II ", "anchor": [null, null], "labelPosition": [0.30985, 0.33978]}, {"path": [[0.29663, 0.4313], [0.29597, 0.4561]], "label": "~40m", "anchor": [0.29729, 0.42535], "labelPosition": [0.28241, 0.47842]}]	multipitch	2026-07-17 12:28:12.671432+00
12	254	[[0.75042, 0.92553], [0.76042, 0.89465], [0.75292, 0.83797], [0.745, 0.80387], [0.75583, 0.75594], [0.76333, 0.73705], [0.75375, 0.70065], [0.76958, 0.64857], [0.77792, 0.61124], [0.7775, 0.56424], [0.77625, 0.51954], [0.7725, 0.48682], [0.75625, 0.48313], [0.7525, 0.47438], [0.73208, 0.44166], [0.70917, 0.39926], [0.69708, 0.37023], [0.70125, 0.34074], [0.695, 0.32829], [0.695, 0.2965], [0.69042, 0.25364], [0.68167, 0.22046], [0.66, 0.19512], [0.66, 0.16747], [0.66, 0.14949]]	[{"grade": "3c", "height": "18m", "belayPosition": [0.74625, 0.81336], "labelPosition": [0.68708, 0.85207]}, {"grade": "4b", "height": "21m", "belayPosition": [0.77333, 0.6212], "labelPosition": [0.70292, 0.70046]}, {"grade": "4b", "height": "17m", "belayPosition": [0.7475, 0.46636], "labelPosition": [0.73583, 0.54101]}, {"grade": "4a", "height": "30m", "belayPosition": [0.65875, 0.15253], "labelPosition": [0.65417, 0.30599]}]	[{"path": [[0.6575, 0.16009], [0.65292, 0.18452], [0.65708, 0.20111]], "label": "30m", "anchor": [null, null], "labelPosition": [0.62125, 0.21309]}, {"path": [[0.69, 0.46774], [0.645, 0.47051]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.50458, 0.47977], [0.51, 0.50005], [0.51083, 0.52171]], "label": "~45m", "anchor": [0.50333, 0.47281], "labelPosition": [0.52042, 0.53871]}, {"path": [[0.55604, 0.8823], [0.55937, 0.90949]], "label": "~20m", "anchor": [0.55542, 0.87373], "labelPosition": [0.56542, 0.90138]}]	multipitch	2026-07-17 12:28:12.671432+00
13	255	[[0.77266, 0.76182], [0.76462, 0.74359], [0.75585, 0.71396], [0.74342, 0.72764], [0.73173, 0.67635], [0.70687, 0.62393], [0.69006, 0.58405], [0.69956, 0.57493], [0.70322, 0.56467], [0.69079, 0.53162], [0.69079, 0.52593], [0.70249, 0.53276], [0.70833, 0.52821], [0.70687, 0.50655], [0.70614, 0.46895], [0.70029, 0.44957], [0.6886, 0.42222], [0.67836, 0.41083], [0.67105, 0.39259], [0.65789, 0.3812], [0.63158, 0.34359], [0.61988, 0.32764], [0.60234, 0.31168], [0.58918, 0.29459], [0.57968, 0.26496], [0.55044, 0.23647], [0.53947, 0.21026], [0.52778, 0.17835], [0.52851, 0.16695], [0.52924, 0.14986]]	[{"grade": "4c", "height": "45m", "belayPosition": [0.69079, 0.58405], "labelPosition": [0.73904, 0.65698]}, {"grade": "4a", "height": "12m", "belayPosition": [0.70687, 0.47009], "labelPosition": [0.72588, 0.54872]}, {"grade": "4c", "height": "45m", "belayPosition": [0.62354, 0.32877], "labelPosition": [0.70249, 0.39487]}, {"grade": "", "height": "45m", "belayPosition": [0.54825, 0.23533], "labelPosition": [0.58991, 0.25584]}, {"grade": "", "height": "15m", "belayPosition": [0.52851, 0.15214], "labelPosition": [0.54605, 0.19316]}]	[{"path": [[0.52851, 0.88262], [0.58699, 0.85299], [0.62646, 0.87009], [0.65058, 0.85983]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.70175, 0.82473], [0.75512, 0.77459]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.51389, 0.1453], [0.50439, 0.16809], [0.46637, 0.16581], [0.45468, 0.19886], [0.42982, 0.20912]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}]	multipitch	2026-07-17 12:28:12.671432+00
14	256	[[0.17778, 0.94274], [0.18389, 0.91142], [0.20917, 0.87201], [0.22139, 0.83833], [0.23389, 0.78545], [0.23333, 0.76255], [0.275, 0.76423], [0.33056, 0.75312], [0.375, 0.7228], [0.41389, 0.70866], [0.48889, 0.66992], [0.51944, 0.6487], [0.50778, 0.62209], [0.47278, 0.59919], [0.43972, 0.57663], [0.41389, 0.55103], [0.4175, 0.48131], [0.45056, 0.46514], [0.48139, 0.43819], [0.51389, 0.40115], [0.50917, 0.37454], [0.52028, 0.35231], [0.53417, 0.34725], [0.61167, 0.22085], [0.62306, 0.20569], [0.62639, 0.19222], [0.63806, 0.17942], [0.65278, 0.18717], [0.67694, 0.15753], [0.67833, 0.14348], [0.70278, 0.12991], [0.73611, 0.12149], [0.74778, 0.12418]]	[{"grade": "4a", "height": "28m", "belayPosition": [0.41167, 0.53318], "labelPosition": [0.38528, 0.67295]}, {"grade": "3c", "height": "16m", "belayPosition": [0.53417, 0.34725], "labelPosition": [0.52278, 0.43213]}, {"grade": "4a", "height": "10m", "belayPosition": [0.61194, 0.22398], "labelPosition": [0.60694, 0.29471]}, {"grade": "3b", "height": "12m", "belayPosition": [0.74917, 0.12529], "labelPosition": [0.65472, 0.12193]}]	[{"path": [[0.80472, 0.12529], [0.8325, 0.15527], [0.86056, 0.14887], [0.91944, 0.15056]], "label": "10min walk off", "anchor": [null, null], "labelPosition": [0.89389, 0.11485]}]	multipitch	2026-07-17 12:28:12.671432+00
15	257	[[0.12492, 0.9501], [0.12262, 0.90138], [0.12262, 0.83929], [0.12755, 0.74028], [0.13083, 0.6947], [0.14464, 0.64597], [0.16831, 0.61336], [0.20151, 0.53163], [0.21762, 0.49862], [0.23603, 0.48448], [0.2574, 0.42868], [0.27613, 0.41572], [0.28665, 0.39018], [0.29849, 0.35324], [0.30966, 0.34145], [0.31328, 0.32377], [0.33432, 0.31081], [0.35569, 0.31159], [0.37081, 0.30609], [0.38527, 0.2664], [0.39283, 0.23733], [0.40697, 0.21572], [0.42078, 0.18507], [0.43491, 0.15363], [0.45759, 0.14067], [0.47107, 0.11356], [0.48093, 0.11631]]	[{"grade": "~30m 4b", "height": "La Savonnette ", "belayPosition": [0.47337, 0.11356], "labelPosition": [0.44773, 0.17917]}, {"grade": "", "height": "~35m", "belayPosition": [0.36095, 0.30884], "labelPosition": [0.31657, 0.39528]}, {"grade": "3c", "height": "~20m", "belayPosition": [0.23077, 0.48684], "labelPosition": [0.20874, 0.57878]}, {"grade": "3c", "height": "~15m", "belayPosition": [0.12558, 0.76464], "labelPosition": [0.15286, 0.85108]}]	[{"path": [[0.3478, 0.29391], [0.32873, 0.28723], [0.35503, 0.27859]], "label": "End Le Merinos", "anchor": [null, null], "labelPosition": [0.26298, 0.2554]}, {"path": [[0.51841, 0.10334], [0.55128, 0.09352], [0.58941, 0.08291], [0.62623, 0.09194]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}]	multipitch	2026-07-17 12:28:12.671432+00
16	258	[[0.98496, 0.80501], [0.94878, 0.76834], [0.92586, 0.71288], [0.91762, 0.69141], [0.9033, 0.67218], [0.87607, 0.678], [0.84277, 0.68605], [0.81089, 0.66816], [0.77865, 0.63685], [0.74749, 0.61091], [0.71096, 0.55859], [0.66798, 0.5322], [0.63073, 0.46869], [0.60996, 0.44589], [0.59169, 0.42844], [0.56769, 0.40385], [0.56232, 0.39893], [0.55444, 0.37835], [0.56447, 0.322], [0.56877, 0.29249], [0.57844, 0.2822], [0.57844, 0.27683], [0.55946, 0.26029], [0.54513, 0.25581], [0.52507, 0.24553], [0.50967, 0.23658], [0.50358, 0.22138], [0.47887, 0.2178], [0.46383, 0.21377], [0.45021, 0.21646], [0.4538, 0.20081], [0.46956, 0.17755], [0.476, 0.14758], [0.49105, 0.14267], [0.51862, 0.12612], [0.53403, 0.11807], [0.54334, 0.10376], [0.55802, 0.08542], [0.56877, 0.06977], [0.56698, 0.06328], [0.56662, 0.05792], [0.55587, 0.05523], [0.54262, 0.0597]]	[{"grade": "UIAA III-", "height": "~50m", "belayPosition": [0.80516, 0.66369], "labelPosition": [0.87428, 0.75581]}, {"grade": "UIAA III-", "height": "~50m", "belayPosition": [0.66798, 0.5322], "labelPosition": [0.69019, 0.60461]}, {"grade": "UIAA III-", "height": "~50m", "belayPosition": [0.59169, 0.43113], "labelPosition": [0.57514, 0.48117]}, {"grade": "UIAA III-", "height": "~50m", "belayPosition": [0.55659, 0.38283], "labelPosition": [0.51934, 0.41154]}, {"grade": "", "height": "", "belayPosition": [0.56017, 0.35331], "labelPosition": [null, null]}, {"grade": "", "height": "", "belayPosition": [0.56554, 0.32424], "labelPosition": [null, null]}, {"grade": "", "height": "", "belayPosition": [0.56948, 0.29606], "labelPosition": [null, null]}, {"grade": "~100m UIAA III", "height": "Pitches 5-8", "belayPosition": [0.5788, 0.27683], "labelPosition": [0.59527, 0.31753]}, {"grade": "", "height": "", "belayPosition": [0.55731, 0.25939], "labelPosition": [null, null]}, {"grade": "", "height": "", "belayPosition": [0.53689, 0.25], "labelPosition": [null, null]}, {"grade": "", "height": "", "belayPosition": [0.50681, 0.23032], "labelPosition": [null, null]}, {"grade": "~170m UIAA II", "height": "pitches 9-13", "belayPosition": [0.48352, 0.21914], "labelPosition": [0.55516, 0.21288]}, {"grade": "", "height": "", "belayPosition": [0.45093, 0.21288], "labelPosition": [null, null]}, {"grade": "UIAA III", "height": "~30m", "belayPosition": [0.4563, 0.19589], "labelPosition": [0.39434, 0.21735]}, {"grade": "UIAA IV-", "height": "~30m", "belayPosition": [0.47493, 0.15474], "labelPosition": [0.48245, 0.1686]}, {"grade": "", "height": "~20m UIAA III", "belayPosition": [0.51755, 0.12567], "labelPosition": [0.54262, 0.12925]}, {"grade": "", "height": "~50m UIAA II", "belayPosition": [0.56662, 0.06082], "labelPosition": [0.57307, 0.09839]}, {"grade": "", "height": "~30m UIAA II", "belayPosition": [0.55158, 0.09213], "labelPosition": [0.57736, 0.07513]}, {"grade": "", "height": "~40m UIAA III", "belayPosition": [0.54011, 0.05859], "labelPosition": [0.56125, 0.04204]}]	[{"path": [[0.47457, 0.16234], [0.47636, 0.18023]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.56877, 0.32804], [0.57235, 0.3352], [0.57056, 0.34191]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.59742, 0.43225], [0.6096, 0.43761], [0.61891, 0.45237]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}]	multipitch	2026-07-17 12:28:12.671432+00
17	259	[[0.51922, 0.71035], [0.53285, 0.66931], [0.55912, 0.61054], [0.56253, 0.60914], [0.5635, 0.632], [0.56934, 0.63806], [0.5854, 0.63806], [0.59757, 0.60681], [0.59805, 0.57836], [0.59611, 0.52425], [0.60341, 0.50793], [0.60681, 0.47668], [0.61314, 0.44543], [0.61509, 0.43377], [0.64526, 0.39879], [0.64574, 0.3708], [0.6545, 0.34422], [0.6691, 0.33116], [0.67299, 0.30737], [0.67251, 0.26259], [0.66959, 0.23647], [0.6764, 0.14459]]	[{"grade": "4b", "height": "25m", "belayPosition": [0.56058, 0.60961], "labelPosition": [0.55377, 0.66698]}, {"grade": "5b", "height": "35m", "belayPosition": [0.60487, 0.48461], "labelPosition": [0.61849, 0.54104]}, {"grade": "4b", "height": "20m", "belayPosition": [0.64477, 0.38526], "labelPosition": [0.64234, 0.4361]}, {"grade": "4b", "height": "35m", "belayPosition": [0.67105, 0.31063], "labelPosition": [0.6764, 0.34981]}, {"grade": "4c", "height": "20m", "belayPosition": [0.67591, 0.14552], "labelPosition": [0.69246, 0.20616]}]	[{"path": [[0.51338, 0.79058], [0.50754, 0.76959], [0.50754, 0.73134]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.67299, 0.15392], [0.66569, 0.15765], [0.66618, 0.16604]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.66618, 0.31763], [0.65937, 0.32416]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.6399, 0.39179], [0.63406, 0.40019]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.59903, 0.49067], [0.59367, 0.5014]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.54939, 0.60774], [0.53869, 0.61194], [0.53479, 0.62687]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}]	multipitch	2026-07-17 12:28:12.671432+00
18	260	[[0.764, 0.83767], [0.73475, 0.74567], [0.718, 0.67], [0.703, 0.60767], [0.69725, 0.60333], [0.6865, 0.559], [0.678, 0.53667], [0.673, 0.53333], [0.6555, 0.49], [0.6365, 0.48567], [0.629, 0.481], [0.629, 0.40667], [0.6355, 0.331], [0.664, 0.32233], [0.66225, 0.299], [0.6555, 0.27233], [0.6455, 0.27567], [0.6665, 0.259], [0.6615, 0.22567], [0.66225, 0.19567], [0.66975, 0.15667], [0.6655, 0.131], [0.66225, 0.12767]]	[{"grade": "", "height": "20m", "belayPosition": [0.723, 0.699], "labelPosition": [0.744, 0.73433]}, {"grade": "3b", "height": "20m", "belayPosition": [0.698, 0.60433], "labelPosition": [0.723, 0.62233]}, {"grade": "4b", "height": "20m", "belayPosition": [0.64975, 0.48667], "labelPosition": [0.683, 0.50667]}, {"grade": "3c", "height": "30m", "belayPosition": [0.63975, 0.33], "labelPosition": [0.64975, 0.381]}, {"grade": "4a", "height": "15m", "belayPosition": [0.649, 0.27233], "labelPosition": [0.679, 0.29333]}, {"grade": "4b", "height": "15", "belayPosition": [0.664, 0.129], "labelPosition": [0.6855, 0.18333]}]	[{"path": [[0.64975, 0.11233], [0.643, 0.11], [0.638, 0.089], [0.62225, 0.07667]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.5155, 0.079], [0.5065, 0.04233], [0.49725, 0.02767], [0.4865, 0.03567]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}]	multipitch	2026-07-17 12:28:12.671432+00
19	261	[[0.54241, 0.86772], [0.53869, 0.85284], [0.52158, 0.83763], [0.51017, 0.82771], [0.49727, 0.80985], [0.48537, 0.80952], [0.48686, 0.79332], [0.48041, 0.7748], [0.47817, 0.75761], [0.46875, 0.72123], [0.47173, 0.69411], [0.46453, 0.67097], [0.47297, 0.65179], [0.48537, 0.64583], [0.46429, 0.62798], [0.43477, 0.62698], [0.40848, 0.61144], [0.43973, 0.58333], [0.45188, 0.56581], [0.47173, 0.55919], [0.49355, 0.53175], [0.48785, 0.51852], [0.46925, 0.48876], [0.48189, 0.47057], [0.49529, 0.43022], [0.50174, 0.39815], [0.49281, 0.39054], [0.48289, 0.38194], [0.46255, 0.37368], [0.46949, 0.35747], [0.47321, 0.35384], [0.48165, 0.34722], [0.48785, 0.33664], [0.48909, 0.32275], [0.49653, 0.31382], [0.49653, 0.30026], [0.49851, 0.292], [0.50546, 0.28704]]	[{"grade": "5a", "height": "30m", "belayPosition": [0.47123, 0.63459], "labelPosition": [0.48438, 0.73347]}, {"grade": "4b", "height": "30m", "belayPosition": [0.48859, 0.51852], "labelPosition": [0.48313, 0.56548]}, {"grade": "4a", "height": "45m", "belayPosition": [0.46751, 0.35913], "labelPosition": [0.50719, 0.41534]}, {"grade": "4b", "height": "15m", "belayPosition": [0.50595, 0.28571], "labelPosition": [0.50595, 0.32176]}]	\N	multipitch	2026-07-17 12:28:12.671432+00
21	263	[[0.72145, 0.86121], [0.71791, 0.83956], [0.73237, 0.81248], [0.68988, 0.79424], [0.67099, 0.77087], [0.65152, 0.75834], [0.61847, 0.73098], [0.60165, 0.70561], [0.59398, 0.68966], [0.59103, 0.66372], [0.59959, 0.62553], [0.60726, 0.60901], [0.61906, 0.60359], [0.63618, 0.57196], [0.64768, 0.53662], [0.63293, 0.52494], [0.61109, 0.50499], [0.59014, 0.46509], [0.58631, 0.45426], [0.53674, 0.43232], [0.4851, 0.42092], [0.4553, 0.40467], [0.43022, 0.39156], [0.44526, 0.37019], [0.45648, 0.32972], [0.45854, 0.29581], [0.45235, 0.28926], [0.44526, 0.27558], [0.41989, 0.25962], [0.40041, 0.25677], [0.39687, 0.24793], [0.39245, 0.23083], [0.39304, 0.21516], [0.41369, 0.20177], [0.42431, 0.19436], [0.43081, 0.18182]]	[{"grade": "", "height": "25m", "belayPosition": [0.66922, 0.77087], "labelPosition": [0.73975, 0.82445]}, {"grade": "3c", "height": "40m", "belayPosition": [0.61316, 0.60587], "labelPosition": [0.55474, 0.6851]}, {"grade": "", "height": "30m", "belayPosition": [0.64296, 0.53434], "labelPosition": [0.59693, 0.57253]}, {"grade": "", "height": "25m", "belayPosition": [0.5866, 0.45711], "labelPosition": [0.6229, 0.49587]}, {"grade": "", "height": "25m", "belayPosition": [0.43464, 0.39527], "labelPosition": [0.4733, 0.43688]}, {"grade": "3c", "height": "45m", "belayPosition": [0.45648, 0.29268], "labelPosition": [0.46592, 0.33713]}, {"grade": "", "height": "30m", "belayPosition": [0.39805, 0.25306], "labelPosition": [0.40572, 0.27757]}, {"grade": "3c", "height": "30m", "belayPosition": [0.4314, 0.17982], "labelPosition": [0.43582, 0.1992]}]	[{"path": [[0.45146, 0.15702], [0.46857, 0.14249], [0.491, 0.13508]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}]	multipitch	2026-07-17 12:28:12.671432+00
22	264	[[0.38113, 0.81209], [0.38082, 0.78881], [0.38358, 0.75735], [0.37439, 0.72917], [0.37194, 0.69444], [0.37102, 0.67075], [0.37255, 0.64216], [0.37347, 0.61887], [0.36918, 0.59191], [0.36612, 0.57802], [0.3652, 0.56904], [0.37255, 0.55596], [0.37071, 0.52859], [0.37623, 0.50123], [0.37592, 0.48652], [0.375, 0.46242], [0.37377, 0.44158], [0.36949, 0.38766], [0.36918, 0.34109], [0.36765, 0.31904], [0.36275, 0.29534], [0.35784, 0.28391], [0.35509, 0.28962], [0.34191, 0.29616], [0.33762, 0.2884], [0.33854, 0.26838], [0.34191, 0.25449], [0.34099, 0.23938], [0.33977, 0.21814], [0.34007, 0.21119], [0.33793, 0.19199], [0.33854, 0.18668], [0.34344, 0.18137], [0.34222, 0.17443]]	[]	\N	multipitch	2026-07-17 12:28:12.671432+00
23	265	[[0.28875, 0.781], [0.30925, 0.757], [0.319, 0.708], [0.328, 0.65367], [0.33875, 0.64033], [0.3425, 0.615], [0.34825, 0.58433], [0.33725, 0.57533], [0.32475, 0.56967], [0.328, 0.55333], [0.33775, 0.505], [0.34725, 0.487], [0.35625, 0.468], [0.3565, 0.44433], [0.36625, 0.44733], [0.36375, 0.431], [0.37425, 0.39833], [0.38575, 0.363], [0.401, 0.34333], [0.414, 0.34], [0.4215, 0.268], [0.43, 0.22967], [0.433, 0.20533], [0.441, 0.172], [0.45275, 0.114], [0.45975, 0.083]]	[{"grade": "3c", "height": "18m", "belayPosition": [0.34125, 0.578], "labelPosition": [0.34075, 0.66333]}, {"grade": "3a", "height": "16m", "belayPosition": [0.36425, 0.44367], "labelPosition": [0.3575, 0.49933]}, {"grade": "3a", "height": "13m", "belayPosition": [0.40975, 0.341], "labelPosition": [0.39175, 0.38667]}, {"grade": "3c", "height": "24m", "belayPosition": [0.45925, 0.08367], "labelPosition": [0.4475, 0.20167]}]	[{"path": [[0.89775, 0.17367], [0.87775, 0.205]], "label": "A. Abseil (50m to ledge)", "anchor": [0.89825, 0.16567], "labelPosition": [0.85, 0.25433]}, {"path": [[0.30625, 0.91233], [0.27175, 0.90267], [0.24575, 0.87667], [0.25825, 0.854]], "label": "B. Low tide scramble", "anchor": [null, null], "labelPosition": [0.304, 0.93567]}, {"path": [[0.5445, 0.21967], [0.53, 0.243], [0.5485, 0.289], [0.53, 0.32567]], "label": "C. Scramble from top", "anchor": [null, null], "labelPosition": [0.55, 0.26833]}, {"path": [[0.609, 0.56933], [0.5785, 0.60067], [0.54675, 0.628]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.47075, 0.08067], [0.5125, 0.08533], [0.51925, 0.11667]], "label": "Walk Off", "anchor": [null, null], "labelPosition": [0.5235, 0.096]}]	multipitch	2026-07-17 12:28:12.671432+00
24	266	[[0.55568, 0.91367], [0.55158, 0.89216], [0.54995, 0.86138], [0.5565, 0.84967], [0.5423, 0.83851], [0.54694, 0.80746], [0.54503, 0.78322], [0.52757, 0.77533], [0.52538, 0.75899], [0.54121, 0.74319], [0.55022, 0.73203], [0.5554, 0.7018], [0.56114, 0.68437], [0.55267, 0.66993], [0.55104, 0.65169], [0.55977, 0.63589], [0.55377, 0.62527], [0.5565, 0.61683], [0.52811, 0.59477], [0.54039, 0.57734], [0.53493, 0.52614], [0.54012, 0.48829], [0.56086, 0.48666], [0.59389, 0.49156], [0.59743, 0.46296], [0.59471, 0.4488], [0.60617, 0.42347], [0.61709, 0.39542], [0.63619, 0.36683], [0.64711, 0.36574]]	[{"grade": "3b", "height": "35m", "belayPosition": [0.54258, 0.78322], "labelPosition": [0.57096, 0.84232]}, {"grade": "3b", "height": "45m", "belayPosition": [0.5524, 0.62718], "labelPosition": [0.57942, 0.70724]}, {"grade": "3c", "height": "25m", "belayPosition": [0.53684, 0.50626], "labelPosition": [0.56332, 0.56672]}, {"grade": "3b", "height": "20m", "belayPosition": [0.59279, 0.48121], "labelPosition": [0.60371, 0.51934]}, {"grade": "3b", "height": "30m", "belayPosition": [0.64738, 0.36411], "labelPosition": [0.62254, 0.436]}]	[{"path": [[0.65502, 0.36329], [0.68068, 0.35893], [0.70906, 0.3622], [0.75136, 0.38344], [0.79967, 0.42756], [0.82396, 0.44853]], "label": "Steep Scramble Off", "anchor": [null, null], "labelPosition": [0.79749, 0.49292]}, {"path": [[0.63783, 0.34559], [0.57806, 0.33469], [0.5161, 0.30664], [0.47789, 0.29684]], "label": "To Summit", "anchor": [null, null], "labelPosition": [0.51447, 0.29031]}]	multipitch	2026-07-17 12:28:12.671432+00
25	267	[[0.35325, 0.92713], [0.3525, 0.90695], [0.34575, 0.89873], [0.34475, 0.87108], [0.344, 0.85389], [0.338, 0.83371], [0.3315, 0.80232], [0.3255, 0.77541], [0.32075, 0.74552], [0.315, 0.72758], [0.3065, 0.70366], [0.30225, 0.68572], [0.29725, 0.6633], [0.28975, 0.66106], [0.29125, 0.65097], [0.29075, 0.62967], [0.2935, 0.61734], [0.301, 0.58744], [0.3075, 0.55643], [0.311, 0.52504], [0.3115, 0.50374], [0.30625, 0.4787], [0.3145, 0.4488], [0.33375, 0.39873], [0.342, 0.38453], [0.34775, 0.37332], [0.3525, 0.358], [0.35025, 0.34081], [0.34875, 0.32474], [0.352, 0.30717], [0.3565, 0.28662], [0.3595, 0.26831], [0.374, 0.25075], [0.3685, 0.24851], [0.369, 0.24066], [0.37875, 0.22795], [0.3945, 0.22048], [0.4035, 0.21562], [0.42225, 0.2059], [0.43825, 0.20254], [0.441, 0.19208], [0.4365, 0.18274], [0.42975, 0.18161]]	[{"grade": "IV", "height": "25m", "belayPosition": [0.344, 0.85949], "labelPosition": [0.3665, 0.9077]}, {"grade": "IV+", "height": "35m", "belayPosition": [0.3065, 0.70478], "labelPosition": [0.3385, 0.76682]}, {"grade": "IV", "height": "25m", "belayPosition": [0.297, 0.60202], "labelPosition": [0.31775, 0.63901]}, {"grade": "IV", "height": "40m", "belayPosition": [0.3115, 0.51831], "labelPosition": [0.3245, 0.55531]}, {"grade": "III+", "height": "50m", "belayPosition": [0.30725, 0.46226], "labelPosition": [0.3275, 0.47982]}, {"grade": "IV", "height": "35m", "belayPosition": [0.344, 0.38079], "labelPosition": [0.34525, 0.41442]}, {"grade": "IV", "height": "45m", "belayPosition": [0.37325, 0.25187], "labelPosition": [0.37075, 0.29858]}, {"grade": "III", "height": "~120m", "belayPosition": [0.42975, 0.18124], "labelPosition": [0.424, 0.23169]}]	\N	multipitch	2026-07-17 12:28:12.671432+00
26	268	[[0.45713, 0.77897], [0.45587, 0.7523], [0.45537, 0.71663], [0.44738, 0.6883], [0.43862, 0.6843], [0.41737, 0.67197], [0.39387, 0.67197], [0.37162, 0.66663], [0.35313, 0.6639], [0.32913, 0.63757], [0.31612, 0.5899], [0.29587, 0.56197], [0.29563, 0.50163], [0.30138, 0.4936], [0.32937, 0.4715], [0.34987, 0.46917], [0.36512, 0.47083], [0.39387, 0.46983], [0.39637, 0.45083], [0.39787, 0.4245], [0.40563, 0.38217], [0.40413, 0.34717], [0.42013, 0.34117], [0.44338, 0.33293], [0.44962, 0.32893], [0.44788, 0.3159], [0.44662, 0.29757], [0.44538, 0.28157], [0.44262, 0.27323], [0.43812, 0.26423], [0.43438, 0.25123], [0.43612, 0.24423], [0.44512, 0.23957], [0.44988, 0.21923], [0.45937, 0.20723], [0.46437, 0.18393], [0.46713, 0.16693], [0.47213, 0.1576], [0.47187, 0.1486], [0.46937, 0.13493], [0.47437, 0.1266], [0.48337, 0.11863], [0.49188, 0.10163], [0.49362, 0.09597], [0.51138, 0.0873], [0.52087, 0.0823], [0.53338, 0.07263], [0.57237, 0.05763], [0.57988, 0.0603], [0.58737, 0.05397]]	[{"grade": "III+", "height": "25m", "belayPosition": [0.41875, 0.67267], "labelPosition": [0.465, 0.73033]}, {"grade": "", "height": "40m", "belayPosition": [0.29625, 0.55533], "labelPosition": [0.34325, 0.62767]}, {"grade": "III+", "height": "20m", "belayPosition": [0.32075, 0.47867], "labelPosition": [0.31375, 0.51867]}, {"grade": "", "height": "20m", "belayPosition": [0.39325, 0.466], "labelPosition": [0.35, 0.5]}, {"grade": "IV-", "height": "40m", "belayPosition": [0.40875, 0.343], "labelPosition": [0.41375, 0.409]}, {"grade": "", "height": "15m", "belayPosition": [0.44825, 0.329], "labelPosition": [0.425, 0.36667]}, {"grade": "IV", "height": "40m", "belayPosition": [0.445, 0.23833], "labelPosition": [0.45875, 0.269]}, {"grade": "IV+", "height": "25m", "belayPosition": [0.47125, 0.13167], "labelPosition": [0.4795, 0.19]}, {"grade": "", "height": "", "belayPosition": [0.58825, 0.05433], "labelPosition": [null, null]}]	\N	multipitch	2026-07-17 12:28:12.671432+00
27	269	[[0.19094, 0.94868], [0.1875, 0.92595], [0.17406, 0.91129], [0.17406, 0.90176], [0.16406, 0.89553], [0.1625, 0.86804], [0.1625, 0.84018], [0.16906, 0.83981], [0.17406, 0.81048], [0.17656, 0.78519], [0.18656, 0.77933], [0.18906, 0.75], [0.19812, 0.739], [0.20813, 0.72837], [0.22312, 0.72874], [0.23312, 0.72177], [0.2425, 0.67962], [0.25344, 0.65396], [0.25594, 0.62867], [0.25594, 0.61107], [0.25688, 0.6074], [0.24844, 0.58101], [0.24438, 0.56122], [0.24438, 0.54985], [0.2475, 0.52089], [0.24563, 0.51173], [0.24438, 0.5011], [0.25312, 0.49157], [0.26156, 0.48057], [0.26406, 0.46811], [0.2625, 0.46408], [0.26438, 0.45711], [0.26937, 0.44648], [0.27094, 0.43878], [0.26594, 0.42522], [0.2725, 0.3805], [0.27344, 0.3563], [0.27313, 0.34128], [0.27437, 0.31708], [0.27687, 0.30425], [0.28437, 0.27896], [0.28563, 0.27493]]	[{"grade": "IV+", "height": "55m", "belayPosition": [0.16344, 0.84238], "labelPosition": [0.13062, 0.88856]}, {"grade": "IV", "height": "30m", "belayPosition": [0.17719, 0.78446], "labelPosition": [0.18969, 0.81342]}, {"grade": "III+", "height": "~50m", "belayPosition": [0.23438, 0.71848], "labelPosition": [0.20688, 0.74707]}, {"grade": "IV", "height": "20m", "belayPosition": [0.24375, 0.67632], "labelPosition": [0.25094, 0.68988]}, {"grade": "IV", "height": "45m", "belayPosition": [0.25656, 0.61327], "labelPosition": [0.26344, 0.64003]}, {"grade": "IV+", "height": "50m", "belayPosition": [0.245, 0.54729], "labelPosition": [0.26687, 0.56708]}, {"grade": "IV+", "height": "30m", "belayPosition": [0.26281, 0.46518], "labelPosition": [0.26344, 0.50073]}, {"grade": "IV+", "height": "50m", "belayPosition": [0.27094, 0.39003], "labelPosition": [0.2825, 0.41239]}, {"grade": "IV", "height": "30m", "belayPosition": [0.27344, 0.32551], "labelPosition": [0.28187, 0.34457]}, {"grade": "IV", "height": "40m", "belayPosition": [0.28406, 0.27749], "labelPosition": [0.29, 0.29949]}]	[{"path": [[0.30156, 0.26393], [0.31656, 0.25953], [0.33563, 0.2478]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}]	multipitch	2026-07-17 12:28:12.671432+00
28	270	[[0.10183, 0.80173], [0.1, 0.78253], [0.09283, 0.77014], [0.09283, 0.76208], [0.0875, 0.75682], [0.08667, 0.73358], [0.08667, 0.71004], [0.09017, 0.70973], [0.09283, 0.68494], [0.09417, 0.66357], [0.0995, 0.65861], [0.10083, 0.63383], [0.10567, 0.62454], [0.111, 0.61555], [0.119, 0.61586], [0.12433, 0.60998], [0.12933, 0.57435], [0.13517, 0.55266], [0.1365, 0.53129], [0.1365, 0.51642], [0.137, 0.51332], [0.1325, 0.49102], [0.13033, 0.47429], [0.13033, 0.46468], [0.132, 0.44021], [0.131, 0.43247], [0.13033, 0.42348], [0.135, 0.41543], [0.1395, 0.40613], [0.14083, 0.3956], [0.14, 0.39219], [0.141, 0.38631], [0.14367, 0.37732], [0.1445, 0.37082], [0.14183, 0.35936], [0.14533, 0.32156], [0.14583, 0.30112], [0.14567, 0.28841], [0.14633, 0.26797], [0.14767, 0.25713], [0.15167, 0.23575], [0.15233, 0.23234]]	[{"grade": "E1+", "height": "20m", "belayPosition": [0.08717, 0.7119], "labelPosition": [0.06967, 0.75093]}]	\N	multipitch	2026-07-17 12:28:12.671432+00
30	273	[[0.08721, 0.59786], [0.08887, 0.54384], [0.14182, 0.51683], [0.19207, 0.47951], [0.23754, 0.44883], [0.24751, 0.44476], [0.24689, 0.42522], [0.25997, 0.40934], [0.27886, 0.39482], [0.30004, 0.39034], [0.29963, 0.36319], [0.29713, 0.34745], [0.29817, 0.32885], [0.28841, 0.31881], [0.26474, 0.32424], [0.24232, 0.3279], [0.24564, 0.27239], [0.27803, 0.25774], [0.30419, 0.24104], [0.32205, 0.21607], [0.34302, 0.20575], [0.36607, 0.20033], [0.37811, 0.18689], [0.37978, 0.1592], [0.37853, 0.13477], [0.34884, 0.11482], [0.33202, 0.11238], [0.31188, 0.08836], [0.28011, 0.06189]]	[{"grade": "Grade IV", "height": "~30m", "belayPosition": [0.1358, 0.51873], "labelPosition": [0.11566, 0.56352]}, {"grade": "III+", "height": "48m", "belayPosition": [0.29755, 0.3883], "labelPosition": [0.23858, 0.47462]}, {"grade": "Grade IV+", "height": "~25m", "belayPosition": [0.24668, 0.32424], "labelPosition": [0.31499, 0.34514]}, {"grade": "Grade IV+", "height": "20m", "belayPosition": [0.26703, 0.26031], "labelPosition": [0.26495, 0.29031]}, {"grade": "Grade IV", "height": "25m", "belayPosition": [0.36607, 0.19734], "labelPosition": [0.34157, 0.22978]}, {"grade": "Grade IV+", "height": "~30m", "belayPosition": [0.36898, 0.12907], "labelPosition": [0.3939, 0.16694]}, {"grade": "Grade IV+", "height": "~30m", "belayPosition": [0.27928, 0.06202], "labelPosition": [0.33036, 0.07736]}]	\N	multipitch	2026-07-17 12:28:12.671432+00
31	274	[[0.47511, 0.69933], [0.47405, 0.68206], [0.47511, 0.6669], [0.4737, 0.65668], [0.47861, 0.65492], [0.47861, 0.6447], [0.47756, 0.63377], [0.47791, 0.61544], [0.47791, 0.59817], [0.48633, 0.58724], [0.48808, 0.57244], [0.48843, 0.55728], [0.48422, 0.54212], [0.48983, 0.53507], [0.49123, 0.51322], [0.49579, 0.49947], [0.50175, 0.48008], [0.50316, 0.46528], [0.49755, 0.46176], [0.4979, 0.44766]]	[{"grade": "Severe 3c", "height": "28m", "belayPosition": [0.48808, 0.56539], "labelPosition": [0.50596, 0.67289]}, {"grade": "Severe 3c", "height": "25m", "belayPosition": [0.48948, 0.52697], "labelPosition": [0.51648, 0.54635]}, {"grade": "Severe 3c", "height": "18m", "belayPosition": [0.49755, 0.44131], "labelPosition": [0.52595, 0.48008]}]	\N	multipitch	2026-07-17 12:28:12.671432+00
32	276	[[0.48678, 0.82026], [0.4746, 0.76691], [0.46521, 0.74151], [0.45894, 0.72658], [0.45233, 0.71832], [0.44607, 0.71578], [0.43493, 0.72467], [0.4412, 0.70054], [0.44885, 0.67641], [0.42658, 0.65957], [0.39005, 0.65735], [0.38344, 0.63607], [0.373, 0.61258], [0.29715, 0.61067], [0.30376, 0.59162], [0.30689, 0.56812], [0.34551, 0.56589], [0.36395, 0.55129], [0.37056, 0.53858], [0.37474, 0.51762], [0.37091, 0.49921], [0.38727, 0.47698], [0.43702, 0.45443], [0.45999, 0.43792], [0.50209, 0.44395], [0.51218, 0.39409], [0.5174, 0.36075], [0.51914, 0.32391], [0.51949, 0.30073], [0.50174, 0.29533], [0.48921, 0.2766], [0.49478, 0.26008], [0.48852, 0.24198], [0.47634, 0.23245], [0.43528, 0.22833], [0.41754, 0.22293], [0.41475, 0.21308], [0.43946, 0.20673], [0.51009, 0.20229]]	[{"grade": "4a", "height": "10m", "belayPosition": [0.43737, 0.71832], "labelPosition": [0.49617, 0.7704]}, {"grade": "4c", "height": "20m", "belayPosition": [0.30097, 0.60591], "labelPosition": [0.35003, 0.66561]}, {"grade": "4b", "height": "30m", "belayPosition": [0.50139, 0.43442], "labelPosition": [0.40049, 0.51413]}, {"grade": "4c", "height": "30m", "belayPosition": [0.50939, 0.20229], "labelPosition": [0.5508, 0.35186]}]	\N	multipitch	2026-07-17 12:28:12.671432+00
33	277	[[0.64975, 0.87667], [0.65525, 0.81933], [0.653, 0.775], [0.646, 0.74967], [0.64075, 0.73933], [0.63925, 0.72733], [0.623, 0.66867], [0.62225, 0.63767], [0.62, 0.603], [0.604, 0.583], [0.59675, 0.56867], [0.59175, 0.55167], [0.582, 0.53033], [0.57675, 0.50633], [0.55925, 0.489], [0.55025, 0.469], [0.54275, 0.44967], [0.53225, 0.44367], [0.53175, 0.41367], [0.51075, 0.418], [0.50775, 0.43433], [0.47075, 0.43667], [0.47675, 0.41], [0.47275, 0.37267], [0.475, 0.33767], [0.47725, 0.297], [0.49775, 0.24833], [0.48675, 0.247], [0.48825, 0.22333], [0.497, 0.18867], [0.51, 0.16067], [0.51525, 0.13633], [0.52125, 0.098], [0.52225, 0.05367]]	[{"grade": "UIAA V / V+", "height": "30m", "belayPosition": [0.59075, 0.55167], "labelPosition": [0.566, 0.72367]}, {"grade": "UIAA V-", "height": "35m", "belayPosition": [0.47325, 0.42833], "labelPosition": [0.509, 0.49833]}, {"grade": "UIAA V", "height": "25m", "belayPosition": [0.48325, 0.28567], "labelPosition": [0.41125, 0.34633]}, {"grade": "UIAA IV+ / V", "height": "30m", "belayPosition": [0.522, 0.054], "labelPosition": [0.44325, 0.146]}]	[{"path": [[0.52375, 0.05933], [0.527, 0.069], [0.52725, 0.08367]], "label": "50m", "anchor": [null, null], "labelPosition": [0.554, 0.078]}, {"path": [[0.48975, 0.42633], [0.491, 0.458]], "label": "50m", "anchor": [0.48875, 0.42067], "labelPosition": [0.45, 0.465]}]	multipitch	2026-07-17 12:28:12.671432+00
34	278	[[0.85539, 0.9113], [0.84824, 0.84], [0.8232, 0.81217], [0.81451, 0.73652], [0.80889, 0.68696], [0.78181, 0.62783], [0.77006, 0.6087], [0.78385, 0.58435], [0.7721, 0.49043], [0.74706, 0.46], [0.744, 0.43391], [0.76035, 0.41565], [0.75881, 0.37826], [0.74911, 0.37304], [0.73889, 0.31391], [0.72305, 0.2913]]	[{"grade": "Diff 3a", "height": "20m", "belayPosition": [0.535, 2.64435], "labelPosition": [0.72049, 3.15739]}, {"grade": "Diff 3a", "height": "10m", "belayPosition": [0.47011, 2.26087], "labelPosition": [0.54318, 2.35565]}, {"grade": "", "height": "", "belayPosition": [1.3117, 1.3287], "labelPosition": [null, null]}, {"grade": "", "height": "", "belayPosition": [1.30404, 0.7913], "labelPosition": [null, null]}, {"grade": "", "height": "", "belayPosition": [1.23659, 0.25391], "labelPosition": [null, null]}, {"grade": "4a", "height": "35m", "belayPosition": [0.82678, 0.81304], "labelPosition": [0.87021, 0.86]}, {"grade": "4a", "height": "30m", "belayPosition": [0.79765, 0.66174], "labelPosition": [0.83546, 0.71565]}, {"grade": "", "height": "20m", "belayPosition": [0.77261, 0.60261], "labelPosition": [0.80583, 0.62174]}, {"grade": "3c", "height": "50m", "belayPosition": [0.77466, 0.51304], "labelPosition": [0.79254, 0.54696]}, {"grade": "4a", "height": "25m", "belayPosition": [0.74706, 0.45565], "labelPosition": [0.7813, 0.47478]}, {"grade": "4a", "height": "20m", "belayPosition": [0.75881, 0.39391], "labelPosition": [0.77466, 0.41652]}, {"grade": "4a", "height": "15m", "belayPosition": [0.74451, 0.34435], "labelPosition": [0.77108, 0.34783]}, {"grade": "3c", "height": "30m", "belayPosition": [0.72407, 0.2913], "labelPosition": [0.75064, 0.30348]}]	[{"path": [[1.23148, 0.16783], [1.13592, 0.17565]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.79765, 0.39304], [0.82984, 0.42957], [0.86868, 0.46348]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.72611, 0.28], [0.7302, 0.27652], [0.73786, 0.29217]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}]	multipitch	2026-07-17 12:28:12.671432+00
35	279	[[0.2192, 0.56009], [0.2259, 0.57095], [0.22665, 0.58422], [0.22702, 0.6098], [0.22367, 0.639], [0.22367, 0.6513], [0.22739, 0.67013], [0.23111, 0.68147], [0.23297, 0.67519], [0.24191, 0.6834], [0.2393, 0.69184], [0.23744, 0.71042], [0.24004, 0.71742], [0.25493, 0.72852], [0.26498, 0.73769], [0.2754, 0.73818], [0.28619, 0.75097], [0.28768, 0.76207], [0.23707, 0.78716], [0.22627, 0.80598], [0.23483, 0.82022], [0.24525, 0.83181], [0.25642, 0.85135], [0.25158, 0.85545], [0.262, 0.87138], [0.2393, 0.88103], [0.20506, 0.90492], [0.19092, 0.91964], [0.20022, 0.93436], [0.18571, 0.94281], [0.19166, 0.95053], [0.17082, 0.97394]]	[{"grade": "IV", "height": "38m", "belayPosition": [0.18757, 0.94764], "labelPosition": [0.21437, 0.95174]}, {"grade": "V", "height": "50m", "belayPosition": [0.23818, 0.88127], "labelPosition": [0.2259, 0.90878]}, {"grade": "IV", "height": "18m", "belayPosition": [0.25158, 0.85618], "labelPosition": [0.2754, 0.87114]}, {"grade": "IV+", "height": "28m", "belayPosition": [0.22739, 0.81081], "labelPosition": [0.26833, 0.81829]}, {"grade": "III+", "height": "45m", "belayPosition": [0.28322, 0.76158], "labelPosition": [0.28619, 0.7792]}, {"grade": "IV+", "height": "40m", "belayPosition": [0.23521, 0.71332], "labelPosition": [0.20655, 0.73142]}, {"grade": "V", "height": "25m", "belayPosition": [0.23483, 0.67616], "labelPosition": [0.18496, 0.69015]}, {"grade": "IV", "height": "35m", "belayPosition": [0.22367, 0.6361], "labelPosition": [0.17603, 0.64431]}, {"grade": "IV", "height": "55m", "belayPosition": [0.21697, 0.55888], "labelPosition": [0.18236, 0.59604]}]	[{"path": [[0.22293, 0.56009], [0.23, 0.56009], [0.23, 0.56419]], "label": "~10m", "anchor": [0.2326, 0.5765], "labelPosition": [0.24377, 0.55719]}, {"path": [[0.23483, 0.5806], [0.24079, 0.59097]], "label": "60m", "anchor": [null, null], "labelPosition": [0.26349, 0.5958]}, {"path": [[0.26907, 0.70801], [0.27242, 0.71597], [0.28545, 0.71284], [0.28768, 0.70584], [0.30703, 0.69474], [0.32118, 0.7015]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.40007, 0.72032], [0.40194, 0.73625], [0.41608, 0.75265], [0.43766, 0.7541]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.50242, 0.75772], [0.53591, 0.75386]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.69297, 0.73842], [0.73949, 0.743], [0.7112, 0.77124]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}]	multipitch	2026-07-17 12:28:12.671432+00
36	280	[[0.40755, 0.62817], [0.44889, 0.60669], [0.46582, 0.5791], [0.47526, 0.55493], [0.50293, 0.54321], [0.52051, 0.52734], [0.52051, 0.50781], [0.51204, 0.50195], [0.51335, 0.48804], [0.51009, 0.47559], [0.52441, 0.46021], [0.53418, 0.45215], [0.54199, 0.43726], [0.53906, 0.41992], [0.51693, 0.4209], [0.48275, 0.43237], [0.4541, 0.43628], [0.45443, 0.43457], [0.45345, 0.41675], [0.4502, 0.38892], [0.45443, 0.36108], [0.45085, 0.31665], [0.4388, 0.29956], [0.42025, 0.2937], [0.41146, 0.28906], [0.37109, 0.28882], [0.35905, 0.27856], [0.33464, 0.26978], [0.33301, 0.23657], [0.32943, 0.21216], [0.31673, 0.20874], [0.26921, 0.20435], [0.2474, 0.20801], [0.21712, 0.17822]]	[{"grade": "4c", "height": "28m", "belayPosition": [0.5153, 0.42114], "labelPosition": [0.5625, 0.52905]}, {"grade": "4b", "height": "18m", "belayPosition": [0.42611, 0.29492], "labelPosition": [0.4873, 0.35327]}, {"grade": "4a", "height": "10m", "belayPosition": [0.21712, 0.17822], "labelPosition": [0.36068, 0.22437]}]	[{"path": [[0.21549, 0.18652], [0.2181, 0.21582]], "label": "~60m", "anchor": [null, null], "labelPosition": [0.20768, 0.26123]}, {"path": [[0.16211, 0.75586], [0.26628, 0.73218], [0.26823, 0.71387], [0.21842, 0.70728], [0.23112, 0.68628], [0.29557, 0.66968]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}]	multipitch	2026-07-17 12:28:12.671432+00
37	282	[[0.39506, 0.9375], [0.39581, 0.792], [0.39656, 0.5585], [0.40179, 0.4545], [0.40379, 0.425], [0.41401, 0.4045], [0.42024, 0.385], [0.417, 0.367], [0.417, 0.355], [0.41152, 0.336], [0.42522, 0.2915], [0.44666, 0.262], [0.46361, 0.243], [0.47483, 0.231], [0.47732, 0.225], [0.47707, 0.219], [0.47134, 0.216], [0.46037, 0.209], [0.4499, 0.2005], [0.4499, 0.1915], [0.45638, 0.1845], [0.46336, 0.1765], [0.4838, 0.16], [0.49177, 0.1495]]	[{"grade": "", "height": "45m", "belayPosition": [0.40429, 0.4395], "labelPosition": [0.40927, 0.5305]}, {"grade": "", "height": "45m", "belayPosition": [0.46162, 0.244], "labelPosition": [0.4327, 0.2975]}, {"grade": "", "height": "25m", "belayPosition": [0.47208, 0.212], "labelPosition": [0.48629, 0.2275]}, {"grade": "", "height": "25m", "belayPosition": [0.48953, 0.15], "labelPosition": [0.42298, 0.1825]}]	[{"path": [[0.45912, 0.156], [0.43644, 0.1545]], "label": "", "anchor": [null, null], "labelPosition": [null, null]}, {"path": [[0.40354, 0.1515], [0.40254, 0.1305], [0.39681, 0.129], [0.39432, 0.1435]], "label": "Scramble up & over", "anchor": [null, null], "labelPosition": [0.34945, 0.105]}]	multipitch	2026-07-17 12:28:12.671432+00
47	1051	[[0.5501647584995758, 0.930000018356438], [0.5201557842154064, 0.8400000091782189], [0.5001498013592934, 0.7600000137673285], [0.5501647584995758, 0.659999990821781], [0.5401617670715194, 0.569999981643562], [0.5001498013592934, 0.479999972465343], [0.470140827075124, 0.3999999770544525], [0.5001498013592934, 0.3000000114727737], [0.46013783564706745, 0.19999998852722625], [0.4401318527909545, 0.1100000080309416]]	[{"grade": "4a", "height": "30m", "belayPosition": [0.5001498013592934, 0.7600000137673285], "labelPosition": [0.5501498013592935, 0.7650000137673285]}, {"grade": "4c", "height": "35m", "belayPosition": [0.5401617670715194, 0.6282706583352914], "labelPosition": [0.5901617670715195, 0.6332706583352914]}, {"grade": "4b", "height": "25m", "belayPosition": [0.5001498013592934, 0.358270688164503], "labelPosition": [0.5501498013592935, 0.36327068816450303]}]	[{"path": [[0.32009584067604213, 0.2158646547704711], [0.2700808835357597, 0.5458646501813615], [0.24007190925159022, 0.9558646983670113]], "label": "abseil 45m", "anchor": null, "labelPosition": null}]	\N	2026-07-17 18:57:50.923526+00
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: rdsadmin
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Name: area_id_seq; Type: SEQUENCE SET; Schema: climbing; Owner: climbing
--

SELECT pg_catalog.setval('climbing.area_id_seq', 318, true);


--
-- Name: area_reference_id_seq; Type: SEQUENCE SET; Schema: climbing; Owner: climbing
--

SELECT pg_catalog.setval('climbing.area_reference_id_seq', 1, false);


--
-- Name: crawl_frontier_id_seq; Type: SEQUENCE SET; Schema: climbing; Owner: climbing
--

SELECT pg_catalog.setval('climbing.crawl_frontier_id_seq', 257, true);


--
-- Name: guide_id_seq; Type: SEQUENCE SET; Schema: climbing; Owner: climbing
--

SELECT pg_catalog.setval('climbing.guide_id_seq', 1, false);


--
-- Name: guide_section_id_seq; Type: SEQUENCE SET; Schema: climbing; Owner: climbing
--

SELECT pg_catalog.setval('climbing.guide_section_id_seq', 1, false);


--
-- Name: guidebook_id_seq; Type: SEQUENCE SET; Schema: climbing; Owner: climbing
--

SELECT pg_catalog.setval('climbing.guidebook_id_seq', 35, true);


--
-- Name: media_id_seq; Type: SEQUENCE SET; Schema: climbing; Owner: climbing
--

SELECT pg_catalog.setval('climbing.media_id_seq', 47, true);


--
-- Name: provenance_id_seq; Type: SEQUENCE SET; Schema: climbing; Owner: climbing
--

SELECT pg_catalog.setval('climbing.provenance_id_seq', 1, true);


--
-- Name: route_id_seq; Type: SEQUENCE SET; Schema: climbing; Owner: climbing
--

SELECT pg_catalog.setval('climbing.route_id_seq', 1051, true);


--
-- Name: route_parking_id_seq; Type: SEQUENCE SET; Schema: climbing; Owner: climbing
--

SELECT pg_catalog.setval('climbing.route_parking_id_seq', 7, true);


--
-- Name: route_reference_id_seq; Type: SEQUENCE SET; Schema: climbing; Owner: climbing
--

SELECT pg_catalog.setval('climbing.route_reference_id_seq', 243, true);


--
-- Name: topo_id_seq; Type: SEQUENCE SET; Schema: climbing; Owner: climbing
--

SELECT pg_catalog.setval('climbing.topo_id_seq', 47, true);


--
-- Name: area area_parent_id_name_key; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.area
    ADD CONSTRAINT area_parent_id_name_key UNIQUE (parent_id, name);


--
-- Name: area area_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.area
    ADD CONSTRAINT area_pkey PRIMARY KEY (id);


--
-- Name: area_reference area_reference_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.area_reference
    ADD CONSTRAINT area_reference_pkey PRIMARY KEY (id);


--
-- Name: ascent_style ascent_style_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.ascent_style
    ADD CONSTRAINT ascent_style_pkey PRIMARY KEY (code);


--
-- Name: character character_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing."character"
    ADD CONSTRAINT character_pkey PRIMARY KEY (code);


--
-- Name: commitment_grade commitment_grade_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.commitment_grade
    ADD CONSTRAINT commitment_grade_pkey PRIMARY KEY (code);


--
-- Name: crawl_frontier crawl_frontier_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.crawl_frontier
    ADD CONSTRAINT crawl_frontier_pkey PRIMARY KEY (id);


--
-- Name: crawl_frontier crawl_frontier_source_id_external_id_key; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.crawl_frontier
    ADD CONSTRAINT crawl_frontier_source_id_external_id_key UNIQUE (source_id, external_id);


--
-- Name: discipline discipline_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.discipline
    ADD CONSTRAINT discipline_pkey PRIMARY KEY (code);


--
-- Name: external_ref external_ref_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.external_ref
    ADD CONSTRAINT external_ref_pkey PRIMARY KEY (entity_type, entity_id, source_id);


--
-- Name: external_ref external_ref_source_id_external_id_key; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.external_ref
    ADD CONSTRAINT external_ref_source_id_external_id_key UNIQUE (source_id, external_id);


--
-- Name: feature feature_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.feature
    ADD CONSTRAINT feature_pkey PRIMARY KEY (code);


--
-- Name: first_ascent first_ascent_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.first_ascent
    ADD CONSTRAINT first_ascent_pkey PRIMARY KEY (route_id, kind);


--
-- Name: grade_conversion grade_conversion_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.grade_conversion
    ADD CONSTRAINT grade_conversion_pkey PRIMARY KEY (grade_system_code, original_grade);


--
-- Name: grade_system grade_system_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.grade_system
    ADD CONSTRAINT grade_system_pkey PRIMARY KEY (code);


--
-- Name: guide_edition guide_edition_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.guide_edition
    ADD CONSTRAINT guide_edition_pkey PRIMARY KEY (guide_id, edition);


--
-- Name: guide guide_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.guide
    ADD CONSTRAINT guide_pkey PRIMARY KEY (id);


--
-- Name: guide_route guide_route_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.guide_route
    ADD CONSTRAINT guide_route_pkey PRIMARY KEY (guide_id, route_id);


--
-- Name: guide_section guide_section_guide_id_position_key; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.guide_section
    ADD CONSTRAINT guide_section_guide_id_position_key UNIQUE (guide_id, "position");


--
-- Name: guide_section guide_section_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.guide_section
    ADD CONSTRAINT guide_section_pkey PRIMARY KEY (id);


--
-- Name: guide guide_slug_key; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.guide
    ADD CONSTRAINT guide_slug_key UNIQUE (slug);


--
-- Name: guidebook guidebook_isbn_key; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.guidebook
    ADD CONSTRAINT guidebook_isbn_key UNIQUE (isbn);


--
-- Name: guidebook guidebook_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.guidebook
    ADD CONSTRAINT guidebook_pkey PRIMARY KEY (id);


--
-- Name: hazard hazard_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.hazard
    ADD CONSTRAINT hazard_pkey PRIMARY KEY (code);


--
-- Name: incline incline_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.incline
    ADD CONSTRAINT incline_pkey PRIMARY KEY (code);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- Name: pitch pitch_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.pitch
    ADD CONSTRAINT pitch_pkey PRIMARY KEY (route_id, number);


--
-- Name: protection_grade protection_grade_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.protection_grade
    ADD CONSTRAINT protection_grade_pkey PRIMARY KEY (code);


--
-- Name: provenance provenance_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.provenance
    ADD CONSTRAINT provenance_pkey PRIMARY KEY (id);


--
-- Name: rock_type rock_type_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.rock_type
    ADD CONSTRAINT rock_type_pkey PRIMARY KEY (code);


--
-- Name: route route_area_id_name_key; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route
    ADD CONSTRAINT route_area_id_name_key UNIQUE (area_id, name);


--
-- Name: route_character route_character_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_character
    ADD CONSTRAINT route_character_pkey PRIMARY KEY (route_id, character_code);


--
-- Name: route_climatology route_climatology_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_climatology
    ADD CONSTRAINT route_climatology_pkey PRIMARY KEY (route_id, month);


--
-- Name: route_discipline route_discipline_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_discipline
    ADD CONSTRAINT route_discipline_pkey PRIMARY KEY (route_id, discipline_code);


--
-- Name: route_feature route_feature_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_feature
    ADD CONSTRAINT route_feature_pkey PRIMARY KEY (route_id, feature_code);


--
-- Name: route_grade route_grade_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_grade
    ADD CONSTRAINT route_grade_pkey PRIMARY KEY (route_id, grade_system_code);


--
-- Name: route_guidebook route_guidebook_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_guidebook
    ADD CONSTRAINT route_guidebook_pkey PRIMARY KEY (route_id, guidebook_id);


--
-- Name: route_hazard route_hazard_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_hazard
    ADD CONSTRAINT route_hazard_pkey PRIMARY KEY (route_id, hazard_code);


--
-- Name: route_parking route_parking_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_parking
    ADD CONSTRAINT route_parking_pkey PRIMARY KEY (id);


--
-- Name: route route_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route
    ADD CONSTRAINT route_pkey PRIMARY KEY (id);


--
-- Name: route_reference route_reference_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_reference
    ADD CONSTRAINT route_reference_pkey PRIMARY KEY (id);


--
-- Name: source source_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.source
    ADD CONSTRAINT source_pkey PRIMARY KEY (id);


--
-- Name: sun_window sun_window_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.sun_window
    ADD CONSTRAINT sun_window_pkey PRIMARY KEY (code);


--
-- Name: topo_line topo_line_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.topo_line
    ADD CONSTRAINT topo_line_pkey PRIMARY KEY (topo_id, route_id);


--
-- Name: topo topo_pkey; Type: CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.topo
    ADD CONSTRAINT topo_pkey PRIMARY KEY (id);


--
-- Name: area_geom_gix; Type: INDEX; Schema: climbing; Owner: climbing
--

CREATE INDEX area_geom_gix ON climbing.area USING gist (geom);


--
-- Name: area_name_trgm; Type: INDEX; Schema: climbing; Owner: climbing
--

CREATE INDEX area_name_trgm ON climbing.area USING gin (name public.gin_trgm_ops);


--
-- Name: crawl_frontier_fetch_pending_ix; Type: INDEX; Schema: climbing; Owner: climbing
--

CREATE INDEX crawl_frontier_fetch_pending_ix ON climbing.crawl_frontier USING btree (source_id, id) WHERE (fetch_status = 'pending'::text);


--
-- Name: crawl_frontier_needs_review_ix; Type: INDEX; Schema: climbing; Owner: climbing
--

CREATE INDEX crawl_frontier_needs_review_ix ON climbing.crawl_frontier USING btree (source_id) WHERE (tag_status = 'needs_review'::text);


--
-- Name: crawl_frontier_parent_ix; Type: INDEX; Schema: climbing; Owner: climbing
--

CREATE INDEX crawl_frontier_parent_ix ON climbing.crawl_frontier USING btree (parent_frontier_id);


--
-- Name: crawl_frontier_tag_pending_ix; Type: INDEX; Schema: climbing; Owner: climbing
--

CREATE INDEX crawl_frontier_tag_pending_ix ON climbing.crawl_frontier USING btree (source_id, id) WHERE ((fetch_status = 'done'::text) AND (tag_status = 'pending'::text));


--
-- Name: media_area_idx; Type: INDEX; Schema: climbing; Owner: climbing
--

CREATE INDEX media_area_idx ON climbing.media USING btree (area_id);


--
-- Name: provenance_route_field_ix; Type: INDEX; Schema: climbing; Owner: climbing
--

CREATE INDEX provenance_route_field_ix ON climbing.provenance USING btree (route_id, field);


--
-- Name: route_data_grade_ix; Type: INDEX; Schema: climbing; Owner: climbing
--

CREATE INDEX route_data_grade_ix ON climbing.route USING btree (data_grade);


--
-- Name: route_geom_gix; Type: INDEX; Schema: climbing; Owner: climbing
--

CREATE INDEX route_geom_gix ON climbing.route USING gist (geom);


--
-- Name: route_name_trgm; Type: INDEX; Schema: climbing; Owner: climbing
--

CREATE INDEX route_name_trgm ON climbing.route USING gin (name public.gin_trgm_ops);


--
-- Name: route_needs_field_check_ix; Type: INDEX; Schema: climbing; Owner: climbing
--

CREATE INDEX route_needs_field_check_ix ON climbing.route USING btree (needs_field_check) WHERE needs_field_check;


--
-- Name: route_parking_route_ix; Type: INDEX; Schema: climbing; Owner: climbing
--

CREATE INDEX route_parking_route_ix ON climbing.route_parking USING btree (route_id);


--
-- Name: route_status_ix; Type: INDEX; Schema: climbing; Owner: climbing
--

CREATE INDEX route_status_ix ON climbing.route USING btree (status);


--
-- Name: topo_area_idx; Type: INDEX; Schema: climbing; Owner: climbing
--

CREATE INDEX topo_area_idx ON climbing.topo USING btree (area_id);


--
-- Name: topo_line_route_idx; Type: INDEX; Schema: climbing; Owner: climbing
--

CREATE INDEX topo_line_route_idx ON climbing.topo_line USING btree (route_id);


--
-- Name: route_hazard route_hazard_evidence; Type: TRIGGER; Schema: climbing; Owner: climbing
--

CREATE TRIGGER route_hazard_evidence BEFORE INSERT OR UPDATE ON climbing.route_hazard FOR EACH ROW EXECUTE FUNCTION climbing.enforce_hazard_evidence();


--
-- Name: area area_parent_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.area
    ADD CONSTRAINT area_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES climbing.area(id);


--
-- Name: area_reference area_reference_area_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.area_reference
    ADD CONSTRAINT area_reference_area_id_fkey FOREIGN KEY (area_id) REFERENCES climbing.area(id) ON DELETE CASCADE;


--
-- Name: area area_rock_code_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.area
    ADD CONSTRAINT area_rock_code_fkey FOREIGN KEY (rock_code) REFERENCES climbing.rock_type(code);


--
-- Name: crawl_frontier crawl_frontier_area_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.crawl_frontier
    ADD CONSTRAINT crawl_frontier_area_id_fkey FOREIGN KEY (area_id) REFERENCES climbing.area(id);


--
-- Name: crawl_frontier crawl_frontier_parent_frontier_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.crawl_frontier
    ADD CONSTRAINT crawl_frontier_parent_frontier_id_fkey FOREIGN KEY (parent_frontier_id) REFERENCES climbing.crawl_frontier(id);


--
-- Name: crawl_frontier crawl_frontier_route_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.crawl_frontier
    ADD CONSTRAINT crawl_frontier_route_id_fkey FOREIGN KEY (route_id) REFERENCES climbing.route(id);


--
-- Name: crawl_frontier crawl_frontier_source_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.crawl_frontier
    ADD CONSTRAINT crawl_frontier_source_id_fkey FOREIGN KEY (source_id) REFERENCES climbing.source(id);


--
-- Name: external_ref external_ref_source_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.external_ref
    ADD CONSTRAINT external_ref_source_id_fkey FOREIGN KEY (source_id) REFERENCES climbing.source(id);


--
-- Name: first_ascent first_ascent_route_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.first_ascent
    ADD CONSTRAINT first_ascent_route_id_fkey FOREIGN KEY (route_id) REFERENCES climbing.route(id) ON DELETE CASCADE;


--
-- Name: first_ascent first_ascent_style_code_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.first_ascent
    ADD CONSTRAINT first_ascent_style_code_fkey FOREIGN KEY (style_code) REFERENCES climbing.ascent_style(code);


--
-- Name: grade_conversion grade_conversion_grade_system_code_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.grade_conversion
    ADD CONSTRAINT grade_conversion_grade_system_code_fkey FOREIGN KEY (grade_system_code) REFERENCES climbing.grade_system(code);


--
-- Name: guide guide_area_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.guide
    ADD CONSTRAINT guide_area_id_fkey FOREIGN KEY (area_id) REFERENCES climbing.area(id);


--
-- Name: guide_edition guide_edition_guide_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.guide_edition
    ADD CONSTRAINT guide_edition_guide_id_fkey FOREIGN KEY (guide_id) REFERENCES climbing.guide(id) ON DELETE CASCADE;


--
-- Name: guide_route guide_route_guide_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.guide_route
    ADD CONSTRAINT guide_route_guide_id_fkey FOREIGN KEY (guide_id) REFERENCES climbing.guide(id) ON DELETE CASCADE;


--
-- Name: guide_route guide_route_route_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.guide_route
    ADD CONSTRAINT guide_route_route_id_fkey FOREIGN KEY (route_id) REFERENCES climbing.route(id);


--
-- Name: guide_route guide_route_section_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.guide_route
    ADD CONSTRAINT guide_route_section_id_fkey FOREIGN KEY (section_id) REFERENCES climbing.guide_section(id) ON DELETE SET NULL;


--
-- Name: guide_section guide_section_area_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.guide_section
    ADD CONSTRAINT guide_section_area_id_fkey FOREIGN KEY (area_id) REFERENCES climbing.area(id);


--
-- Name: guide_section guide_section_guide_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.guide_section
    ADD CONSTRAINT guide_section_guide_id_fkey FOREIGN KEY (guide_id) REFERENCES climbing.guide(id) ON DELETE CASCADE;


--
-- Name: media media_area_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.media
    ADD CONSTRAINT media_area_id_fkey FOREIGN KEY (area_id) REFERENCES climbing.area(id) ON DELETE SET NULL;


--
-- Name: pitch pitch_grade_system_code_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.pitch
    ADD CONSTRAINT pitch_grade_system_code_fkey FOREIGN KEY (grade_system_code) REFERENCES climbing.grade_system(code);


--
-- Name: pitch pitch_route_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.pitch
    ADD CONSTRAINT pitch_route_id_fkey FOREIGN KEY (route_id) REFERENCES climbing.route(id) ON DELETE CASCADE;


--
-- Name: provenance provenance_route_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.provenance
    ADD CONSTRAINT provenance_route_id_fkey FOREIGN KEY (route_id) REFERENCES climbing.route(id) ON DELETE CASCADE;


--
-- Name: provenance provenance_source_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.provenance
    ADD CONSTRAINT provenance_source_id_fkey FOREIGN KEY (source_id) REFERENCES climbing.source(id);


--
-- Name: route route_area_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route
    ADD CONSTRAINT route_area_id_fkey FOREIGN KEY (area_id) REFERENCES climbing.area(id);


--
-- Name: route_character route_character_character_code_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_character
    ADD CONSTRAINT route_character_character_code_fkey FOREIGN KEY (character_code) REFERENCES climbing."character"(code);


--
-- Name: route_character route_character_route_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_character
    ADD CONSTRAINT route_character_route_id_fkey FOREIGN KEY (route_id) REFERENCES climbing.route(id) ON DELETE CASCADE;


--
-- Name: route_climatology route_climatology_route_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_climatology
    ADD CONSTRAINT route_climatology_route_id_fkey FOREIGN KEY (route_id) REFERENCES climbing.route(id) ON DELETE CASCADE;


--
-- Name: route route_commitment_code_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route
    ADD CONSTRAINT route_commitment_code_fkey FOREIGN KEY (commitment_code) REFERENCES climbing.commitment_grade(code);


--
-- Name: route_discipline route_discipline_discipline_code_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_discipline
    ADD CONSTRAINT route_discipline_discipline_code_fkey FOREIGN KEY (discipline_code) REFERENCES climbing.discipline(code);


--
-- Name: route_discipline route_discipline_route_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_discipline
    ADD CONSTRAINT route_discipline_route_id_fkey FOREIGN KEY (route_id) REFERENCES climbing.route(id) ON DELETE CASCADE;


--
-- Name: route_feature route_feature_feature_code_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_feature
    ADD CONSTRAINT route_feature_feature_code_fkey FOREIGN KEY (feature_code) REFERENCES climbing.feature(code);


--
-- Name: route_feature route_feature_route_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_feature
    ADD CONSTRAINT route_feature_route_id_fkey FOREIGN KEY (route_id) REFERENCES climbing.route(id) ON DELETE CASCADE;


--
-- Name: route_grade route_grade_grade_system_code_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_grade
    ADD CONSTRAINT route_grade_grade_system_code_fkey FOREIGN KEY (grade_system_code) REFERENCES climbing.grade_system(code);


--
-- Name: route_grade route_grade_route_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_grade
    ADD CONSTRAINT route_grade_route_id_fkey FOREIGN KEY (route_id) REFERENCES climbing.route(id) ON DELETE CASCADE;


--
-- Name: route route_grade_system_code_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route
    ADD CONSTRAINT route_grade_system_code_fkey FOREIGN KEY (grade_system_code) REFERENCES climbing.grade_system(code);


--
-- Name: route_guidebook route_guidebook_guidebook_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_guidebook
    ADD CONSTRAINT route_guidebook_guidebook_id_fkey FOREIGN KEY (guidebook_id) REFERENCES climbing.guidebook(id);


--
-- Name: route_guidebook route_guidebook_route_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_guidebook
    ADD CONSTRAINT route_guidebook_route_id_fkey FOREIGN KEY (route_id) REFERENCES climbing.route(id) ON DELETE CASCADE;


--
-- Name: route_hazard route_hazard_hazard_code_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_hazard
    ADD CONSTRAINT route_hazard_hazard_code_fkey FOREIGN KEY (hazard_code) REFERENCES climbing.hazard(code);


--
-- Name: route_hazard route_hazard_route_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_hazard
    ADD CONSTRAINT route_hazard_route_id_fkey FOREIGN KEY (route_id) REFERENCES climbing.route(id) ON DELETE CASCADE;


--
-- Name: route route_incline_code_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route
    ADD CONSTRAINT route_incline_code_fkey FOREIGN KEY (incline_code) REFERENCES climbing.incline(code);


--
-- Name: route_parking route_parking_route_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_parking
    ADD CONSTRAINT route_parking_route_id_fkey FOREIGN KEY (route_id) REFERENCES climbing.route(id) ON DELETE CASCADE;


--
-- Name: route route_protection_code_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route
    ADD CONSTRAINT route_protection_code_fkey FOREIGN KEY (protection_code) REFERENCES climbing.protection_grade(code);


--
-- Name: route_reference route_reference_route_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route_reference
    ADD CONSTRAINT route_reference_route_id_fkey FOREIGN KEY (route_id) REFERENCES climbing.route(id) ON DELETE CASCADE;


--
-- Name: route route_rock_code_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route
    ADD CONSTRAINT route_rock_code_fkey FOREIGN KEY (rock_code) REFERENCES climbing.rock_type(code);


--
-- Name: route route_sun_window_code_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.route
    ADD CONSTRAINT route_sun_window_code_fkey FOREIGN KEY (sun_window_code) REFERENCES climbing.sun_window(code);


--
-- Name: topo topo_area_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.topo
    ADD CONSTRAINT topo_area_id_fkey FOREIGN KEY (area_id) REFERENCES climbing.area(id) ON DELETE SET NULL;


--
-- Name: topo_line topo_line_route_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.topo_line
    ADD CONSTRAINT topo_line_route_id_fkey FOREIGN KEY (route_id) REFERENCES climbing.route(id) ON DELETE CASCADE;


--
-- Name: topo_line topo_line_source_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.topo_line
    ADD CONSTRAINT topo_line_source_id_fkey FOREIGN KEY (source_id) REFERENCES climbing.source(id);


--
-- Name: topo_line topo_line_topo_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.topo_line
    ADD CONSTRAINT topo_line_topo_id_fkey FOREIGN KEY (topo_id) REFERENCES climbing.topo(id) ON DELETE CASCADE;


--
-- Name: topo topo_media_id_fkey; Type: FK CONSTRAINT; Schema: climbing; Owner: climbing
--

ALTER TABLE ONLY climbing.topo
    ADD CONSTRAINT topo_media_id_fkey FOREIGN KEY (media_id) REFERENCES climbing.media(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict fp6FoTXCcWuPx5foQVpVeeOAXlLjNWso26JGe1iD7UYCkeC8D6ttd318dXmjm5X

